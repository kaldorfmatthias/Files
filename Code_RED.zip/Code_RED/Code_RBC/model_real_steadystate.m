function [ys,params,check]=model_real_steadystate(ys,exo,M_,options)

global estim_params

%% Calibration

% % Inside parameters (potentially estimated)
% if ~isempty(estim_params)
%     parin.RHOA    = RHO_A;                           % persistence parameter exogenous TFP
%     parin.SIGMAA  = SIGMA_A;                         % standard deviation of innovation to exogenous TFP
%     par           = setParams(parin,'estimation');   % Set parameters
% else
%     parin         = [];
%     par           = setParams(parin,'calibration');
% end

par           = setParams();

% LOOP OVER PARAMETERS
% Make sure that parameters is set to the value specified in mainfile.m (line 22)
paramsLOOP = ["ETA0","NU","GAMMA_P","PHICss","PHIGss","SIGMA_A","SIGMA_M","TAXC"];
for iPL = 1:length(paramsLOOP)
    
    target_val = M_.params(ismember(M_.param_names, paramsLOOP(iPL)));
    params_val = eval(strcat('par.',paramsLOOP(iPL)));
    
    if target_val ~= params_val && ~isnan(target_val)
        
        parVAL = strcat('par.',paramsLOOP(iPL),'=', string(target_val), ';');
        eval(parVAL)
        
    end
end

%% Compute steady state
[ss,par,check]   = fcomputeSS(par);

%% Load parameters and steady state of endogeneous variables into Dynare

nparams     = size(M_.param_names,1);
params      = NaN(nparams,1);

%--------------------- Read out outside-parameters ------------------------
for iout = 1 : nparams
    
    parName = deblank(M_.param_names{iout});
    
	if isfield(par,parName) == 1
 		params_val = eval(['par.' parName]);
        eval([ parName ' = params_val;']);
        
        eval(['params(' num2str(iout) ') = ' M_.param_names{iout} ';' ])
               
	end
end

% Update parameters which were changed in the steady state file
for ii = 1: nparams
    eval([ 'M_.params(' num2str(ii) ') = ' M_.param_names{ii} ';' ])
end

%------------- Read out endogenous variables' steady state ----------------
nEndoVar = M_.orig_endo_nbr; %auxiliary variables are set automatically

for iendo = 1 : nEndoVar
    
    varendoName = deblank(M_.endo_names{iendo});
        
	if isfield(ss,varendoName) == 1
        endo_val = eval(['ss.' varendoName]);
        eval([ varendoName ' = endo_val;']);
        eval(['ys(' int2str(iendo) ') = ' varendoName ';']);
	end
end
 
end
