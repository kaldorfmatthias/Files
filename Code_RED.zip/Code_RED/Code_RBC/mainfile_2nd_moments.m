%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% Computes data moments and generates table 2
clear; clc; close all;

%% LOAD DATA (ECB Data Warehouse)
opts                = delimitedTextImportOptions("NumVariables", 6);

opts.DataLines      = [6, Inf];
opts.Delimiter      = ";";
opts.VariableNames  = ["Date", "GDP", "C", "GFCF", "Employment", "Deflator"];
opts.VariableTypes  = ["string", "double", "double", "double", "double", "double"];
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule  = "read";
opts                = setvaropts(opts, "Date", "WhitespaceRule", "preserve");
opts                = setvaropts(opts, "Date", "EmptyFieldRule", "auto");

table_real_data     = readtable("Real_sector.csv", opts);

clear opts

%% PREPARE VARIABLES
% Units: GDP,C & GFCF millions; employment thousands

table_real_data.Date=flip(table_real_data.Date);
table_real_data.Date=[1995:0.25:2022.75]';
table_real_data.GDP=flip(table_real_data.GDP);
table_real_data.C=flip(table_real_data.C);
table_real_data.GFCF=flip(table_real_data.GFCF);
table_real_data.Employment=flip(table_real_data.Employment);
table_real_data.Deflator=flip(table_real_data.Deflator);

datest=find(table_real_data.Date==1995);

dateend=find(table_real_data.Date==2019.75);

GFCF_GDP                = mean( table_real_data.GFCF(datest:dateend) ./table_real_data.GDP(datest:dateend));
C_GDP                   = mean( table_real_data.C(datest:dateend) ./table_real_data.GDP(datest:dateend));

vecLogGDP_defl_percap   = log( 1000000*table_real_data.GDP(datest:dateend)...
    ./table_real_data.Deflator(datest:dateend)./(1000*table_real_data.Employment(datest:dateend)) );

vecLogC_defl_percap     = log( 1000000*table_real_data.C(datest:dateend)...
    ./table_real_data.Deflator(datest:dateend)./(1000*table_real_data.Employment(datest:dateend)) );

vecLogGFCF_defl_percap  = log( 1000000*table_real_data.GFCF(datest:dateend)...
    ./table_real_data.Deflator(datest:dateend)./(1000*table_real_data.Employment(datest:dateend)) );


%% FILTER
lambdaa = 1600;         % quarterly


[vecGDP_tr,vecGDP_cy]   = hpfilter(...
    vecLogGDP_defl_percap(datest:dateend) ,lambdaa);

[vecC_tr,vecC_cy]       = hpfilter(...
    vecLogC_defl_percap(datest:dateend) ,lambdaa);

[vecGFCF_tr,vecGFCF_cy] = hpfilter(...
    vecLogGFCF_defl_percap(datest:dateend) ,lambdaa);


%% MOMENTS
std_GDP     = 100 * sqrt( var( vecGDP_cy(datest:dateend) ) );
std_C       = 100 * sqrt( var( vecC_cy(datest:dateend) ) );
std_GFCF    = 100 * sqrt( var( vecGFCF_cy(datest:dateend) ) );

auto_c      = corr(vecC_cy(datest+1:dateend),vecC_cy(datest:dateend-1));
auto_GFCF   = corr(vecGFCF_cy(datest+1:dateend),vecGFCF_cy(datest:dateend-1));
auto_GDP    = corr(vecGDP_cy(datest+1:dateend),vecGDP_cy(datest:dateend-1));

corr_GDP_c  = corr(vecC_cy(datest:dateend),vecGDP_cy(datest:dateend));
corr_GDP_GFCF= corr(vecGFCF_cy(datest:dateend),vecGDP_cy(datest:dateend));


vecResult   = [C_GDP; GFCF_GDP; std_GDP ; std_C ; std_GFCF ; std_C/std_GDP ; std_GFCF/std_GDP ...
    ; auto_GDP; auto_c; auto_GFCF; corr_GDP_c; corr_GDP_GFCF];
vecNames    = {'Mean C/GDP';'Mean I/GDP';'Std GDP';'Std C';'Std I';'Std C/Std Y';'Std I/Std Y';'Auto GDP';'Auto C';...
    'Auto I';'Corr GDP-C';'Corr GDP-I'};

table(vecNames,vecResult)
