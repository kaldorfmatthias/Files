%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% optimal symmetric collateral policy in baseline model and generates table 2

clear; clc; close all;

% OPTIONS
opt.perorder        = 2;        % order of perturbation
opt.nirf            = 0;        % length of irf
opt.nperiods        = 0;        % length of simulation
opt.plotirf         = 'N';      % Plot IRF Functions
opt.savefigures     = 'N';      % Save Figures 

eval(['dynare model_real_dynamics.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf) ' -Dnperiods=' num2str(opt.nperiods)])
results.baseline.M_   = M_;
results.baseline.ss   = steady_(M_,options_,oo_);
results.baseline.mean = oo_.mean;
results.baseline.std  = sqrt(diag(oo_.var));
results.baseline.auto = oo_.autocorr{1,1};
results.baseline.var  = oo_.var;

fprintf('****************************************************\n');
fprintf('<strong>STATIONARY EQUILIBRIUM, BASELINE</strong> \n\n');
momentsModel(results.baseline);

fprintf('Calibrated ETA0 is %1.6f \n',results.baseline.M_.params(18))

%% symmetric policy
eval(['dynare model_real.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf) ' -Dnperiods=' num2str(opt.nperiods)])

nphi            = 21;
polMat.PHICss   = linspace(0.6,1,nphi);
polMat.PHIGss   = linspace(0.6,1,nphi);

% financial side
LEVC_pos        = strmatch('levc',M_.endo_names,'exact');
SPREAD_pos      = strmatch('spreadc',M_.endo_names,'exact');
PREMIUM_pos     = strmatch('premiumc',M_.endo_names,'exact');

% welfare
Y_pos           = strmatch('y',M_.endo_names,'exact');
DEFC_pos        = strmatch('Fc',M_.endo_names,'exact');
DEFG_pos        = strmatch('Fg',M_.endo_names,'exact');
CDCOST_pos      = strmatch('CDcost',M_.endo_names,'exact');
FCOST_pos       = strmatch('Fcost',M_.endo_names,'exact');
LMCOST_pos      = strmatch('LMcost',M_.endo_names,'exact');
PCOST_pos       = strmatch('Pcost',M_.endo_names,'exact');
V_pos           = strmatch('V',M_.endo_names,'exact');

% financial side
vecLEV_M        = nan(nphi,1);
vecSPREAD_M     = nan(nphi,1);
vecPREMIUM_M    = nan(nphi,1);

% welfare
vecWelfgain     = nan(nphi,1);
vecWelfare      = nan(nphi,1);
vecY_M          = nan(nphi,1);
vecDefg_M       = nan(nphi,1);
vecDefc_M       = nan(nphi,1);
vecCDcost_M     = nan(nphi,1);
vecFcost_M      = nan(nphi,1);
vecLMcost_M     = nan(nphi,1);
vecPcost_M      = nan(nphi,1);

% loop over different collateral parameters

for iphi = 1:nphi
           
        set_param_value('PHICss', polMat.PHICss(1,iphi));
        set_param_value('PHIGss', polMat.PHIGss(1,iphi));
        
        try
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     

        results.M_           = M_;
        results.ss           = steady_(M_,options_,oo_);                 
        results.means        = oo_.mean;
        
        % financial side
        vecLEV_M(iphi,1)              = 100*results.means(LEVC_pos); 
        vecSPREAD_M(iphi,1)           = results.means(SPREAD_pos);
        vecPREMIUM_M(iphi,1)          = results.means(PREMIUM_pos);
        
        % welfare   
        vecY_M(iphi,1)                = results.means(Y_pos);
        vecWelfare(iphi,1)            = results.means(V_pos);
        vecDefc_M(iphi,1)             = results.means(DEFC_pos);
        vecDefg_M(iphi,1)             = results.means(DEFG_pos);
        vecFcost_M(iphi,1)            = results.means(FCOST_pos);
        vecLMcost_M(iphi,1)           = results.means(LMCOST_pos);
        vecCDcost_M(iphi,1)           = results.means(CDCOST_pos);
        vecPcost_M(iphi,1)            = results.means(PCOST_pos);

        catch
            
        end

        clc
        fprintf('collateral parameter  : %1.0f \n',iphi);
        
end

% optimal collateral parameter
indmax = find(vecWelfare==max(vecWelfare));
fprintf('optimal haircut value: %1.6f \n',polMat.PHIGss(indmax))

% plot welfare analysis 
vecWelfareCE = 100*(1-exp((1-0.99)*(-vecWelfare+vecWelfare(indmax))));
plot(polMat.PHIGss,vecWelfareCE,'LineWidth',1.5);
xlabel('Collateral Parameter $\phi_{sym}$','Interpreter','LaTex');
xline(polMat.PHIGss(indmax));
title('Welfare (CE)','Interpreter','LaTex','FontSize',11);

% hold on
% plot(polMat.PHIGss,100*vecFcost_M/vecFcost_M(indmax)-100,'LineWidth',1.5,'color','red');
% plot(polMat.PHIGss,100*vecLMcost_M/vecLMcost_M(indmax)-100,'LineWidth',1.5,'color',[0 0.4470 0.7410]);
% plot(polMat.PHIGss,100*vecCDcost_M/vecCDcost_M(indmax)-100,'LineWidth',1.5,'color',[0.4660 0.6740 0.1880]);
% plot(polMat.PHIGss,100*vecY_M/vecY_M(1,1)-100,'LineWidth',1.5,'color','black');
% plot(polMat.PHIGss,nan(nphi,1),'--black');
% xlabel('Collateral Parameter $\phi_{sym}$','Interpreter','LaTex');
% % xlim([0.1 0.4])
% ylabel('Change (\%)','Interpreter','LaTex');
% title('Time Series Means','Interpreter','LaTex','FontSize',11);
% lgd = legend('Default Cost','LM Cost','Collateral Default Cost','GDP','Interpreter','LaTex','Location','best');
% %lgd.FontSize = 6;
% print('-r800','-depsc','Figures\policysymm_welfare');