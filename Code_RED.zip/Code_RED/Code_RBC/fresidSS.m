%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% residuals of financial markets, baseline

function [resid,out] = fresidSS(finguess,out,par)

out.mbarc   = finguess(1);
out.mbarg   = finguess(2);
out.bbar    = finguess(3);
out.TAXG    = finguess(4);

if ~isreal(out.mbarc) || ~isreal(out.mbarg)
    error('Calibration results in imaginary mbar')
end

if out.mbarc<0 || out.mbarg<0
    error('Calibration results in negative mbar')
end

out.OmegaB = - par.L1 * out.bbar^(par.L2-1);

% distribution
out.Fc      = normcdf((log(out.mbarc)-out.muM)/out.vsigM);
out.Fg      = normcdf((log(out.mbarg)-out.muM)/out.vsigM);
out.Gc      = normcdf((log(out.mbarc)-out.muM-out.vsigM^2)/out.vsigM);
out.Gg      = normcdf((log(out.mbarg)-out.muM-out.vsigM^2)/out.vsigM);
out.DFc     = 1 / (out.mbarc * out.vsigM * sqrt(2 * pi)) * ...
                exp(-1 * (log(out.mbarc) - out.muM)^2 / (2 * out.vsigM^2) );
out.DFg     = 1 / (out.mbarg * out.vsigM * sqrt(2 * pi)) * ...
                exp(-1 * (log(out.mbarg) - out.muM)^2 / (2 * out.vsigM^2) ); 

out.DGc     = out.DFc * out.mbarc;
out.DGg     = out.DFg * out.mbarg;

% partial derivatives of bond prices
out.Dqc     = -(par.S*out.Gc/out.mbarc^2 + par.VARPHI*out.DFc) / ( (1+out.PHIC*out.OmegaB)*(1+out.idep) );
out.Dqg     = -(par.S*out.Gg/out.mbarg^2 + par.VARPHI*out.DFg) / ( (1+out.PHIG*out.OmegaB)*(1+out.idep) );

% Implied bond prices from entrepreneur FOC for bonds
out.qc      = (par.BETAE*(par.S*(1-out.Fc)) - out.Dqc*out.mbarc*par.S) / (1-par.BETAE*(1-par.S));
out.qg      = (par.BETAE*(par.S*(1-out.Fg)) - out.Dqg*out.mbarg*par.S) / (1-par.BETAE*(1-par.S));

% Implied intermediate goods prices from entrepreneur FOC for capital
out.pc      = (1-par.BETAE*(1-par.DELTAK)) / ( (1-par.TAXC)*(par.BETAE*(1-out.Gc) - out.Dqc*out.mbarc^2) );             
out.pg      = (1-par.BETAE*(1-par.DELTAK)) / ( (1-out.TAXG)*(par.BETAE*(1-out.Gg) - out.Dqg*out.mbarg^2) ); 

% intermediate inputs and output
lguess      = 0.3;
zc2yguess   = (1/out.pc) * par.THETAC * (1-par.NU); 
zg2yguess   = (1/out.pg) * par.THETAG * par.NU; 
z2yguess    = (zc2yguess)^(1-par.NU)*zg2yguess^(par.NU);
z2lguess    = (1/z2yguess)^(1/(par.THETA-1));
yguess      = z2lguess^(par.THETA)*lguess;
zcguess     = zc2yguess*yguess;
zgguess     = zg2yguess*yguess;
wguess      = (1 - par.THETA) * yguess / lguess;
cguess      = (par.OMEGA_L/wguess * lguess^par.GAMMA_L)^(-1/par.GAMMA_C);
prodguess   = [zcguess,zgguess,lguess,cguess];

% solve
options     = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-16,'FunctionTolerance',1e-16);
prodstar    = fsolve(@(x) (fresidPROD(x,out,par)),prodguess,options);

[valfun,out]= fresidPROD(prodstar,out,par);
if max(abs(valfun)) > 1e-12
    error('Excess demand on goods markets non-zero')
end

out.TAXG1 = -par.TAXC*out.pc*out.zc/(out.pg*out.zg);

% bond payoff
out.Rc      = par.S*(out.Gc/out.mbarc + 1-out.Fc) - out.Fc*par.VARPHI + (1-par.S)*out.qc;
out.Rg      = par.S*(out.Gg/out.mbarg + 1-out.Fg) - out.Fg*par.VARPHI + (1-par.S)*out.qg;

% deposits
out.d       = (out.Rc*out.bc + out.Rg*out.bg)/(1+out.idep);

% eligibility premium consistent with bank FOC
qc1 = out.Rc/((1+out.PHIC*out.OmegaB)*(1+out.idep));
qg1 = out.Rg/((1+out.PHIG*out.OmegaB)*(1+out.idep));

% Residual 
resid(1)    = qc1 - out.qc;
resid(2)    = qg1 - out.qg;
resid(3)    = out.OmegaB - out.OmegaB1;
resid(4)    = out.TAXG - out.TAXG1;

end
