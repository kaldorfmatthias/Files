function par = setParams_firmreaction()

par.GAMMA_C     = 1;        % intertemporal substitution consumption (household)
par.BETA        = 0.995;    % discount factor (household)
par.BETAE       = 0.988;    % discount factor (entrepreneur) 
par.OMEGA_L     = 12;       % weight on labour disutility
par.GAMMA_L     = 1;        % Frisch elasticity of labour supply
par.GAMMA_P     = 3.9e-6;   % Externality parameter
par.THETA       = 1/3;      % Cobb-Douglas parameter (intermediate goods basket)
par.NU          = 0.2;      % Cobb-Douglas parameter (green intermediate good) 
par.VSIGss      = 0.21;     % std. deviation of idiosyncratic prod shock 
par.MUss        = -1/2*par.VSIGss^2; % normalization idiosyncratic prod shock
par.DELTAK      = 0.115/4;  % capital depreciation rate
par.DELTAZ      = 0.9979;   % persistence of pollution
par.VARPHI      = 1.2;      % default cost
par.S           = 0.05;     % maturity parameter
par.L0          = 0.05;     % lm cost intercept 
par.L1          = 0.0075;   % lm cost slope 
par.L2          = 0.5;      % lm cost curvature 
par.ETA0        = 0.0555;   % collateral default cost slope 
par.ETA1        = 0.5;      % collateral default cost curvature 

par.OMEGAB      = -0.005;   % will be overwritten once model_real is run
par.LMCOST      = 0.05;     % will be overwritten once model_real is run

par.PHICss      = 0.74;     % 1-haircut conventional bond 
par.PHIGss      = 0.74;     % 1-haircut green bond 
par.TAXC        = 0.0;      % tax on conventional output

par.RHO_A    	= 0.95;     % persistence TFP
par.SIGMA_A  	= 0.005;    % standard deviation TFP shock
par.RHO_H       = 0.95;     % persistence haircut 
par.SIGMA_H     = 0.00;     % standard deviation haircut shock
par.RHO_M    	= 0.95;     % persistence risk
par.SIGMA_M  	= 0.0;      % standard deviation risk shock

end