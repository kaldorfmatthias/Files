%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% Computes firm reaction to symmetric haircut change and generates model part of Table 4

clear; clc; close all;

% OPTIONS
opt.perorder        = 2;        % order of perturbation
opt.nirf            = 0;        % length of irf
opt.nperiods        = 0;        % length of simulation
opt.plotirf         = 'N';      % Plot IRF Functions
opt.savefigures     = 'N';      % Save Figures 

% Compare steady states
eval(['dynare model_real.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf) ' -Dnperiods=' num2str(opt.nperiods)])
LMCOST_pos = strmatch('LMcost',M_.endo_names,'exact');
LMCOST = oo_.steady_state(LMCOST_pos);
OMEGAB_pos = strmatch('OmegaB',M_.endo_names,'exact');
OMEGAB = oo_.steady_state(OMEGAB_pos);

%%
eval(['dynare model_real_firmreaction.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf) ' -Dnperiods=' num2str(opt.nperiods)])

set_param_value('LMCOST',LMCOST);
set_param_value('OMEGAB',OMEGAB);    
oo_.steady_state     = steady_(M_,options_,oo_);
[info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
results.M_           = M_;
results.ss           = steady_(M_,options_,oo_);                 
results.means        = oo_.mean;
results.cov          = sqrt(diag(oo_.var));

BC_pos          = strmatch('bc',M_.endo_names,'exact');
FC_pos          = strmatch('Fc',M_.endo_names,'exact');
KC_pos          = strmatch('kc',M_.endo_names,'exact');
LEVC_pos        = strmatch('levc',M_.endo_names,'exact');
MLEVC_pos       = strmatch('marketlevc',M_.endo_names,'exact');
YIELDC_pos      = strmatch('yieldc',M_.endo_names,'exact');

vecYield(1,1) = 10000*results.means(YIELDC_pos);
vecDebt(1,1) = results.means(BC_pos);
vecDefault(1,1) = results.means(FC_pos);
vecCapital(1,1) = results.means(KC_pos);
vecLeverage(1,1) = results.means(LEVC_pos);
vecMLeverage(1,1) = results.means(MLEVC_pos);

set_param_value('PHIGss',0.01);
set_param_value('PHICss',0.01);
oo_.steady_state     = steady_(M_,options_,oo_);
[info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     

results.M_           = M_;
results.ss           = steady_(M_,options_,oo_);                 
results.means        = oo_.mean;
results.cov          = sqrt(diag(oo_.var));

vecYield(2,1) = 10000*results.means(YIELDC_pos);
vecDebt(2,1) = results.means(BC_pos);
vecDefault(2,1) = results.means(FC_pos);
vecCapital(2,1) = results.means(KC_pos);
vecLeverage(2,1) = results.means(LEVC_pos);
vecMLeverage(2,1) = results.means(MLEVC_pos);

fprintf('Spread Increase %1.6f \n',vecYield(1,1)-vecYield(2,1))
fprintf('Debt Increase %1.6f \n',100*(vecDebt(1,1)/vecDebt(2,1))-100)
fprintf('Default Increase %1.6f \n',100*(vecDefault(1,1)/vecDefault(2,1))-100)
fprintf('Capital Increase %1.6f \n',100*(vecCapital(1,1)/vecCapital(2,1))-100)
fprintf('Leverage (Book) Increase %1.6f \n',100*(vecLeverage(1,1)/vecLeverage(2,1))-100)
fprintf('Leverage (Market) Increase %1.6f \n',100*(vecMLeverage(1,1)/vecMLeverage(2,1))-100)
