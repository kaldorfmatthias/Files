%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% Computes news shock in CES extension and generates model part Table E.1

clear; clc; close all;

% OPTIONS
opt.perorder        = 2;        % order of perturbation
opt.nirf            = 20;       % length of irf
opt.nperiods        = 0;        % length of simulation
opt.plotirf         = 'N';      % Plot IRF Functions
opt.savefigures     = 'N';      % Save Figures 

%%
news_horizon        = [8,12,16,20]; % news horizon
effect              = NaN(numel(news_horizon),1); % preallocate results

start_comp          = tic; % Start timing of computation

for j = 1:numel(news_horizon)

    h = news_horizon(j);
    % Dynare
    eval(['dynare model_ces_anticipation.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf)...
        ' -Dnperiods=' num2str(opt.nperiods) ' -Dnnews=' num2str(h)]);
    
    if j == 1
        % check that haircut is 4.5%
        fprintf('Haircut is: %6.3f percent \n',100*(1-(1+oo_.irfs.PHIG_eps_H(9))*0.74))  
    end
    
    % Anticipation effect
    effect(j) = oo_.irfs.greenium_eps_H(1,1);


end

% Computation time
toc(start_comp)

%% Print results
for j = 1:numel(news_horizon)
    h = news_horizon(j);
    fprintf('Announcement effect at horizon %d: %6.5f \n',h,effect(j))
end

