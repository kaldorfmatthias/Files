%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% optimal tax with with CES production function

clear; clc; close all;

% OPTIONS
opt.perorder        = 2;        % order of perturbation
opt.nirf            = 0;       % length of irf
opt.nperiods        = 0;        % length of simulation
opt.plotirf         = 'N';      % Plot IRF Functions
opt.savefigures     = 'N';      % Save Figures 

eval(['dynare model_ces.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf) ' -Dnperiods=' num2str(opt.nperiods)])

%% SOLVE MODEL WITH DIFFERENT TAXES
ntaxc           = 11;
polMat.TAXC     = linspace(0.11,0.13,ntaxc);

% financial side
LEVC_pos        = strmatch('levc',M_.endo_names,'exact');
SPREAD_pos      = strmatch('spreadc',M_.endo_names,'exact');
PREMIUM_pos     = strmatch('premiumc',M_.endo_names,'exact');

% welfare
Y_pos           = strmatch('y',M_.endo_names,'exact');
DEFC_pos        = strmatch('Fc',M_.endo_names,'exact');
DEFG_pos        = strmatch('Fg',M_.endo_names,'exact');
CDCOST_pos      = strmatch('CDcost',M_.endo_names,'exact');
FCOST_pos       = strmatch('Fcost',M_.endo_names,'exact');
LMCOST_pos      = strmatch('LMcost',M_.endo_names,'exact');
PCOST_pos       = strmatch('Pcost',M_.endo_names,'exact');
V_pos           = strmatch('V',M_.endo_names,'exact');

% financial side
vecLEV_M        = nan(ntaxc,1);
vecSPREAD_M     = nan(ntaxc,1);
vecPREMIUM_M    = nan(ntaxc,1);

% welfare
vecWelfgain     = nan(ntaxc,1);
vecWelfare      = nan(ntaxc,1);
vecY_M          = nan(ntaxc,1);
vecFg_M         = nan(ntaxc,1);
vecFc_M         = nan(ntaxc,1);
vecCDcost_M     = nan(ntaxc,1);
vecFcost_M      = nan(ntaxc,1);
vecLMcost_M     = nan(ntaxc,1);
vecPcost_M      = nan(ntaxc,1);

%% loop over different tax parameters

for itaxc = 1:ntaxc
    
    set_param_value('TAXC', polMat.TAXC(1,itaxc));
          
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     

        results.M_           = M_;
        results.ss           = steady_(M_,options_,oo_);                 
        results.means        = oo_.mean;
        results.cov          = sqrt(diag(oo_.var));
        
        % financial side
        vecLEV_M(itaxc,1)              = 100*results.means(LEVC_pos); 
        vecSPREAD_M(itaxc,1)           = results.means(SPREAD_pos);
        vecPREMIUM_M(itaxc,1)          = results.means(PREMIUM_pos);
        
        % welfare   
        vecY_M(itaxc,1)                = results.means(Y_pos);
        vecWelfare(itaxc,1)            = results.means(V_pos);
        vecFc_M(itaxc,1)               = results.means(DEFC_pos);
        vecFg_M(itaxc,1)               = results.means(DEFG_pos);
        vecFcost_M(itaxc,1)            = results.means(FCOST_pos);
        vecLMcost_M(itaxc,1)           = results.means(LMCOST_pos);
        vecCDcost_M(itaxc,1)           = results.means(CDCOST_pos);
        vecPcost_M(itaxc,1)            = results.means(PCOST_pos);
                        
        clc
        fprintf('conv tax parameter  : %1.0f \n',itaxc);

end
    
vecWelfareCE = 100*(-1+exp((1-0.99)*(vecWelfare-vecWelfare(1,1))));

% optimal tax
[indmax] = find(vecWelfare==max(vecWelfare(:)));
fprintf('Optimal tax: %1.6f \n',polMat.TAXC(indmax))
