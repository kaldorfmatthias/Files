%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% computes solution to system of steady state equations for firm reaction, CES extension

function [out,par,check] = fcomputeSS_firmreaction(par)

out.A               = 1;
out.vsigM           = par.VSIGss;                                          
out.muM             = par.MUss;                                            

out.idep            = 1/par.BETA-1;                                         
out.PHIC            = par.PHICss;
out.PHIG            = par.PHIGss;
out.OmegaB          = par.OMEGAB;
out.LMcost          = par.LMCOST;

% guess for mbar_c, mbar_g, bbar
finguess = [0.712697881,0.712697881,0.4 -par.TAXC*(1-par.NU)/par.NU];
options = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-16,'FunctionTolerance',1e-16);
finstar = fsolve(@(x) (fresidSS_firmreaction(x,out,par)),finguess,options);

[valfun,out] = fresidSS_firmreaction(finstar,out,par);

if abs(max(valfun)) > 1e-12
    error('No Fixed Point Found')
end

% Definitions (fin)
out.levc        = out.bc/out.kc;
out.levg        = out.bg/out.kg;
out.marketlevc  = out.qc*out.bc/out.kc;
out.marketlevg  = out.qg*out.bg/out.kg;
out.yieldc      = (1+par.S/out.qc-par.S)^4;
out.yieldg      = (1+par.S/out.qg-par.S)^4;
out.spreadc     = 10000*(out.yieldc - (1+out.idep)^4);
out.spreadg     = 10000*(out.yieldg - (1+out.idep)^4);
out.premiumc    = 10000*(out.yieldc - (1+par.S/(out.qc*(1+out.PHIC*out.OmegaB))-par.S)^4);
out.premiumg    = 10000*(out.yieldg - (1+par.S/(out.qg*(1+out.PHIG*out.OmegaB))-par.S)^4);
out.greenium    = 10000*(out.yieldc - out.yieldg);

% Definitions (macro)
out.bagg    = out.bc + out.bg;
out.ceagg   = out.divc + out.divg;
out.cagg    = out.ceagg + out.c;
out.fagg    = par.NU*out.Fg + (1-par.NU)*out.Fc;
out.iagg    = out.iic + out.iig;
out.kagg    = out.kg + out.kc;
out.lagg    = par.NU*out.marketlevg + (1-par.NU)*out.marketlevc;

% welfare
out.V       = 1/(1-par.BETA) * ( log(out.c) - par.OMEGA_L*out.l^(1+par.GAMMA_L)/(1+par.GAMMA_L) );

% definitions (sectors)
out.shareB  = 100*out.bg/(out.bc+out.bg);
out.shareI  = 100*out.iig/(out.iic+out.iig);
out.shareK  = 100*out.kg/(out.kc+out.kg);
out.shareZ  = 100*out.zg/(out.zc+out.zg);
out.relP    = out.pg/out.pc;

% definitions (log)
out.log_b   = log(out.bagg);
out.log_f   = log(out.fagg);
out.log_i   = log(out.iagg);
out.log_l   = log(out.lagg);
out.log_c   = log(out.c);
out.log_p   = log(out.zc);
out.log_y   = log(out.y);

% Flag if everything went through
check = 0;

end