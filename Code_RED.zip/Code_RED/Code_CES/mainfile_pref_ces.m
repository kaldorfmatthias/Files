%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% Computes optimal preferential treatment for CES-case

clear; clc; close all;

%% OPTIONS
opt.perorder        = 2;        % order of perturbation
opt.nirf            = 0;        % length of irf
opt.nperiods        = 0;        % length of simulation
opt.plotirf         = 'N';      % Plot IRF Functions
opt.savefigures     = 'N';      % Save Figures 

% SOLVE BSELINE
eval(['dynare model_ces.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf) ' -Dnperiods=' num2str(opt.nperiods)])

% POLICY SPACE
npolc           = 21;
npolg           = 21;
polMat.PHICss   = linspace(0.6,1,npolc);
polMat.PHIGss   = linspace(0.6,1,npolg);

KC_pos          = strmatch('kc',M_.endo_names,'exact');
KG_pos          = strmatch('kg',M_.endo_names,'exact');
LEVC_pos        = strmatch('marketlevc',M_.endo_names,'exact');
LEVG_pos        = strmatch('marketlevg',M_.endo_names,'exact');
SPREADC_pos     = strmatch('spreadc',M_.endo_names,'exact');
SPREADG_pos     = strmatch('spreadg',M_.endo_names,'exact');
V_pos           = strmatch('V',M_.endo_names,'exact');

matKC           = nan(npolg,npolc);
matKG           = nan(npolg,npolc);
matLEVC         = nan(npolg,npolc);
matLEVG         = nan(npolg,npolc);
matSPREADC      = nan(npolg,npolc);
matSPREADG      = nan(npolg,npolc);
matWelfare      = nan(npolg,npolc);

% loop over different collateral parameters
for iconv = 1:npolc

PHICss = polMat.PHICss(iconv);
set_param_value('PHICss', polMat.PHICss(1,iconv));
    
for igreen = 1:npolg

        PHIGss = polMat.PHIGss(igreen);
        set_param_value('PHIGss', polMat.PHIGss(1,igreen));
        
        try 
            
        oo_.steady_state            = steady_(M_,options_,oo_);
        [info,oo_,~,M_]             = stoch_simul(M_, options_, oo_, var_list_);     
        vecMean                     = oo_.mean;
        vecCov                      = sqrt(diag(oo_.var));
        
        matKC(igreen,iconv)         = vecMean(KC_pos);
        matKG(igreen,iconv)         = vecMean(KG_pos);
        matLEVC(igreen,iconv)       = vecMean(LEVC_pos);
        matLEVG(igreen,iconv)       = vecMean(LEVG_pos);
        matSPREADC(igreen,iconv)    = vecMean(SPREADC_pos);
        matSPREADG(igreen,iconv)    = vecMean(SPREADG_pos);
        matWelfare(igreen,iconv)    = vecMean(V_pos);
        
        catch
            
        end
        
        clc
        fprintf('green collateral parameter : %1.0f \n',igreen);
        fprintf('conv collateral parameter  : %1.0f \n',iconv);
    
end

end

rowbase = find(polMat.PHIGss==0.74);
colbase = find(polMat.PHICss==0.74);

% optimal policy
[rowopt,colopt] = find(max(matWelfare(:))==matWelfare);
fprintf('Optimal phi_g %1.6f \n',polMat.PHIGss(rowopt))
fprintf('Optimal phi_c %1.6f \n',polMat.PHICss(colopt))

matWelfareCE = 100*(-1+exp((1-0.99)*(matWelfare-matWelfare(rowbase,colbase))));

save('workspace_pref_ces')