function out = momentsModel(results)

M_  = results.M_;
mean = results.mean;
std  = results.std;
auto = results.auto;
var  = results.var;

gdp  = 4*(mean(ismember(M_.endo_names,'y')));
kagg = mean(ismember(M_.endo_names,'kagg')); 
bc   = mean(ismember(M_.endo_names,'bc'));
bg   = mean(ismember(M_.endo_names,'bg'));
qc   = mean(ismember(M_.endo_names,'qc'));
qg   = mean(ismember(M_.endo_names,'qg'));
bagg = qc*bc+qg*bg;

% damage/gdp
vecMoments(1,1) = mean(ismember(M_.endo_names,'Pcost'));
% debt/gdp
vecMoments(2,1) = bagg/gdp; 
% bond spread
vecMoments(3,1) = mean(ismember(M_.endo_names,'spreadc'));
% eligibility premium
vecMoments(4,1) = mean(ismember(M_.endo_names,'premiumc'));
% leverage
vecMoments(5,1) = mean(ismember(M_.endo_names,'levc'));
% capital over GDP
vecMoments(6,1) = kagg/gdp;
% labor
vecMoments(7,1) = mean(ismember(M_.endo_names,'l'));
% default
vecMoments(8,1) = 1-(1-mean(ismember(M_.endo_names,'Fg')))^4;

%%% UNTARGETED
% std spread
vecMoments_non(1,1) = std(ismember(M_.endo_names,'spreadc'));
% std c / std y
vecMoments_non(2,1) = std(ismember(M_.endo_names,'log_c'))/std(ismember(M_.endo_names,'log_y'));
% std I / std y
vecMoments_non(3,1) = std(ismember(M_.endo_names,'log_i'))/std(ismember(M_.endo_names,'log_y'));
% auto y
vecMoments_non(4,1) = auto(ismember(M_.endo_names,'log_y'),ismember(M_.endo_names,'log_y'));
% auto c
vecMoments_non(5,1) = auto(ismember(M_.endo_names,'log_c'),ismember(M_.endo_names,'log_c'));
% auto I
vecMoments_non(6,1) = auto(ismember(M_.endo_names,'log_i'),ismember(M_.endo_names,'log_i'));
% correlation c to y
vecMoments_non(7,1) = var(ismember(M_.endo_names,'log_c'),ismember(M_.endo_names,'log_y'))/(std(ismember(M_.endo_names,'log_c'))*std(ismember(M_.endo_names,'log_y')));
% correlation i to y
vecMoments_non(8,1) = var(ismember(M_.endo_names,'log_i'),ismember(M_.endo_names,'log_y'))/(std(ismember(M_.endo_names,'log_i'))*std(ismember(M_.endo_names,'log_y')));
% correlation leverage to y
vecMoments_non(9,1) = var(ismember(M_.endo_names,'log_l'),ismember(M_.endo_names,'log_y'))/(std(ismember(M_.endo_names,'log_l'))*std(ismember(M_.endo_names,'log_y')));
% correlation default to y
vecMoments_non(10,1) = var(ismember(M_.endo_names,'log_f'),ismember(M_.endo_names,'log_y'))/(std(ismember(M_.endo_names,'log_f'))*std(ismember(M_.endo_names,'log_y')));
% correlation debt issuance to y
vecMoments_non(11,1) = var(ismember(M_.endo_names,'log_b'),ismember(M_.endo_names,'log_y'))/(std(ismember(M_.endo_names,'log_b'))*std(ismember(M_.endo_names,'log_y')));
% correlation pollution issuance to y
vecMoments_non(12,1) = var(ismember(M_.endo_names,'log_p'),ismember(M_.endo_names,'log_y'))/(std(ismember(M_.endo_names,'log_p'))*std(ismember(M_.endo_names,'log_y')));

% DATA
vecMomentsData     = [0.1; 0.8; 100; -11; 0.4; 2.1; 0.3; 0.01];
vecMomentsData_non = ["50-100"; 0.7; 3.8; 0.9; 0.8; 0.8; 0.6; 0.7; -0.3; -0.55; 0.65; 0.30];

varNAMES  = ["Model","Data"];
rowNAMES  = ["Damage/GDP","Debt/GDP","Spread","Eligibility Premium","Leverage","Investment","Labor","Default Rate"];
out.Ttarget = table(vecMoments,vecMomentsData,'VariableNames',varNAMES,'RowNames',rowNAMES);  

fprintf('____________________________________________________\n');
fprintf('Targeted Moments\n');
disp(out.Ttarget)

varNAMES  = ["Model","Data","Source"];
rowNAMES  = ["Std Spread","Std C/ Std Y","Std I/ Std Y","Auto Y","Auto C",...
    "Auto I","Corr Y-C","Corr Y-I","Corr Y-Leverage",...
    "Corr Y-Default","Corr Y-B","Corr Y-P"];
rowSOURCE  = ["Gilchrist Zakrajsek 2012","Own","Own","Own","Own",...
    "Own","Own","Own","Kuehn Schmid 2014","Kuehn Schmid 2014","Jungherr Schott 2022","Doda 2014"];
out.Ttarget = table(vecMoments_non,vecMomentsData_non,rowSOURCE','VariableNames',varNAMES,'RowNames',rowNAMES);  

fprintf('____________________________________________________\n');
fprintf('Untargeted Moments\n');
disp(out.Ttarget)


end