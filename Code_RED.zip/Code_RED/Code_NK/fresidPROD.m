%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% residuals of real side, New Keynsian extension

function [resid,out] = fresidPROD(prodguess,out,par)

out.kc      = prodguess(1);
out.kg      = prodguess(2);
out.l       = prodguess(3); 
out.c       = prodguess(4);

% supply
out.w       = par.OMEGA_L * out.l^(par.GAMMA_L) / ( out.c^(-par.GAMMA_C) );

out.bc      = out.mbarc*(1-par.TAXC)*out.pc*out.kc/par.S;
out.bg      = out.mbarg*(1-out.TAXG)*out.pg*out.kg/par.S;
out.iic     = par.DELTAK*out.kc;
out.iig     = par.DELTAK*out.kg;

out.divc    = (1-out.Gc)*out.pc*(1-par.TAXC)*out.kc - (1-out.Fc)*par.S*out.bc ...
                - out.iic + out.qc*out.bc*(1-(1-par.S)/out.pii);
out.divg    = (1-out.Gg)*out.pg*(1-out.TAXG)*out.kg - (1-out.Fg)*par.S*out.bg ...
                - out.iig + out.qg*out.bg*(1-(1-par.S)/out.pii);
            
out.zc      = prodguess(1);
out.zg      = prodguess(2);
out.zcstock = out.zc / (1 - par.DELTAZ);
out.Pcost   = 1 - exp(-par.GAMMA_P*out.zcstock);
out.z       = out.zg^par.NU*out.zc^(1-par.NU);

% default cost
out.Fcost   = par.VARPHI*(out.Fc*out.bc+out.Fg*out.bg);

% eligibility premium from bank FOC
bbar1       = out.PHIC*out.qc*out.bc + out.PHIG*out.qg*out.bg;
out.OmegaB1 = - par.L1 * bbar1^(par.L2-1);
out.LMcost  = par.L0 - par.L1/par.L2 * bbar1^par.L2;

% collateral default cost
out.Fbar    = out.PHIG*out.qg*out.bg*out.Fg + out.PHIC*out.qc*out.bc*out.Fc;
out.CDcost  = par.ETA0/par.ETA1*out.Fbar^par.ETA1;

out.y       = out.c + out.divc + out.divg + out.iic + out.iig + out.Fcost + out.CDcost + out.LMcost;
out.Rcost   = 0;

% demand
zcd         = (1/out.pc) * par.THETAC * out.mc * out.y; 
zgd         = (1/out.pg) * par.THETAG * out.mc * out.y; 
wd          = (1 - par.THETA) * out.mc * out.y / out.l;

% supply of final good
ys          = (1-out.Pcost) * out.z^(par.THETA) * out.l^(1-par.THETA);

% wholesale goods price and deposits
out.pz      = par.THETA * out.mc * out.y / out.z;

%% Residuals
resid(1)    = out.zc - zcd;  % excess demand conventional good
resid(2)    = out.zg - zgd;  % excess demand green good
resid(3)    = out.w - wd;  % excess demand labor
resid(4)    = out.y - ys; % excess demand final good

end
