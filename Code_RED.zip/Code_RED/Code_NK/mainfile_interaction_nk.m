%**************************************************************************
%  The Preferential Treatment of Green Bonds
%  (C) Giovanardi, Kaldorf, Radke, Wicknig (2023)
%**************************************************************************
% Computes globally optimal policy in Newy Keynesian extension and generates Table E.4

clear; clc; close all;

% OPTIONS
opt.perorder        = 2;        % order of perturbation
opt.nirf            = 0;        % length of irf
opt.nperiods        = 0;        % length of simulation
opt.plotirf         = 'N';      % Plot IRF Functions
opt.savefigures     = 'N';      % Save Figures 

% SOLVE MODEL
eval(['dynare model_nk.mod noclearall -Dperorder=' num2str(opt.perorder) ' -Dnirf=' num2str(opt.nirf) ' -Dnperiods=' num2str(opt.nperiods)])
results.baseline.M_   = M_;
results.baseline.ss   = steady_(M_,options_,oo_);
results.baseline.mean = oo_.mean;
results.baseline.cov  = sqrt(diag(oo_.var));

%% GRID (SPECIFIED IN TERMS OF 1-HAIRCUT)
nphic           = 27;
nphig           = 27;
ntax            = 11;
polMat.PHICss   = linspace(0.7,0.96,nphic);
polMat.PHIGss   = linspace(0.7,0.96,nphig);
polMat.TAXC     = linspace(0.0,0.101,ntax);

polMat.PHIGss(26) = 0.955;

% financial
BC_pos          = strmatch('bc',M_.endo_names,'exact');
BG_pos          = strmatch('bg',M_.endo_names,'exact');
FC_pos          = strmatch('Fc',M_.endo_names,'exact');
FG_pos          = strmatch('Fg',M_.endo_names,'exact');
KC_pos          = strmatch('kc',M_.endo_names,'exact');
KG_pos          = strmatch('kg',M_.endo_names,'exact');
LEVC_pos        = strmatch('marketlevc',M_.endo_names,'exact');
LEVG_pos        = strmatch('marketlevg',M_.endo_names,'exact');
SPREADC_pos     = strmatch('spreadc',M_.endo_names,'exact');
SPREADG_pos     = strmatch('spreadg',M_.endo_names,'exact');
PREMIUMC_pos    = strmatch('premiumc',M_.endo_names,'exact');
PREMIUMG_pos    = strmatch('premiumg',M_.endo_names,'exact');
% sectoral
BSHARE_pos      = strmatch('shareB',M_.endo_names,'exact');
KSHARE_pos      = strmatch('shareK',M_.endo_names,'exact');
RELP_pos        = strmatch('relP',M_.endo_names,'exact');
% welfare
FCOST_pos       = strmatch('Fcost',M_.endo_names,'exact');
LMCOST_pos      = strmatch('LMcost',M_.endo_names,'exact');
CDCOST_pos      = strmatch('CDcost',M_.endo_names,'exact');
PCOST_pos       = strmatch('Pcost',M_.endo_names,'exact');
RCOST_pos       = strmatch('Rcost',M_.endo_names,'exact');
V_pos           = strmatch('V',M_.endo_names,'exact');
Y_pos           = strmatch('y',M_.endo_names,'exact');

% financial
vecBC_M         = nan(nphig,nphic,ntax);
vecBG_M         = nan(nphig,nphic,ntax);
vecFC_M         = nan(nphig,nphic,ntax);
vecFG_M         = nan(nphig,nphic,ntax);
vecKC_M         = nan(nphig,nphic,ntax);
vecKG_M         = nan(nphig,nphic,ntax);
vecLEVC_M       = nan(nphig,nphic,ntax);
vecLEVG_M       = nan(nphig,nphic,ntax);
vecSPREADC_M    = nan(nphig,nphic,ntax);
vecSPREADG_M    = nan(nphig,nphic,ntax);
vecPREMIUMC_M   = nan(nphig,nphic,ntax);
vecPREMIUMG_M   = nan(nphig,nphic,ntax);
% sectors
vecGreenB_M     = nan(nphig,nphic,ntax);
vecGreenK_M     = nan(nphig,nphic,ntax);
vecGreenP_M     = nan(nphig,nphic,ntax);
% welfare
vecWelfare      = nan(nphig,nphic,ntax);
vecFcost_M      = nan(nphig,nphic,ntax);
vecCDcost_M     = nan(nphig,nphic,ntax);
vecLMcost_M     = nan(nphig,nphic,ntax);
vecPcost_M      = nan(nphig,nphic,ntax);
vecRcost_M      = nan(nphig,nphic,ntax);
vecY_M          = nan(nphig,nphic,ntax);

%% loop over different collateral parameters

for iconv = 1:nphic

PHIC = polMat.PHICss(iconv);
set_param_value('PHICss', PHIC);
    
for igreen = 1:nphig

PHIG = polMat.PHIGss(igreen);
set_param_value('PHIGss', PHIG);

    for itax = 1:ntax

        TAXC = polMat.TAXC(itax);
        set_param_value('TAXC', TAXC);

       % try
        oo_.steady_state            = steady_(M_,options_,oo_);
        [info,oo_,~,M_]             = stoch_simul(M_, options_, oo_, var_list_);     
        vecMean                     = oo_.mean;
        vecCov                      = sqrt(diag(oo_.var));
        
        % financial
        vecBC_M(igreen,iconv,itax)               = vecMean(BC_pos);
        vecBG_M(igreen,iconv,itax)               = vecMean(BG_pos);
        vecFC_M(igreen,iconv,itax)               = vecMean(FC_pos);
        vecFG_M(igreen,iconv,itax)               = vecMean(FG_pos);
        vecKC_M(igreen,iconv,itax)               = vecMean(KC_pos);
        vecKG_M(igreen,iconv,itax)               = vecMean(KG_pos);
        vecLEVC_M(igreen,iconv,itax)             = vecMean(LEVC_pos);    
        vecLEVG_M(igreen,iconv,itax)             = vecMean(LEVG_pos);
        vecSPREADC_M(igreen,iconv,itax)          = vecMean(SPREADC_pos);
        vecSPREADG_M(igreen,iconv,itax)          = vecMean(SPREADG_pos);
        vecPREMIUMC_M(igreen,iconv,itax)         = vecMean(PREMIUMC_pos);
        vecPREMIUMG_M(igreen,iconv,itax)         = vecMean(PREMIUMG_pos);  

        % sectors
        vecGreenB_M(igreen,iconv,itax)           = vecMean(BSHARE_pos);
        vecGreenK_M(igreen,iconv,itax)           = vecMean(KSHARE_pos);
        vecGreenP_M(igreen,iconv,itax)           = vecMean(RELP_pos);
        
        % welfare      
        vecWelfare(igreen,iconv,itax)            = vecMean(V_pos);        
        vecFcost_M(igreen,iconv,itax)            = vecMean(FCOST_pos);
        vecLMcost_M(igreen,iconv,itax)           = vecMean(LMCOST_pos);
        vecCDcost_M(igreen,iconv,itax)           = vecMean(CDCOST_pos);
        vecPcost_M(igreen,iconv,itax)            = vecMean(PCOST_pos);
        vecRcost_M(igreen,iconv,itax)            = vecMean(RCOST_pos);
        vecY_M(igreen,iconv,itax)                = vecMean(Y_pos);
        
       % catch
            
       % end
        
        clc
        fprintf('green collateral parameter : %1.0f \n',igreen);
        fprintf('conv collateral parameter  : %1.0f \n',iconv);
        fprintf('tax parameter              : %1.0f \n',itax);

    end
    
end

end

%% optimal collateral policy
rowstrong = 26;
rowbase = find(polMat.PHIGss==0.74);
colbase = find(polMat.PHICss==0.74);

% optimal coll
vecWelfare_Coll = vecWelfare(:,:,1);
[rowopt,colopt] = find(max(vecWelfare_Coll(:))==vecWelfare_Coll);
fprintf('Optimal phi_g %1.6f \n',polMat.PHIGss(rowopt))
fprintf('Optimal phi_c %1.6f \n',polMat.PHICss(colopt))
fprintf('Optimal Haircut Gap %1.6f \n',polMat.PHIGss(rowopt)-polMat.PHICss(colopt))

% optimal tax
vecWelfare_Tax = vecWelfare(rowbase,colbase,:);
taxopt = find(vecWelfare_Tax(:)==max(vecWelfare_Tax(:)));
fprintf('Optimal tax %1.6f \n',polMat.TAXC(taxopt))

vecWelfareCE = 100*(-1+exp((1-0.99)*(vecWelfare-vecWelfare(rowbase,colbase))));

%% summarize results
matRes = nan(14,4);
vecTableNames = {'Welfare','Premium C','Premium G','Spread C','Spread G','Leverage C','Leverage G',...
    'Capital C','Capital G','Green Capital Share','GDP','Default Cost','LM Cost','Rotemberg Cost','Pollution Cost'};

matRes(1,1) = vecWelfareCE(rowbase,colbase,1); 
matRes(1,2) = vecWelfareCE(rowstrong,colbase,1); 
matRes(1,3) = vecWelfareCE(rowopt,colopt,1); 
matRes(1,4) = vecWelfareCE(rowbase,colbase,taxopt); 

matRes(2,1) = vecPREMIUMC_M(rowbase,colbase,1); 
matRes(2,2) = vecPREMIUMC_M(rowstrong,colbase,1); 
matRes(2,3) = vecPREMIUMC_M(rowopt,colopt,1); 
matRes(2,4) = vecPREMIUMC_M(rowbase,colbase,taxopt); 

matRes(3,1) = vecPREMIUMG_M(rowbase,colbase,1); 
matRes(3,2) = vecPREMIUMG_M(rowstrong,colbase,1); 
matRes(3,3) = vecPREMIUMG_M(rowopt,colopt,1); 
matRes(3,4) = vecPREMIUMG_M(rowbase,colbase,taxopt); 

matRes(4,1) = vecSPREADC_M(rowbase,colbase,1); 
matRes(4,2) = vecSPREADC_M(rowstrong,colbase,1);
matRes(4,3) = vecSPREADC_M(rowopt,colopt,1); 
matRes(4,4) = vecSPREADC_M(rowbase,colbase,taxopt); 

matRes(5,1) = vecSPREADG_M(rowbase,colbase,1); 
matRes(5,2) = vecSPREADG_M(rowstrong,colbase,1); 
matRes(5,3) = vecSPREADG_M(rowopt,colopt,1); 
matRes(5,4) = vecSPREADG_M(rowbase,colbase,taxopt); 

matRes(6,1) = vecLEVC_M(rowbase,colbase,1); 
matRes(6,2) = vecLEVC_M(rowstrong,colbase,1); 
matRes(6,3) = vecLEVC_M(rowopt,colopt,1); 
matRes(6,4) = vecLEVC_M(rowbase,colbase,taxopt); 

matRes(7,1) = vecLEVG_M(rowbase,colbase,1); 
matRes(7,2) = vecLEVG_M(rowstrong,colbase,1); 
matRes(7,3) = vecLEVG_M(rowopt,colopt,1); 
matRes(7,4) = vecLEVG_M(rowbase,colbase,taxopt); 

matRes(8,1) = vecKC_M(rowbase,colbase,1); 
matRes(8,2) = vecKC_M(rowstrong,colbase,1); 
matRes(8,3) = vecKC_M(rowopt,colopt,1); 
matRes(8,4) = vecKC_M(rowbase,colbase,taxopt); 

matRes(9,1) = vecKG_M(rowbase,colbase,1); 
matRes(9,2) = vecKG_M(rowstrong,colbase,1); 
matRes(9,3) = vecKG_M(rowopt,colopt,1); 
matRes(9,4) = vecKG_M(rowbase,colbase,taxopt); 

matRes(10,1) = vecGreenK_M(rowbase,colbase,1); 
matRes(10,2) = vecGreenK_M(rowstrong,colbase,1); 
matRes(10,3) = vecGreenK_M(rowopt,colopt,1); 
matRes(10,4) = vecGreenK_M(rowbase,colbase,taxopt); 

matRes(11,1) = vecY_M(rowbase,colbase,1); 
matRes(11,2) = vecY_M(rowstrong,colbase,1); 
matRes(11,3) = vecY_M(rowopt,colopt,1); 
matRes(11,4) = vecY_M(rowbase,colbase,taxopt); 

matRes(12,1) = (vecFcost_M(rowbase,colbase,1)+vecCDcost_M(rowbase,colbase,1))/vecY_M(rowbase,colbase,1);
matRes(12,2) = (vecFcost_M(rowstrong,colbase,1)+vecCDcost_M(rowstrong,colbase,1))/vecY_M(rowstrong,colbase,1);
matRes(12,3) = (vecFcost_M(rowopt,colopt,1)+vecCDcost_M(rowopt,colopt,1))/vecY_M(rowopt,colopt,1); 
matRes(12,4) = (vecFcost_M(rowbase,colbase,taxopt)+vecCDcost_M(rowbase,colbase,taxopt))/vecY_M(rowbase,colbase,taxopt); 

matRes(13,1) = vecLMcost_M(rowbase,colbase,1)/vecY_M(rowbase,colbase,1); 
matRes(13,2) = vecLMcost_M(rowstrong,colbase,1)/vecY_M(rowstrong,colbase,1); 
matRes(13,3) = vecLMcost_M(rowopt,colopt,1)/vecY_M(rowopt,colopt,1); 
matRes(13,4) = vecLMcost_M(rowbase,colbase,taxopt)/vecY_M(rowbase,colbase,taxopt); 

matRes(14,1) = vecRcost_M(rowbase,colbase,1)*100; 
matRes(14,2) = vecRcost_M(rowstrong,colbase,1)*100; 
matRes(14,3) = vecRcost_M(rowopt,colopt,1)*100;
matRes(14,4) = vecRcost_M(rowbase,colbase,taxopt)*100;

matRes(15,1) = vecPcost_M(rowbase,colbase,1)*100; 
matRes(15,2) = vecPcost_M(rowstrong,colbase,1)*100; 
matRes(15,3) = vecPcost_M(rowopt,colopt,1)*100;
matRes(15,4) = vecPcost_M(rowbase,colbase,taxopt)*100;

matRes(6,2:end) = 100*matRes(6,2:end)/matRes(6,1)-100;
matRes(7,2:end) = 100*matRes(7,2:end)/matRes(7,1)-100;
matRes(8,2:end) = 100*matRes(8,2:end)/matRes(8,1)-100;
matRes(9,2:end) = 100*matRes(9,2:end)/matRes(9,1)-100;
matRes(11,2:end) = 100*matRes(11,2:end)/matRes(11,1)-100;
matRes(12,2:end) = 100*matRes(12,2:end)/matRes(12,1)-100;
matRes(13,2:end) = 100*matRes(13,2:end)/matRes(13,1)-100;
matRes(14,2:end) = 100*matRes(14,2:end)/matRes(14,1)-100;
matRes(15,2:end) = 100*matRes(15,2:end)/matRes(15,1)-100;
table(vecTableNames',matRes(:,2:end))

%%
save('workspace_interaction_nk')