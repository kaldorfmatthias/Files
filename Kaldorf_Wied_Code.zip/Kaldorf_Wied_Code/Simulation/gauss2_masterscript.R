###########################################################################################################################
# Replication files to Kaldorf & Wied (2020) 
# "Testing Constant Cross-Sectional Dependence with Time-Varying Marginal Distributions in Parametric Models"
# For comments and questions please contact kaldorf@wiso.uni-koeln.de
# This script computes all empirical applications
###########################################################################################################################

# specify path
rootpath = getwd()
vecR=seq(-0.1,0.9,0.1)
vecS=c(1,1.5,2,2.5,3)
# critical values Bessel process: 8.68 for dim=1, 11.72 for dim=2, 14.15 for dim=3, 27.03 for dim=10
# critical values Brownian Bridge: 1.358 for dim=1, 1.584 for dim=2, 1.74709 for dim=3, 2.45917 for dim=10

# gauss, m=2, n=100
# size
source(paste(rootpath,"gauss2_n0100_size.R",sep=""))
for(k in c(1:5)){
  s=vecS[k]
  print(paste("computing scenario set ",s,sep=""))
  start.time=Sys.time()
  matRes=gauss2_n0100_size(s)
  end.time=Sys.time()
  print(end.time-start.time)
  write.table(matRes,paste(rootpath,"Simulation/gauss2_n0100_s",s,".csv",sep=""),sep=";",dec=",",col.names=FALSE)
}

matResult=matrix(nrow=13,ncol=5); 
for(k in c(1:5)){
  s=vecS[k] 
  # target arrays for each scenario
  vecFluct.stat.d=vector(l=1000)
  vecFluct.stat.boot=vector(l=1000)
  vecFluct.lambda.d=vector(l=1000)
  vecSuplr.stat.d=vector(l=1000)
  vecSuplr.stat.boot=vector(l=1000)
  vecSuplr.lambda.d=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n0100_s",s,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.d[i]=input[1,i]
    vecFluct.stat.boot[i]=input[2,i]
    vecFluct.lambda.d[i]=input[5,i]
    vecSuplr.stat.d[i]=input[8,i]
    vecSuplr.stat.boot[i]=input[9,i]
    vecSuplr.lambda.d[i]=input[12,i]
  }
  matResult[1,k]=s
  matResult[2,k]=mean(vecFluct.stat.boot<0.05,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.d>1.358,na.rm=TRUE) 
  matResult[4,k]=mean(vecFluct.lambda.d,na.rm=TRUE)
  matResult[5,k]=sd(vecFluct.lambda.d,na.rm=TRUE)
  matResult[6,k]=matResult[4,k]-70
  matResult[7,k]=(matResult[6,k]^2+matResult[5,k]^2)^0.5
  matResult[8,k]=mean(vecSuplr.stat.boot<0.05,na.rm=TRUE)
  matResult[9,k]=mean(vecSuplr.stat.d>8.68,na.rm=TRUE)
  matResult[10,k]=mean(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[11,k]=sd(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[12,k]=matResult[10,k]-70
  matResult[13,k]=(matResult[11,k]^2+matResult[12,k]^2)^0.5
}

rownames(matResult)=c("s","fluct.stat.boot","fluct.stat.d","fluct.lambda.d","fluct.lambda.d.se","fluct.lambda.d.bias","fluct.lambda.d.rmse",
                   "suplr.stat.boot","suplr.stat.d","suplr.lambda.d","suplr.lambda.d.se","suplr.lambda.d.bias","suplr.lambda.d.rmse")

write.table(matResult,paste(rootpath,"Results/gauss2_n0100_size.csv",sep=""),sep=";",dec=",",col.names=FALSE)

matResult=matrix(nrow=5,ncol=5); 
for(k in c(1:5)){
  s=vecS[k] 
  # target arrays for each scenario
  vecFluct.stat.1=vector(l=1000)
  vecFluct.stat.2=vector(l=1000)
  vecSuplr.stat.1=vector(l=1000)
  vecSuplr.stat.2=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n0100_s",s,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.1[i]=input[3,i]
    vecFluct.stat.2[i]=input[4,i]
    vecSuplr.stat.1[i]=input[10,i]
    vecSuplr.stat.2[i]=input[11,i]
  }
  matResult[1,k]=s
  matResult[2,k]=mean(vecFluct.stat.1>1.584,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.2>1.584,na.rm=TRUE) 
  matResult[4,k]=mean(vecSuplr.stat.1>11.72,na.rm=TRUE)
  matResult[5,k]=mean(vecSuplr.stat.2>11.72,na.rm=TRUE)
}

rownames(matResult)=c("s","fluct.stat.1","fluct.stat.2","suplr.stat.1","suplr.stat.2")
write.table(matResult,paste(rootpath,"Results/gauss2_n0100_margin.csv",sep=""),sep=";",dec=",",col.names=FALSE)

# power
source(paste(rootpath,"gauss2_n0100_power.R",sep=""))
for(k in c(1:11)){
  r=vecR[k]
  print(paste("computing scenario set ",r,sep=""))
  start.time=Sys.time()
  matRes=gauss2_n0100_power(r)
  end.time=Sys.time()
  print(end.time-start.time)
  write.table(matRes,paste(rootpath,"Simulation/gauss2_n0100_r",r,".csv",sep=""),sep=";",dec=",",col.names=FALSE)
}

matResult=matrix(nrow=13,ncol=11); 
for(k in c(1:11)){
  r=vecR[k] 
  # target arrays for each scenario
  vecFluct.stat.d=vector(l=1000)
  vecFluct.stat.boot=vector(l=1000)
  vecFluct.lambda.d=vector(l=1000)
  vecSuplr.stat.d=vector(l=1000)
  vecSuplr.stat.boot=vector(l=1000)
  vecSuplr.lambda.d=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n0100_r",r,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.d[i]=input[1,i]
    vecFluct.stat.boot[i]=input[2,i]
    vecFluct.lambda.d[i]=input[5,i]
    vecSuplr.stat.d[i]=input[8,i]
    vecSuplr.stat.boot[i]=input[9,i]
    vecSuplr.lambda.d[i]=input[12,i]
  }
  matResult[1,k]=r
  matResult[2,k]=mean(vecFluct.stat.boot<0.05,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.d>1.358,na.rm=TRUE) 
  matResult[4,k]=mean(vecFluct.lambda.d,na.rm=TRUE)
  matResult[5,k]=sd(vecFluct.lambda.d,na.rm=TRUE)
  matResult[6,k]=matResult[4,k]-70
  matResult[7,k]=(matResult[6,k]^2+matResult[5,k]^2)^0.5
  matResult[8,k]=mean(vecSuplr.stat.boot<0.05,na.rm=TRUE)
  matResult[9,k]=mean(vecSuplr.stat.d>8.68,na.rm=TRUE) 
  matResult[10,k]=mean(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[11,k]=sd(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[12,k]=matResult[10,k]-70
  matResult[13,k]=(matResult[11,k]^2+matResult[12,k]^2)^0.5
}
rownames(matResult)=c("r","fluct.stat.boot","fluct.stat.d","fluct.lambda.d","fluct.lambda.d.se","fluct.lambda.d.bias","fluct.lambda.d.rmse",
                      "suplr.stat.boot","suplr.stat.d","suplr.lambda.d","suplr.lambda.d.se","suplr.lambda.d.bias","suplr.lambda.d.rmse")
write.table(matResult,paste(rootpath,"Results/gauss2_n0100_power.csv",sep=""),sep=";",dec=",",col.names=FALSE)

# plot
pdf(paste(rootpath,"Results/gauss2_n0100_power.pdf",sep=""),width=10,height=6)
plot(matResult[3,],x=vecR,type="o",col="red",pch=19,lty=2,ylim=c(0,1),xlab="Correlation for t > 70",ylab="rejection rate")
par(new=TRUE)
plot(matResult[2,],x=vecR,type="o",col="red",pch=19,lty=1,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
plot(matResult[9,],x=vecR,type="o",col="blue",pch=19,lty=2,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
plot(matResult[8,],x=vecR,type="o",col="blue",pch=19,lty=1,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
grid(lty=2,col="grey"); abline(h=0.05,lty="solid",col="grey");
legend("top",bg="white",legend=c("fluct, asym.","fluct, boot.","sup-lr, asym.","sup-lr, boot."),lty=c(2,1,2,1),col=c("red","red","blue","blue"))
dev.off()

#############################################################################################################################
# gauss, m=2, n=500
# size
source(paste(rootpath,"gauss2_n0500_size.R",sep=""))
for(k in c(1:5)){
  s=vecS[k]
  print(paste("computing scenario set ",s,sep=""))
  start.time=Sys.time()
  matRes=gauss2_n0500_size(s)
  end.time=Sys.time()
  print(end.time-start.time)
  write.table(matRes,paste(rootpath,"Simulation/gauss2_n0500_s",s,".csv",sep=""),sep=";",dec=",",col.names=FALSE)
}

matResult=matrix(nrow=13,ncol=5); 
for(k in c(1:5)){
  s=vecS[k] 
  # target arrays for each scenario
  vecFluct.stat.d=vector(l=1000)
  vecFluct.stat.boot=vector(l=1000)
  vecFluct.lambda.d=vector(l=1000)
  vecSuplr.stat.d=vector(l=1000)
  vecSuplr.stat.boot=vector(l=1000)
  vecSuplr.lambda.d=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n0500_s",s,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.d[i]=input[1,i]
    vecFluct.stat.boot[i]=input[2,i]
    vecFluct.lambda.d[i]=input[5,i]
    vecSuplr.stat.d[i]=input[8,i]
    vecSuplr.stat.boot[i]=input[9,i]
    vecSuplr.lambda.d[i]=input[12,i]
  }
  matResult[1,k]=s
  matResult[2,k]=mean(vecFluct.stat.boot<0.05,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.d>1.358,na.rm=TRUE) 
  matResult[4,k]=mean(vecFluct.lambda.d,na.rm=TRUE)
  matResult[5,k]=sd(vecFluct.lambda.d,na.rm=TRUE)
  matResult[6,k]=matResult[4,k]-70
  matResult[7,k]=(matResult[6,k]^2+matResult[5,k]^2)^0.5
  matResult[8,k]=mean(vecSuplr.stat.boot<0.05,na.rm=TRUE)
  matResult[9,k]=mean(vecSuplr.stat.d>8.68,na.rm=TRUE) 
  matResult[10,k]=mean(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[11,k]=sd(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[12,k]=matResult[10,k]-70
  matResult[13,k]=(matResult[11,k]^2+matResult[12,k]^2)^0.5
}

rownames(matResult)=c("s","fluct.stat.boot","fluct.stat.d","fluct.lambda.d","fluct.lambda.d.se","fluct.lambda.d.bias","fluct.lambda.d.rmse",
                      "suplr.stat.boot","suplr.stat.d","suplr.lambda.d","suplr.lambda.d.se","suplr.lambda.d.bias","suplr.lambda.d.rmse")
write.table(matResult,paste(rootpath,"Results/gauss2_n0500_size.csv",sep=""),sep=";",dec=",",col.names=FALSE)

matResult=matrix(nrow=5,ncol=5); 
for(k in c(1:5)){
  s=vecS[k] 
  # target arrays for each scenario
  vecFluct.stat.1=vector(l=1000)
  vecFluct.stat.2=vector(l=1000)
  vecSuplr.stat.1=vector(l=1000)
  vecSuplr.stat.2=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n0500_s",s,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.1[i]=input[3,i]
    vecFluct.stat.2[i]=input[4,i]
    vecSuplr.stat.1[i]=input[10,i]
    vecSuplr.stat.2[i]=input[11,i]
  }
  matResult[1,k]=s
  matResult[2,k]=mean(vecFluct.stat.1>1.584,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.2>1.584,na.rm=TRUE) 
  matResult[4,k]=mean(vecSuplr.stat.1>11.72,na.rm=TRUE)
  matResult[5,k]=mean(vecSuplr.stat.2>11.72,na.rm=TRUE)
}

rownames(matResult)=c("s","fluct.stat.1","fluct.stat.2","suplr.stat.1","suplr.stat.2")
write.table(matResult,paste(rootpath,"Results/gauss2_n0500_margin.csv",sep=""),sep=";",dec=",",col.names=FALSE)

# power
source(paste(rootpath,"gauss2_n0500_power.R",sep=""))
for(k in c(1:11)){
  r=vecR[k]
  print(paste("computing scenario set ",r,sep=""))
  start.time=Sys.time()
  matRes=gauss2_n0500_power(r)
  end.time=Sys.time()
  print(end.time-start.time)
  write.table(matRes,paste(rootpath,"Simulation/gauss2_n0500_r",r,".csv",sep=""),sep=";",dec=",",col.names=FALSE)
}

matResult=matrix(nrow=13,ncol=11); 
for(k in c(1:11)){
  r=vecR[k] 
  # target arrays for each scenario
  vecFluct.stat.d=vector(l=1000)
  vecFluct.stat.boot=vector(l=1000)
  vecFluct.lambda.d=vector(l=1000)
  vecSuplr.stat.d=vector(l=1000)
  vecSuplr.stat.boot=vector(l=1000)
  vecSuplr.lambda.d=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n0500_r",r,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.d[i]=input[1,i]
    vecFluct.stat.boot[i]=input[2,i]
    vecFluct.lambda.d[i]=input[5,i]
    vecSuplr.stat.d[i]=input[8,i]
    vecSuplr.stat.boot[i]=input[9,i]
    vecSuplr.lambda.d[i]=input[12,i]
  }
  matResult[1,k]=r
  matResult[2,k]=mean(vecFluct.stat.boot<0.05,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.d>1.358,na.rm=TRUE)
  matResult[4,k]=mean(vecFluct.lambda.d,na.rm=TRUE)
  matResult[5,k]=sd(vecFluct.lambda.d,na.rm=TRUE)
  matResult[6,k]=matResult[4,k]-350
  matResult[7,k]=(matResult[6,k]^2+matResult[5,k]^2)^0.5
  matResult[8,k]=mean(vecSuplr.stat.boot<0.05,na.rm=TRUE)
  matResult[9,k]=mean(vecSuplr.stat.d>8.68,na.rm=TRUE) 
  matResult[10,k]=mean(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[11,k]=sd(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[12,k]=matResult[10,k]-350
  matResult[13,k]=(matResult[11,k]^2+matResult[12,k]^2)^0.5
}
rownames(matResult)=c("r","fluct.stat.boot","fluct.stat.d","fluct.lambda.d","fluct.lambda.d.se","fluct.lambda.d.bias","fluct.lambda.d.rmse",
                      "suplr.stat.boot","suplr.stat.d","suplr.lambda.d","suplr.lambda.d.se","suplr.lambda.d.bias","suplr.lambda.d.rmse")
write.table(matResult,paste(rootpath,"Results/gauss2_n0500_power.csv",sep=""),sep=";",dec=",",col.names=FALSE)

# plot
pdf(paste(rootpath,"Results/gauss2_n0500_power.pdf",sep=""),width=10,height=6)
plot(matResult[3,],x=vecR,type="o",col="red",pch=19,lty=2,ylim=c(0,1),xlab="Correlation for t > 350",ylab="rejection rate")
par(new=TRUE)
plot(matResult[2,],x=vecR,type="o",col="red",pch=19,lty=1,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
plot(matResult[9,],x=vecR,type="o",col="blue",pch=19,lty=2,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
plot(matResult[8,],x=vecR,type="o",col="blue",pch=19,lty=1,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
grid(lty=2,col="grey"); abline(h=0.05,lty="solid",col="grey");
legend("top",bg="white",legend=c("fluct, asym.","fluct, boot.","sup-lr, asym.","sup-lr, boot."),lty=c(2,1,2,1),col=c("red","red","blue","blue"))
dev.off()

#############################################################################################################################
# gauss, m=2, n=1500
# size
source(paste(rootpath,"gauss2_n1500_size.R",sep=""))
for(k in c(1:5)){
  s=vecS[k]
  print(paste("computing scenario set ",s,sep=""))
  start.time=Sys.time()
  matRes=gauss2_n1500_size(s)
  end.time=Sys.time()
  print(end.time-start.time)
  write.table(matRes,paste(rootpath,"Simulation/gauss2_n1500_s",s,".csv",sep=""),sep=";",dec=",",col.names=FALSE)
}

matResult=matrix(nrow=13,ncol=5); 
for(k in c(1:5)){
  s=vecS[k] 
  # target arrays for each scenario
  vecFluct.stat.d=vector(l=1000)
  vecFluct.stat.boot=vector(l=1000)
  vecFluct.lambda.d=vector(l=1000)
  vecSuplr.stat.d=vector(l=1000)
  vecSuplr.stat.boot=vector(l=1000)
  vecSuplr.lambda.d=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n1500_s",s,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.d[i]=input[1,i]
    vecFluct.stat.boot[i]=input[2,i]
    vecFluct.lambda.d[i]=input[5,i]
    vecSuplr.stat.d[i]=input[8,i]
    vecSuplr.stat.boot[i]=input[9,i]
    vecSuplr.lambda.d[i]=input[12,i]
  }
  matResult[1,k]=s
  matResult[2,k]=mean(vecFluct.stat.boot<0.05,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.d>1.358,na.rm=TRUE)
  matResult[4,k]=mean(vecFluct.lambda.d,na.rm=TRUE)
  matResult[5,k]=sd(vecFluct.lambda.d,na.rm=TRUE)
  matResult[6,k]=matResult[4,k]-1050
  matResult[7,k]=(matResult[6,k]^2+matResult[5,k]^2)^0.5
  matResult[8,k]=mean(vecSuplr.stat.boot<0.05,na.rm=TRUE)
  matResult[9,k]=mean(vecSuplr.stat.d>8.68,na.rm=TRUE)
  matResult[10,k]=mean(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[11,k]=sd(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[12,k]=matResult[10,k]-1050
  matResult[13,k]=(matResult[11,k]^2+matResult[12,k]^2)^0.5
}

rownames(matResult)=c("s","fluct.stat.boot","fluct.stat.d","fluct.lambda.d","fluct.lambda.d.se","fluct.lambda.d.bias","fluct.lambda.d.rmse",
                      "suplr.stat.boot","suplr.stat.d","suplr.lambda.d","suplr.lambda.d.se","suplr.lambda.d.bias","suplr.lambda.d.rmse")
write.table(matResult,paste(rootpath,"Results/gauss2_n1500_size.csv",sep=""),sep=";",dec=",",col.names=FALSE)

matResult=matrix(nrow=5,ncol=5); 
for(k in c(1:5)){
  s=vecS[k] 
  # target arrays for each scenario
  vecFluct.stat.1=vector(l=1000)
  vecFluct.stat.2=vector(l=1000)
  vecSuplr.stat.1=vector(l=1000)
  vecSuplr.stat.2=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n1500_s",s,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.1[i]=input[3,i]
    vecFluct.stat.2[i]=input[4,i]
    vecSuplr.stat.1[i]=input[10,i]
    vecSuplr.stat.2[i]=input[11,i]
  }
  matResult[1,k]=s
  matResult[2,k]=mean(vecFluct.stat.1>1.584,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.2>1.584,na.rm=TRUE) 
  matResult[4,k]=mean(vecSuplr.stat.1>11.72,na.rm=TRUE)
  matResult[5,k]=mean(vecSuplr.stat.2>11.72,na.rm=TRUE)
}

rownames(matResult)=c("s","fluct.stat.1","fluct.stat.2","suplr.stat.1","suplr.stat.2")

write.table(matResult,paste(rootpath,"Results/gauss2_n1500_margin.csv",sep=""),sep=";",dec=",",col.names=FALSE)

# power
source(paste(rootpath,"gauss2_n1500_power.R",sep=""))
for(k in c(1:11)){
  r=vecR[k]
  print(paste("computing scenario set ",r,sep=""))
  start.time=Sys.time()
  matRes=gauss2_n1500_power(r)
  end.time=Sys.time()
  print(end.time-start.time)
  write.table(matRes,paste(rootpath,"Simulation/gauss2_n1500_r",r,".csv",sep=""),sep=";",dec=",",col.names=FALSE)
}

matResult=matrix(nrow=13,ncol=11); 
for(k in c(1:11)){
  r=vecR[k] 
  # target arrays for each scenario
  vecFluct.stat.d=vector(l=1000)
  vecFluct.stat.boot=vector(l=1000)
  vecFluct.lambda.d=vector(l=1000)
  vecSuplr.stat.d=vector(l=1000)
  vecSuplr.stat.boot=vector(l=1000)
  vecSuplr.lambda.d=vector(l=1000)
  # read csv file
  input=read.table(paste(rootpath,"Simulation/gauss2_n1500_r",r,".csv",sep=""),sep=";",dec=",")[,-1]
  for(i in c(1:1000)){
    vecFluct.stat.d[i]=input[1,i]
    vecFluct.stat.boot[i]=input[2,i]
    vecFluct.lambda.d[i]=input[5,i]
    vecSuplr.stat.d[i]=input[8,i]
    vecSuplr.stat.boot[i]=input[9,i]
    vecSuplr.lambda.d[i]=input[12,i]
  }
  matResult[1,k]=r
  matResult[2,k]=mean(vecFluct.stat.boot<0.05,na.rm=TRUE)
  matResult[3,k]=mean(vecFluct.stat.d>1.358,na.rm=TRUE) #1.358 for m=2, 1.74709 for m=3, 2.45917 for m=10
  matResult[4,k]=mean(vecFluct.lambda.d,na.rm=TRUE)
  matResult[5,k]=sd(vecFluct.lambda.d,na.rm=TRUE)
  matResult[6,k]=matResult[4,k]-1050
  matResult[7,k]=(matResult[6,k]^2+matResult[5,k]^2)^0.5
  matResult[8,k]=mean(vecSuplr.stat.boot<0.05,na.rm=TRUE)
  matResult[9,k]=mean(vecSuplr.stat.d>8.68,na.rm=TRUE) #8.68 for m=2, 14.15 for m=3, 27.03 for m=10
  matResult[10,k]=mean(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[11,k]=sd(vecSuplr.lambda.d,na.rm=TRUE)
  matResult[12,k]=matResult[10,k]-1050
  matResult[13,k]=(matResult[11,k]^2+matResult[12,k]^2)^0.5
}

rownames(matResult)=c("r","fluct.stat.boot","fluct.stat.d","fluct.lambda.d","fluct.lambda.d.se","fluct.lambda.d.bias","fluct.lambda.d.rmse",
                      "suplr.stat.boot","suplr.stat.d","suplr.lambda.d","suplr.lambda.d.se","suplr.lambda.d.bias","suplr.lambda.d.rmse")
write.table(matResult,paste(rootpath,"Results/gauss2_n1500_power.csv",sep=""),sep=";",dec=",",col.names=FALSE)

# plot
pdf(paste(rootpath,"Results/gauss2_n1500_power.pdf",sep=""),width=10,height=6)
plot(matResult[3,],x=vecR,type="o",col="red",pch=19,lty=2,ylim=c(0,1),xlab="Correlation for t > 1050",ylab="rejection rate")
par(new=TRUE)
plot(matResult[2,],x=vecR,type="o",col="red",pch=19,lty=1,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
plot(matResult[9,],x=vecR,type="o",col="blue",pch=19,lty=2,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
plot(matResult[8,],x=vecR,type="o",col="blue",pch=19,lty=1,ylim=c(0,1),xlab="",ylab="",xaxt="n",yaxt="n")
par(new=TRUE)
grid(lty=2,col="grey"); abline(h=0.05,lty="solid",col="grey");
legend("top",bg="white",legend=c("fluct, asym.","fluct, boot.","sup-lr, asym.","sup-lr, boot."),lty=c(2,1,2,1),col=c("red","red","blue","blue"))
dev.off()
