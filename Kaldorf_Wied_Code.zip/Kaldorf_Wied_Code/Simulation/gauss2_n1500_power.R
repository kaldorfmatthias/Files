gauss2_n1500_power = function(r){
  scenario.set = function(i,r){    
    library(SeqStrucChange)
    library(mvtnorm)
  
    # preallocate output vector
    res=vector(l=14);
    # simulated dataset
    set.seed(i); s=2
    Sd0=diag(c(1,1),2,2); Sd1=diag(c(s^0.5,1),2,2); Sd2=diag(c(s^0.5,s^0.5),2,2)
    Rho1=matrix(c(1,0.4,0.4,1),2,2)
    Rho2=matrix(c(1,r,r,1),2,2)
    Sigma1=Sd0%*%Rho1%*%Sd0; Sigma2=Sd1%*%Rho1%*%Sd1; Sigma3=Sd2%*%Rho1%*%Sd2; Sigma4=Sd2%*%Rho2%*%Sd2;
    matZ1=rmvnorm(750,c(0.05,0.05),Sigma1)
    matZ2=rmvnorm(150,c(0.06-0.01*s,0.05),Sigma2)
    matZ3=rmvnorm(150,c(0.06-0.01*s,0.06-0.01*s),Sigma3)
    matZ4=rmvnorm(450,c(0.06-0.01*s,0.06-0.01*s),Sigma4)
    matZ=rbind(matZ1,matZ2,matZ3,matZ4) 
    # estimation
    tryCatch({res.fluct=fluct_GaussJoint_wildboot(matZ,200)}, error=function(e) {return(list(Qmax=NaN,pval_boot=NaN,lambda=NaN,Qmax_margins=NaN,lambda_margins=NaN)) })
    tryCatch({res.suplr=suplr_GaussMarginal_GaussJoint_resboot(matZ,200)}, error=function(e) {return(list(suplr=NaN,pval_boot=NaN,lambda=NaN,suplr_margins=NaN,lambda_margins=NaN)) })
    # fluct
    res[1]=res.fluct$Qmax
    res[2]=res.fluct$pval_boot
    res[3]=res.fluct$Qmax_margins[1]
    res[4]=res.fluct$Qmax_margins[2]
    res[5]=res.fluct$lambda
    res[6]=res.fluct$lambda_margins[1]
    res[7]=res.fluct$lambda_margins[2]
    # suplr
    res[8]=res.suplr$suplr
    res[9]=res.suplr$pval_boot
    res[10]=res.suplr$suplr_margins[1]
    res[11]=res.suplr$suplr_margins[2]
    res[12]=res.suplr$lambda
    res[13]=res.suplr$lambda_margins[1]
    res[14]=res.suplr$lambda_margins[2]
    return(res)
  }

library(parallel)
ncores = detectCores(logical=FALSE) 
Cluster = makeCluster(ncores)

clusterExport(Cluster,"r")
clusterExport(Cluster,"scenario.set")

matRes=parSapply(Cluster,c(1:1000),function(i) scenario.set(i,r))
stopCluster(Cluster)
return(matRes)
}