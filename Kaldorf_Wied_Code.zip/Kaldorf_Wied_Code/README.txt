This folder contains code and data necessary to replicate numerical results in Kaldorf & Wied (2020)
"Testing Constant Cross-Sectional Dependence with Time-Varying Marginal Distributions in Parametric Models" 
Please contact kaldorf@wiso.uni-koeln.de for any questions and comments on the code.
###########################################################################################################
The code was compiled and executed using R 3.5 and requires installation of several additional packages.
- SeqStrucChange_1.0.tar is the core of this code and contains all test statistics. To replicate results,
  the package and all dependencies must be downloaded, installed, and loaded prior to execution.
- The Simulation folder contains code necessary for the Monte Carlo experiments from the paper. The 
  subfolders "Results" and "Simulation" come empty and are used to write the simulation results.
  The script file gauss2_masterscript.R The code simulates sample paths and runs all considered tests in the 
  2-dimensional i.i.d. case. All simulation experiments with higher-dimensional I.I.D. and all GARCH-data
  were conducted using a High-Performance-Cluster. The code extends analogously to these cases.
- The Application folder contains all necessary data, runs several break-point tests, and creates
  all time-series plots with break-point estimators presented in the paper.