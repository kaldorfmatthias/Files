###########################################################################################################################
# Replication files to Kaldorf & Wied (2020) 
# "Testing Constant Cross-Sectional Dependence with Time-Varying Marginal Distributions in Parametric Models"
# For comments and questions please contact kaldorf@wiso.uni-koeln.de
# This script computes all empirical applications
###########################################################################################################################

# load packages
library("SeqStrucChange")
library("crayon")
library("tibble")
library("readxl")
library("timeDate")
library("timeSeries")
library("roll")

# specify output path
path = getwd()

#################################################################################################################
# Application to European Financial Sector Stocks, Section 4
#################################################################################################################

stxx.data=read.table(paste(path,"eurostoxx50_banks.csv",sep=""),header=FALSE,sep=";",dec=",")
stxx=100*returns(as.timeSeries(stxx.data[1935:3500,2:8]))
time = as.Date(stxx.data[1936:3500,1],format="%d.%m.%Y")

res.fluct=fluct_Copula(stxx)

res.suplr=suplr_GARCH_GaussCopula(stxx,B=200)

# rolling stats
rolling_st=vector("list", 7); stdev=matrix(nrow=7,ncol=2); lambda=res.suplr$lambda_marg 
lbtest=vector("numeric",7); kstest=vector("numeric",7)
for(j in c(1:7)){
  stdev[j,1]=250^0.5*sd(stxx[1:lambda[j],j],na.rm=TRUE)
  stdev[j,2]=250^0.5*sd(stxx[(lambda[j]+1):1043,j],na.rm=TRUE)
  rolling_st[[j]]=250^0.5*rollStats(stxx[,j],100,sd,align="right")
  res.lb = Box.test(res.fluct$matZ[,j], lag = 4, type = c("Box-Pierce", "Ljung-Box"), fitdf = 0)
  res.ks = ks.test(res.fluct$matZ[,j],"pnorm")
  lbtest[j] = res.lb$p.value
  kstest[j] = res.ks$p.value
}

rc=roll_cor(stxx[,2:3],width=250)[1,2,]


# plot
pdf(paste(path,"stxx_bnp.pdf",sep=""),width=8,height=4)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_st[[1]],x=time[-c(1:99)],ylab="Rolling (Unconditional) Volatility (%)",xlab="",type="l")
lines(x=c(time[1],time[lambda[1]]),y=c(stdev[1,1],stdev[1,1]),col="dodgerblue")
lines(x=c(time[lambda[1]],time[1565]),y=c(stdev[1,2],stdev[1,2]),col="dodgerblue")
abline(v=time[lambda[1]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"stxx_santander.pdf",sep=""),width=8,height=4)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_st[[2]],x=time[-c(1:99)],ylab="Rolling (Unconditional) Volatility (%)",xlab="",type="l")
lines(x=c(time[2],time[lambda[2]]),y=c(stdev[2,1],stdev[2,1]),col="dodgerblue")
lines(x=c(time[lambda[2]],time[1565]),y=c(stdev[2,2],stdev[2,2]),col="dodgerblue")
abline(v=time[lambda[2]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"stxx_ing.pdf",sep=""),width=8,height=4)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_st[[3]],x=time[-c(1:99)],ylab="Rolling (Unconditional) Volatility (%)",xlab="",type="l")
lines(x=c(time[1],time[lambda[3]]),y=c(stdev[3,1],stdev[3,1]),col="dodgerblue")
lines(x=c(time[lambda[3]],time[1565]),y=c(stdev[3,2],stdev[3,2]),col="dodgerblue")
abline(v=time[lambda[3]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"stxx_bbva.pdf",sep=""),width=8,height=4)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_st[[4]],x=time[-c(1:99)],ylab="Rolling (Unconditional) Volatility (%)",xlab="",type="l")
lines(x=c(time[4],time[lambda[4]]),y=c(stdev[4,1],stdev[4,1]),col="dodgerblue")
lines(x=c(time[lambda[4]],time[1565]),y=c(stdev[4,2],stdev[4,2]),col="dodgerblue")
abline(v=time[lambda[4]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"stxx_is.pdf",sep=""),width=8,height=4)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_st[[5]],x=time[-c(1:99)],ylab="Rolling (Unconditional) Volatility (%)",xlab="",type="l")
lines(x=c(time[5],time[lambda[5]]),y=c(stdev[5,1],stdev[5,1]),col="dodgerblue")
lines(x=c(time[lambda[5]],time[1565]),y=c(stdev[5,2],stdev[5,2]),col="dodgerblue")
abline(v=time[lambda[5]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"stxx_sg.pdf",sep=""),width=8,height=4)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_st[[6]],x=time[-c(1:99)],ylab="Rolling (Unconditional) Volatility (%)",xlab="",type="l")
lines(x=c(time[6],time[lambda[6]]),y=c(stdev[6,1],stdev[6,1]),col="dodgerblue")
lines(x=c(time[lambda[6]],time[1565]),y=c(stdev[6,2],stdev[6,2]),col="dodgerblue")
abline(v=time[lambda[6]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"stxx_db.pdf",sep=""),width=8,height=4)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_st[[7]],x=time[-c(1:99)],ylab="Rolling (Unconditional) Volatility (%)",xlab="",type="l")
lines(x=c(time[7],time[lambda[7]]),y=c(stdev[7,1],stdev[7,1]),col="dodgerblue")
lines(x=c(time[lambda[7]],time[1565]),y=c(stdev[7,2],stdev[7,2]),col="dodgerblue")
abline(v=time[lambda[7]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

sant_hat=stxx[,2]; sant_tilde=stxx[,2]
for(t in c(1:lambda[2])){sant_hat[t]=sant_hat[t]/suplr_fr_s$sigma1^0.5}
for(t in c((524+suplr_fr_s$lambda):2889)){fr5_s_hat[t]=(fr5_s[t]-suplr_fr_s$mu2)/suplr_fr_s$sigma2^0.5}
for(t in c(1:(524+fluct_fr_s$lambda))){fr5_s_tilde[t]=(fr5_s[t]-fluct_fr_s$mu1)/fluct_fr_s$sigma1^0.5}
for(t in c((524+fluct_fr_s$lambda):2889)){fr5_s_tilde[t]=(fr5_s[t]-fluct_fr_s$mu2)/fluct_fr_s$sigma2^0.5}

pdf(paste(path,"bnp_de.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
de_fr_s_tilde = rollapply(cbind(de5_s_tilde,fr5_s_tilde), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
de_fr_s_hat = rollapply(cbind(de5_s_hat,fr5_s_hat), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
de_fr_s = rollapply(cbind(de5_s,fr5_s), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
plot(y=de_fr_s[plotrange-126],x=time[plotrange],ylab="Correlation",xlab="",type="l"); par(new=TRUE)
plot(y=de_fr_s_hat[plotrange-126],x=time[plotrange],lty="dashed",col="blue",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
plot(y=de_fr_s_tilde[plotrange-126],x=time[plotrange],lty="dashed",col="red",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
lines(x=c(time[524],time[524+suplr_s$lambda]),y=c(suplr_s$rho1[1,2],suplr_s$rho1[1,2]),col="blue")
lines(x=c(time[524+suplr_s$lambda],time[2000]),y=c(suplr_s$rho2[1,2],suplr_s$rho2[1,2]),col="blue")
abline(v=time[524+suplr_s$lambda],col="blue",lty="dashed")
lines(x=c(time[524],time[524+fluct_s$lambda]),y=c(fluct_s$rho1[1,2],fluct_s$rho1[1,2]),col="red")
lines(x=c(time[524+fluct_s$lambda],time[2000]),y=c(fluct_s$rho2[1,2],fluct_s$rho2[1,2]),col="red")
abline(v=time[524+fluct_s$lambda],col="red",lty="dashed")
grid(lty=2,col="grey")
legend("topright",bg="white",legend=c("No Correction","Fluctuation","sup-LR"),lty=c(1,2,2),col=c("black","red","blue"),cex=1)
dev.off()

###################################################################################################################
# Application to Equity and Commodity Index Data, Supplementary Material, Section E
###################################################################################################################

oil.data=read.table(paste(path,"oil_estxx.csv",sep=""),header=TRUE,sep=";",dec=",")
oil=100*returns(as.timeSeries(oil.data[,2:3]))
time =as.Date(oil.data[,1],format="%d.%m.%Y")

res.fluct = fluct_GARCH_GaussJoint(data.matrix(oil[1000:4000,]))
time[1000+res.fluct$lambda_marg[1]]
time[1000+res.fluct$lambda_marg[2]]

res.suplr = suplr_GARCH_GaussJoint(data.matrix(oil[1000:4000,]))
time[1000+res.suplr$lambda_marg[1]]
time[1000+res.suplr$lambda_marg[2]]

# oil
suplr.oil=suplr_Squares(oil[1000:4000,1])
time[1000+suplr.oil$lambda]; suplr.oil$suplr
(252*suplr.oil$sigma1)^0.5; (252*suplr.oil$sigma2)^0.5
# equity
suplr.eq=suplr_Squares(oil[1000:4000,2])
time[1000+suplr.eq$lambda]; suplr.eq$suplr
(252*suplr.eq$sigma1)^0.5; (252*suplr.eq$sigma2)^0.5

# rolling stats
rolling_sd_oil=rollStats(oil[,1],252,sd,align="center")
rolling_sd_stx=rollStats(oil[,2],252,sd,align="center")
rolling_correlation = roll_cor(oil[,],width=252)[1,2,]

# plot
pdf(paste(path,"oil_vol.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=252^0.5*rolling_sd_oil[1126:3874],x=time[1126:3874],ylab="Rolling Volatility (%)",xlab="",type="l")
lines(x=c(time[1000],time[1000+res.suplr$lambda_marg[1]]),y=c((252*suplr.oil$sigma1)^0.5,(252*suplr.oil$sigma1)^0.5),col="dodgerblue")
lines(x=c(time[1000+res.suplr$lambda_marg[1]],time[4000]),y=c((252*suplr.oil$sigma2)^0.5,(252*suplr.oil$sigma2)^0.5),col="dodgerblue")
abline(v=time[1000+res.suplr$lambda_marg[1]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"eq_vol.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=252^0.5*rolling_sd_stx[1126:3874],x=time[1126:3874],ylab="Rolling Volatility (%)",xlab="",type="l")
lines(x=c(time[1000],time[1000+res.suplr$lambda_marg[2]]),y=c((252*suplr.eq$sigma1)^0.5,(252*suplr.eq$sigma1)^0.5),col="dodgerblue")
lines(x=c(time[1000+res.suplr$lambda_marg[2]],time[4000]),y=c((252*suplr.eq$sigma2)^0.5,(252*suplr.eq$sigma2)^0.5),col="dodgerblue")
abline(v=time[1000+res.suplr$lambda_marg[2]],col="dodgerblue",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"oil_eq_cor.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_correlation[1252:4000],x=time[1252:4000],ylab="Rolling correlation (%)",xlab="",type="l")
grid(lty=2,col="grey")
dev.off()

###########################################################################################################################
# Application to European Bond Data, Supplementary Material, Section F
###########################################################################################################################

irs=read_xlsx(paste(path,"bondspreads_euro_area.xlsx",sep=""),sheet="IRS",col_names=TRUE,col_types=c("date",rep("numeric",18)))
irs5=as.timeSeries(100*irs$`5`)
de=read_xlsx(paste(path,"bondspreads_euro_area.xlsx",sep=""),sheet="DE_GOV",col_names=TRUE,col_types=c("date",rep("numeric",14)))
de5_s=as.timeSeries(100*de$`5`)-irs5
fr=read_xlsx(paste(path,"bondspreads_euro_area.xlsx",sep=""),sheet="FR_GOV",col_names=TRUE,col_types=c("date",rep("numeric",15)))
fr5_s=as.timeSeries(100*fr$`5`)-irs5
es=read_xlsx(paste(path,"bondspreads_euro_area.xlsx",sep=""),sheet="ES_GOV",col_names=TRUE,col_types=c("date",rep("numeric",14)))
es5_s=as.timeSeries(100*es$`5`)-irs5
it=read_xlsx(paste(path,"bondspreads_euro_area.xlsx",sep=""),sheet="IT_GOV",col_names=TRUE,col_types=c("date",rep("numeric",14)))
it5_s=as.timeSeries(100*it$`5`)-irs5

matY = as.matrix(cbind(fr5_s,de5_s,it5_s,es5_s))
testFluct = fluct_GaussJoint_wildboot(matY)

time = as.Date(de$DATE)
rolling_sd_de_s=rollStats(de5_s,252,sd,align="center")
rolling_sd_fr_s=rollStats(fr5_s,252,sd,align="center")
rolling_sd_it_s=rollStats(it5_s,252,sd,align="center")
rolling_sd_es_s=rollStats(es5_s,252,sd,align="center")

# margins
plotrange=c(524:1223)
fluct_fr_s=fluct_GaussMarginal(fr5_s[plotrange]);
time[524+fluct_fr_s$lambda]; fluct_fr_s$Qmax; fluct_fr_s$mu1; fluct_fr_s$mu2; fluct_fr_s$sigma1^0.5; fluct_fr_s$sigma2^0.5
suplr_fr_s=suplr_GaussMarginal(fr5_s[plotrange]);
time[524+suplr_fr_s$lambda]; suplr_fr_s$suplr; suplr_fr_s$mu1; suplr_fr_s$mu2; suplr_fr_s$sigma1^0.5; suplr_fr_s$sigma2^0.5

fluct_de_s=fluct_GaussMarginal(de5_s[plotrange])
time[524+fluct_de_s$lambda]; fluct_de_s$Qmax; fluct_de_s$mu1; fluct_de_s$mu2; fluct_de_s$sigma1^0.5; fluct_de_s$sigma2^0.5
suplr_de_s=suplr_GaussMarginal(de5_s[plotrange])
time[524+suplr_de_s$lambda]; suplr_de_s$suplr; suplr_de_s$mu1; suplr_de_s$mu2; suplr_de_s$sigma1^0.5; suplr_de_s$sigma2^0.5

fluct_it_s=fluct_GaussMarginal(it5_s[plotrange])
time[524+fluct_it_s$lambda]; fluct_it_s$Qmax; fluct_it_s$mu1; fluct_it_s$mu2; fluct_it_s$sigma1^0.5; fluct_it_s$sigma2^0.5
suplr_it_s=suplr_GaussMarginal(it5_s[plotrange])
time[524+suplr_it_s$lambda]; suplr_it_s$suplr; suplr_it_s$mu1; suplr_it_s$mu2; suplr_it_s$sigma1^0.5; suplr_it_s$sigma2^0.5

fluct_es_s=fluct_GaussMarginal(es5_s[plotrange])
time[524+fluct_es_s$lambda]; fluct_es_s$Qmax; fluct_es_s$mu1; fluct_es_s$mu2; fluct_es_s$sigma1^0.5; fluct_es_s$sigma2^0.5
suplr_es_s=suplr_GaussMarginal(es5_s[plotrange])
time[524+suplr_es_s$lambda]; suplr_es_s$suplr; suplr_es_s$mu1; suplr_es_s$mu2; suplr_es_s$sigma1^0.5; suplr_es_s$sigma2^0.5

# standardization
fr5_s_hat=fr5_s; fr5_s_tilde=fr5_s
for(t in c(1:(524+suplr_fr_s$lambda))){fr5_s_hat[t]=(fr5_s[t]-suplr_fr_s$mu1)/suplr_fr_s$sigma1^0.5}
for(t in c((524+suplr_fr_s$lambda):2889)){fr5_s_hat[t]=(fr5_s[t]-suplr_fr_s$mu2)/suplr_fr_s$sigma2^0.5}
for(t in c(1:(524+fluct_fr_s$lambda))){fr5_s_tilde[t]=(fr5_s[t]-fluct_fr_s$mu1)/fluct_fr_s$sigma1^0.5}
for(t in c((524+fluct_fr_s$lambda):2889)){fr5_s_tilde[t]=(fr5_s[t]-fluct_fr_s$mu2)/fluct_fr_s$sigma2^0.5}
de5_s_hat=de5_s; de5_s_tilde=de5_s
for(t in c(1:(524+suplr_de_s$lambda))){de5_s_hat[t]=(de5_s[t]-suplr_de_s$mu1)/suplr_de_s$sigma1^0.5}
for(t in c((524+suplr_de_s$lambda):2889)){de5_s_hat[t]=(de5_s[t]-suplr_de_s$mu2)/suplr_de_s$sigma2^0.5}
for(t in c(1:(524+fluct_de_s$lambda))){de5_s_tilde[t]=(de5_s[t]-fluct_de_s$mu1)/fluct_de_s$sigma1^0.5}
for(t in c((524+fluct_de_s$lambda):2889)){de5_s_tilde[t]=(de5_s[t]-fluct_de_s$mu2)/fluct_de_s$sigma2^0.5}
it5_s_hat=it5_s; it5_s_tilde=it5_s
for(t in c(1:(524+suplr_it_s$lambda))){it5_s_hat[t]=(it5_s[t]-suplr_it_s$mu1)/suplr_it_s$sigma1^0.5}
for(t in c((524+suplr_it_s$lambda):2889)){it5_s_hat[t]=(it5_s[t]-suplr_it_s$mu2)/suplr_it_s$sigma2^0.5}
for(t in c(1:(524+fluct_it_s$lambda))){it5_s_tilde[t]=(it5_s[t]-fluct_it_s$mu1)/fluct_it_s$sigma1^0.5}
for(t in c((524+fluct_it_s$lambda):2889)){it5_s_tilde[t]=(it5_s[t]-fluct_it_s$mu2)/fluct_it_s$sigma2^0.5}
es5_s_hat=es5_s; es5_s_tilde=es5_s
for(t in c(1:(524+suplr_es_s$lambda))){es5_s_hat[t]=(es5_s[t]-suplr_es_s$mu1)/suplr_es_s$sigma1^0.5}
for(t in c((524+suplr_es_s$lambda):2889)){es5_s_hat[t]=(es5_s[t]-suplr_es_s$mu2)/suplr_es_s$sigma2^0.5}
for(t in c(1:(524+fluct_es_s$lambda))){es5_s_tilde[t]=(es5_s[t]-fluct_es_s$mu1)/fluct_es_s$sigma1^0.5}
for(t in c((524+fluct_es_s$lambda):2889)){es5_s_tilde[t]=(es5_s[t]-fluct_es_s$mu2)/fluct_es_s$sigma2^0.5}

# correlation
fluct_s=fluct_GaussJoint_wildboot(as.matrix(cbind(fr5_s,de5_s,it5_s,es5_s)[plotrange,]))
time[524+fluct_s$lambda]; fluct_s$Qmax; fluct_s$pval_boot; fluct_s$rho1; fluct_s$rho2
suplr_s=suplr_GaussJoint_resboot(as.matrix(cbind(fr5_s,de5_s,it5_s,es5_s)[plotrange,]))
time[524+suplr_s$lambda]; suplr_s$suplr; suplr_s$pval_boot; suplr_s$rho1; suplr_s$rho2
fluctc_s=fluct_Copula(as.matrix(cbind(fr5_s,de5_s,it5_s,es5_s)[plotrange,]))
time[524+fluctc_s$lambda]; fluctc_s$pval; fluctc_s$Rho1; fluctc_s$Rho2
suplrt_s=suplr_tMarginal_tCopula(as.matrix(cbind(fr5_s,de5_s,it5_s,es5_s)[plotrange,]),niter=1000)
time[524+suplrt_s$lambda]; suplrt_s$suplr; suplrt_s$pval_boot; suplrt_s$Rho1; suplrt_s$Rho2
suplrm_s=suplr_tMarginal_GaussCopula_resboot(as.matrix(cbind(fr5_s,de5_s,it5_s,es5_s)[plotrange,]),niter=1000,B=200)
time[524+suplrm_s$lambda]; suplrm_s$suplr; suplrm_s$pval_boot; suplrm_s$rho1; suplrm_s$rho2

# spreads
pdf(paste(path,"de_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=de5_s[plotrange],x=time[plotrange],ylab="Bond Spread (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_de_s$lambda]),y=c(suplr_de_s$mu1,suplr_de_s$mu1),col="dodgerblue")
lines(x=c(time[524+suplr_de_s$lambda],time[2000]),y=c(suplr_de_s$mu2,suplr_de_s$mu2),col="dodgerblue")
abline(v=time[524+suplr_de_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"fr_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=fr5_s[plotrange],x=time[plotrange],ylab="Bond Spread (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_fr_s$lambda]),y=c(suplr_fr_s$mu1,suplr_fr_s$mu1),col="dodgerblue")
lines(x=c(time[524+suplr_fr_s$lambda],time[2000]),y=c(suplr_fr_s$mu2,suplr_fr_s$mu2),col="dodgerblue")
abline(v=time[524+suplr_fr_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"es_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=es5_s[plotrange],x=time[plotrange],ylab="Bond Spread (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_es_s$lambda]),y=c(suplr_es_s$mu1,suplr_es_s$mu1),col="dodgerblue")
lines(x=c(time[524+suplr_es_s$lambda],time[2000]),y=c(suplr_es_s$mu2,suplr_es_s$mu2),col="dodgerblue")
abline(v=time[524+suplr_es_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"it_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=it5_s[plotrange],x=time[plotrange],ylab="Bond Spread (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_it_s$lambda]),y=c(suplr_it_s$mu1,suplr_it_s$mu1),col="dodgerblue")
lines(x=c(time[524+suplr_it_s$lambda],time[2000]),y=c(suplr_it_s$mu2,suplr_it_s$mu2),col="dodgerblue")
abline(v=time[524+suplr_it_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

# rolling volatilities

pdf(paste(path,"de_s_vol.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_sd_de_s[plotrange-126],x=time[plotrange],ylab="Rolling Volatility (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_de_s$lambda]),y=c(suplr_de_s$sigma1^0.5,suplr_de_s$sigma1^0.5),col="dodgerblue")
lines(x=c(time[524+suplr_de_s$lambda],time[2000]),y=c(suplr_de_s$sigma2^0.5,suplr_de_s$sigma2^0.5),col="dodgerblue")
abline(v=time[524+suplr_de_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"fr_s_vol.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_sd_fr_s[plotrange-126],x=time[plotrange],ylab="Rolling Volatility (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_fr_s$lambda]),y=c(suplr_fr_s$sigma1^0.5,suplr_fr_s$sigma1^0.5),col="dodgerblue")
lines(x=c(time[524+suplr_fr_s$lambda],time[2000]),y=c(suplr_fr_s$sigma2^0.5,suplr_fr_s$sigma2^0.5),col="dodgerblue")
abline(v=time[524+suplr_fr_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"es_s_vol.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_sd_es_s[plotrange-126],x=time[plotrange],ylab="Rolling Volatility (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_es_s$lambda]),y=c(suplr_es_s$sigma1^0.5,suplr_es_s$sigma1^0.5),col="dodgerblue")
lines(x=c(time[524+suplr_es_s$lambda],time[2000]),y=c(suplr_es_s$sigma2^0.5,suplr_es_s$sigma2^0.5),col="dodgerblue")
abline(v=time[524+suplr_es_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"it_s_vol.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
plot(y=rolling_sd_it_s[plotrange-126],x=time[plotrange],ylab="Rolling Volatility (bp)",xlab="",type="l")
lines(x=c(time[524],time[524+suplr_it_s$lambda]),y=c(suplr_it_s$sigma1^0.5,suplr_it_s$sigma1^0.5),col="dodgerblue")
lines(x=c(time[524+suplr_it_s$lambda],time[2000]),y=c(suplr_it_s$sigma2^0.5,suplr_it_s$sigma2^0.5),col="dodgerblue")
abline(v=time[524+suplr_it_s$lambda],col="dodgerblue",lty="dashed")
abline(v=time[524+suplr_joint_s$lambda],col="darkred",lty="dashed")
grid(lty=2,col="grey")
dev.off()

# rolling correlations

pdf(paste(path,"fr_de_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
de_fr_s_tilde = rollapply(cbind(de5_s_tilde,fr5_s_tilde), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
de_fr_s_hat = rollapply(cbind(de5_s_hat,fr5_s_hat), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
de_fr_s = rollapply(cbind(de5_s,fr5_s), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
plot(y=de_fr_s[plotrange-126],x=time[plotrange],ylab="Correlation",xlab="",type="l"); par(new=TRUE)
plot(y=de_fr_s_hat[plotrange-126],x=time[plotrange],lty="dashed",col="blue",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
plot(y=de_fr_s_tilde[plotrange-126],x=time[plotrange],lty="dashed",col="red",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
lines(x=c(time[524],time[524+suplr_s$lambda]),y=c(suplr_s$rho1[1,2],suplr_s$rho1[1,2]),col="blue")
lines(x=c(time[524+suplr_s$lambda],time[2000]),y=c(suplr_s$rho2[1,2],suplr_s$rho2[1,2]),col="blue")
abline(v=time[524+suplr_s$lambda],col="blue",lty="dashed")
lines(x=c(time[524],time[524+fluct_s$lambda]),y=c(fluct_s$rho1[1,2],fluct_s$rho1[1,2]),col="red")
lines(x=c(time[524+fluct_s$lambda],time[2000]),y=c(fluct_s$rho2[1,2],fluct_s$rho2[1,2]),col="red")
abline(v=time[524+fluct_s$lambda],col="red",lty="dashed")
grid(lty=2,col="grey")
legend("topright",bg="white",legend=c("No Correction","Fluctuation","sup-LR"),lty=c(1,2,2),col=c("black","red","blue"),cex=1)
dev.off()

pdf(paste(path,"fr_it_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
it_fr_s_tilde = rollapply(cbind(it5_s_tilde,fr5_s_tilde), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
it_fr_s_hat = rollapply(cbind(it5_s_hat,fr5_s_hat), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
it_fr_s = rollapply(cbind(it5_s,fr5_s), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
plot(y=it_fr_s[plotrange-126],x=time[plotrange],ylab="Correlation",xlab="",type="l"); par(new=TRUE)
plot(y=it_fr_s_hat[plotrange-126],x=time[plotrange],lty="dashed",col="blue",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
plot(y=it_fr_s_tilde[plotrange-126],x=time[plotrange],lty="dashed",col="red",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
lines(x=c(time[524],time[524+suplr_s$lambda]),y=c(suplr_s$rho1[1,3],suplr_s$rho1[1,3]),col="blue")
lines(x=c(time[524+suplr_s$lambda],time[2000]),y=c(suplr_s$rho2[1,3],suplr_s$rho2[1,3]),col="blue")
abline(v=time[524+suplr_s$lambda],col="blue",lty="dashed")
lines(x=c(time[524],time[524+fluct_s$lambda]),y=c(fluct_s$rho1[1,3],fluct_s$rho1[1,3]),col="red")
lines(x=c(time[524+fluct_s$lambda],time[2000]),y=c(fluct_s$rho2[1,3],fluct_s$rho2[1,3]),col="red")
abline(v=time[524+fluct_s$lambda],col="red",lty="dashed"); 
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"fr_es_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
es_fr_s_tilde = rollapply(cbind(es5_s_tilde,fr5_s_tilde), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
es_fr_s_hat = rollapply(cbind(es5_s_hat,fr5_s_hat), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
es_fr_s = rollapply(cbind(es5_s,fr5_s), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
plot(y=es_fr_s[plotrange-126],x=time[plotrange],ylab="Correlation",xlab="",type="l"); par(new=TRUE)
plot(y=es_fr_s_hat[plotrange-126],x=time[plotrange],lty="dashed",col="blue",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
plot(y=es_fr_s_tilde[plotrange-126],x=time[plotrange],lty="dashed",col="red",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
lines(x=c(time[524],time[524+suplr_s$lambda]),y=c(suplr_s$rho1[1,4],suplr_s$rho1[1,4]),col="blue")
lines(x=c(time[524+suplr_s$lambda],time[2000]),y=c(suplr_s$rho2[1,4],suplr_s$rho2[1,4]),col="blue")
abline(v=time[524+suplr_s$lambda],col="blue",lty="dashed")
lines(x=c(time[524],time[524+fluct_s$lambda]),y=c(fluct_s$rho1[1,4],fluct_s$rho1[1,4]),col="red")
lines(x=c(time[524+fluct_s$lambda],time[2000]),y=c(fluct_s$rho2[1,4],fluct_s$rho2[1,4]),col="red")
abline(v=time[524+fluct_s$lambda],col="red",lty="dashed");
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"de_it_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
it_de_s_tilde = rollapply(cbind(it5_s_tilde,de5_s_tilde), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
it_de_s_hat = rollapply(cbind(it5_s_hat,de5_s_hat), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
it_de_s = rollapply(cbind(it5_s,de5_s), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
plot(y=it_de_s[plotrange-126],x=time[plotrange],ylab="Correlation",xlab="",type="l"); par(new=TRUE)
plot(y=it_de_s_hat[plotrange-126],x=time[plotrange],lty="dashed",col="blue",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
plot(y=it_de_s_tilde[plotrange-126],x=time[plotrange],lty="dashed",col="red",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
lines(x=c(time[524],time[524+suplr_s$lambda]),y=c(suplr_s$rho1[2,3],suplr_s$rho1[2,3]),col="blue")
lines(x=c(time[524+suplr_s$lambda],time[2000]),y=c(suplr_s$rho2[2,3],suplr_s$rho2[2,3]),col="blue")
abline(v=time[524+suplr_s$lambda],col="blue",lty="dashed")
lines(x=c(time[524],time[524+fluct_s$lambda]),y=c(fluct_s$rho1[2,3],fluct_s$rho1[2,3]),col="red")
lines(x=c(time[524+fluct_s$lambda],time[2000]),y=c(fluct_s$rho2[2,3],fluct_s$rho2[2,3]),col="red")
abline(v=time[524+fluct_s$lambda],col="red",lty="dashed"); 
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"de_es_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
es_de_s_tilde = rollapply(cbind(es5_s_tilde,de5_s_tilde), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
es_de_s_hat = rollapply(cbind(es5_s_hat,de5_s_hat), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
es_de_s = rollapply(cbind(es5_s,de5_s), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
plot(y=es_de_s[plotrange-126],x=time[plotrange],ylab="Correlation",xlab="",type="l"); par(new=TRUE)
plot(y=es_de_s_hat[plotrange-126],x=time[plotrange],lty="dashed",col="blue",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
plot(y=es_de_s_tilde[plotrange-126],x=time[plotrange],lty="dashed",col="red",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
lines(x=c(time[524],time[524+suplr_s$lambda]),y=c(suplr_s$rho1[2,4],suplr_s$rho1[2,4]),col="blue")
lines(x=c(time[524+suplr_s$lambda],time[2000]),y=c(suplr_s$rho2[2,4],suplr_s$rho2[2,4]),col="blue")
abline(v=time[524+suplr_s$lambda],col="blue",lty="dashed")
lines(x=c(time[524],time[524+fluct_s$lambda]),y=c(fluct_s$rho1[2,4],fluct_s$rho1[2,4]),col="red")
lines(x=c(time[524+fluct_s$lambda],time[2000]),y=c(fluct_s$rho2[2,4],fluct_s$rho2[2,4]),col="red")
abline(v=time[524+fluct_s$lambda],col="red",lty="dashed"); 
grid(lty=2,col="grey")
dev.off()

pdf(paste(path,"it_es_s.pdf",sep=""),width=10,height=6)
par(mar=c(5,4,2,2)+0.1)
es_it_s_tilde = rollapply(cbind(es5_s_tilde,it5_s_tilde), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
es_it_s_hat = rollapply(cbind(es5_s_hat,it5_s_hat), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
es_it_s = rollapply(cbind(es5_s,de5_s), 252, function(x) cor(x[,1], x[,2]), by.column = FALSE,align="center")
plot(y=es_it_s[plotrange-126],x=time[plotrange],ylab="Correlation",xlab="",type="l"); par(new=TRUE)
plot(y=es_it_s_hat[plotrange-126],x=time[plotrange],lty="dashed",col="blue",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
plot(y=es_it_s_tilde[plotrange-126],x=time[plotrange],lty="dashed",col="red",ylab="",xlab="",xaxt="n",yaxt="n",type="l"); par(new=TRUE)
lines(x=c(time[524],time[524+suplr_s$lambda]),y=c(suplr_s$rho1[3,4],suplr_s$rho1[3,4]),col="blue")
lines(x=c(time[524+suplr_s$lambda],time[2000]),y=c(suplr_s$rho2[3,4],suplr_s$rho2[3,4]),col="blue")
abline(v=time[524+suplr_s$lambda],col="blue",lty="dashed")
lines(x=c(time[524],time[524+fluct_s$lambda]),y=c(fluct_s$rho1[3,4],fluct_s$rho1[3,4]),col="red")
lines(x=c(time[524+fluct_s$lambda],time[2000]),y=c(fluct_s$rho2[3,4],fluct_s$rho2[3,4]),col="red")
abline(v=time[524+fluct_s$lambda],col="red",lty="dashed"); 
grid(lty=2,col="grey")
dev.off()

