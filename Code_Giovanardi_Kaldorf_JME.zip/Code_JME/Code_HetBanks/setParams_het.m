function par = setParams_het()

par = setParams_structural();

% policy
par.KAPPACss    = 0.08;
par.KAPPAFss    = 0.08;
par.KAPPANss    = 0.08;
par.TAXE        = 0.0;

end