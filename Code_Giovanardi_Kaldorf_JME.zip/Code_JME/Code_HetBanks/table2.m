function out = table2(results,estock_baseline,welfare_baseline)

% estock_baseline is the carbon stock in tax-free model

M_  = results.M_;
mean = results.means;

% clean bond spread
vecMoments(1,1) = mean(ismember(M_.endo_names,'spreadc'));
% fossil bond spread
vecMoments(2,1) = mean(ismember(M_.endo_names,'spreadf'));
% clean leverage
vecMoments(3,1) = mean(ismember(M_.endo_names,'marketlevc'));
% fossil leverage
vecMoments(4,1) = mean(ismember(M_.endo_names,'marketlevf'));
% clean default
vecMoments(5,1) = 100*(1-(1-mean(ismember(M_.endo_names,'Fc')))^4);
% fossil default
vecMoments(6,1) = 100*(1-(1-mean(ismember(M_.endo_names,'Ff')))^4);
% fossil cap share
vecMoments(7,1) = mean(ismember(M_.endo_names,'fossilshareK'));
% pollution stock
vecMoments(8,1) = 100*mean(ismember(M_.endo_names,'estock'))/estock_baseline - 100;
% damage/gdp
vecMoments(9,1) = 100*mean(ismember(M_.endo_names,'Dcost'));
% abatement
vecMoments(10,1) = 100*mean(ismember(M_.endo_names,'eta'));
% bank failure
vecMoments(11,1) = 100*(1-(1-mean(ismember(M_.endo_names,'Fmu')))^4);
% deposit spread
vecMoments(12,1) = mean(ismember(M_.endo_names,'spreaddep'));
% welfare
vecMoments(13,1) =  100*(1-exp((1-0.995)*(- mean(ismember(M_.endo_names,'V')) + welfare_baseline)));

% DATA
rowNAMES  = ["Spread C","Spread F","Leverage C","Leverage F","Default C","Default F",...
    "Fossil Cap Share","GHG Stock","Damage/GDP","Abated Emissions","Bank Failure","Deposit Spread","Welfare"];
out.Ttarget = table(vecMoments,'RowNames',rowNAMES);  

end