function out = momentsModel2nd(results)

M_  = results.M_;
std = diag(results.var).^0.5;
var = results.var;

% std inv / std y
vecMoments(1,1) = std(ismember(M_.endo_names,'loginv'))/std(ismember(M_.endo_names,'logy'));
% std dy / std y
vecMoments(2,1) = 0.01*std(ismember(M_.endo_names,'dshare'))/std(ismember(M_.endo_names,'logy'));
% std rfree / std y
vecMoments(3,1) = std(ismember(M_.endo_names,'rfree'))/std(ismember(M_.endo_names,'logy'));
% std inflation / std y
vecMoments(4,1) = std(ismember(M_.endo_names,'pii'))/std(ismember(M_.endo_names,'logy'));
% std c / std y
vecMoments(5,1) = std(ismember(M_.endo_names,'logc'))/std(ismember(M_.endo_names,'logy'));
% std lev / std y
vecMoments(6,1) = std(ismember(M_.endo_names,'lev'))/std(ismember(M_.endo_names,'logy'));
% std Fm / std y
vecMoments(7,1) = std(ismember(M_.endo_names,'Fagg'))/std(ismember(M_.endo_names,'logy'));
% std Fmu / std y
vecMoments(8,1) = std(ismember(M_.endo_names,'Fmu'))/std(ismember(M_.endo_names,'logy'));
% correlation emissions to y
vecMoments(9,1) = var(ismember(M_.endo_names,'loge'),ismember(M_.endo_names,'logy'))/(std(ismember(M_.endo_names,'loge'))*std(ismember(M_.endo_names,'logy')));
% correlation d/y to y
vecMoments(10,1) = var(ismember(M_.endo_names,'logy'),ismember(M_.endo_names,'dshare'))/(std(ismember(M_.endo_names,'logy'))*std(ismember(M_.endo_names,'dshare')));
% correlation leverage to y
vecMoments(11,1) = var(ismember(M_.endo_names,'lev'),ismember(M_.endo_names,'logy'))/(std(ismember(M_.endo_names,'lev'))*std(ismember(M_.endo_names,'logy')));
% correlation firm default to y
vecMoments(12,1) = var(ismember(M_.endo_names,'Fagg'),ismember(M_.endo_names,'logy'))/(std(ismember(M_.endo_names,'Fagg'))*std(ismember(M_.endo_names,'logy')));
% correlation bank failure to y
vecMoments(13,1) = var(ismember(M_.endo_names,'Fmu'),ismember(M_.endo_names,'logy'))/(std(ismember(M_.endo_names,'Fmu'))*std(ismember(M_.endo_names,'logy')));
% correlation bank failure to firm default
vecMoments(14,1) = var(ismember(M_.endo_names,'Fmu'),ismember(M_.endo_names,'Fagg'))/(std(ismember(M_.endo_names,'Fmu'))*std(ismember(M_.endo_names,'Fagg')));
% correlation firm default to infl
vecMoments(15,1) = var(ismember(M_.endo_names,'Fagg'),ismember(M_.endo_names,'pii'))/(std(ismember(M_.endo_names,'Fagg'))*std(ismember(M_.endo_names,'pii')));
% correlation bank failure to infl
vecMoments(16,1) = var(ismember(M_.endo_names,'Fmu'),ismember(M_.endo_names,'pii'))/(std(ismember(M_.endo_names,'Fmu'))*std(ismember(M_.endo_names,'pii')));

% DATA
vecMomentsData = [1.5; 0.97; 1.02; 0.68; 0.88; 0.93; 0.86; 0.33; ...
    0.78; -0.22; -0.58; -0.32; -0.32; 0.56; -0.33; -0.11];

varNAMES  = ["Model","Data"];
rowNAMES  = ["Std I/Std Y","Std DY/Std Y","Std R/Std Y","Std Infl/Std Y","Std C/Std Y","Std Lev/Std Y","Std F/Std Y","Std Fmu/Std Y",...
    "Corr Y-Emissions","Corr Y-DY","Corr Y-Lev","Corr Y-Firm Default","Corr Y-Bank Failure",...
    "Corr Firm-Bank Failure","Corr Infl-Firm Default","Corr Infl-Bank Default"];
out = table(vecMoments,vecMomentsData,'VariableNames',varNAMES,'RowNames',rowNAMES);  

end