%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  Sector-specific banks

%--------------------------------------------------------------------------
% Declare endogenous and exogenous variables
%--------------------------------------------------------------------------

var 
%---------------------------------- HOUSEHOLDS ----------------------------
    V           ${V}$               (long_name='welfare')   
    c           ${c}$               (long_name='consumption')   
    d           ${d}$               (long_name='deposits')
    dc
    df
    dn
    n           ${n}$               (long_name='labor demand')
    ns          ${\mathcal{N}}$     (long_name='labor supply')
    X1          ${X_1}$             (long_name='first auxiliary term')
    X2          ${X_2}$             (long_name='second auxiliary term')

%---------------------------------- FIRMS ----------------------------
    zc          ${z_c}$             (long_name='clean energy')
    zf          ${z_f}$             (long_name='fossil energy')
    ze          ${z_e}$             (long_name='energy bundle')
    zn          ${z_n}$             (long_name='non-energy good')
    ztilde      ${\widetilde{Z}}$   (long_name='intermediate good bundle')
    kc          ${k_c}$             (long_name='clean capital')
    kf          ${k_f}$             (long_name='fossil capital')
    kn          ${k_n}$             (long_name='non-energy capital')
    iic         ${i_c}$             (long_name='clean investment')
    iif         ${i_f}$             (long_name='fossil investment')
    iin         ${i_n}$             (long_name='non-energy investment')
    lc          ${l_c}$             (long_name='clean loans')
    lf          ${l_f}$             (long_name='fossil loans')
    lnon        ${l_n}$             (long_name='non-energy loans')
    e           ${e}$               (long_name='emissions')
    E           ${E}$               (long_name='emission stock')
    eta         ${\eta}$            (long_name='abatement effort')
    xi          ${\xi}$             (long_name='compliance cost per unit')
    y           ${y}$               (long_name='output') 

    %------------------------------ PRICES --------------------------------
    mc          ${mc}$              (long_name='marginal cost')
    pii         ${\pi}$             (long_name='gross inflation')
    w           ${w}$               (long_name='aggregate real wage')
    wstar       ${w^*}$             (long_name='optimal real wage')
    Delta       ${\Delta}$          (long_name='wage dispersion')
    psic        ${\psi_c}$          (long_name='clean capital price')
    psif        ${\psi_f}$          (long_name='fossil capital price')
    psin        ${\PSIN}$           (long_name='non-energy capital price')
    pc          ${p_c}$             (long_name='clean energy price')
    pf          ${p_g}$             (long_name='fossil energy price')
    pn          ${p_n}$             (long_name='non-energy price')
    rdep        ${r^D}$             (long_name='interest rate on deposits')
    rfree       ${r}$               (long_name='policy rate')

    %------------------------------ DEFAULT RISK -------------------------
    Xic         ${\Xi}$             (long_name='clean deposit financing wedge')
    Xif         ${\Xi}$             (long_name='fossil deposit financing wedge')
    Xin         ${\Xi}$             (long_name='non-energy deposit financing wedge')
    Rc          ${\mathcal{R}_c}$   (long_name='clean loan payoff')
    Rf          ${\mathcal{R}_f}$   (long_name='fossil loan payoff')
    Rn          ${\mathcal{R}_n}$   (long_name='non-energy loan payoff')
    mbarc       ${\overline{m}_c}$  (long_name='clean default threshold')
    mm1c        ${m1_c}$            (long_name='clean policy function slope')
    lambdac     ${\lambda_c}$       (long_name='multiplier clean risk')
    mbarf       ${\overline{m}_f}$  (long_name='fossil default threshold')
    mm1f        ${m1_f}$            (long_name='fossil policy function slope')
    lambdaf     ${\lambda_f}$       (long_name='multiplier fossil risk')
    mbarn       ${\overline{m}_n}$  (long_name='non-energy default threshold')
    mm1n        ${m1_n}$            (long_name='non-energy policy function slope')
    lambdan     ${\lambda_n}$       (long_name='multiplier non-energy risk')
    mubarc      ${\overline{\mu}}$  (long_name='clean bank failure threshold')
    mubarf      ${\overline{\mu}}$  (long_name='fossil bank failure threshold')
    mubarn      ${\overline{\mu}}$  (long_name='non-energy bank failure threshold')
    qc          ${q_c}$             (long_name='clean loan price')
    qf          ${q_f}$             (long_name='fossil loan price')
    qn          ${q_n}$             (long_name='non-energy loan price')
    Dqc         ${dq_c}$            (long_name='derivative of clean loan price')
    Dqf         ${dq_f}$            (long_name='derivative of fossil loan price')
    Dqn         ${dq_n}$            (long_name='derivative of non-energy loan price')
    Fc          ${F_c}$             (long_name='share of clean defaulters')
    Ff          ${F_f}$             (long_name='share of fossil defaulters')
    Fn          ${F_n}$             (long_name='share of non-energy defaulters')
    Fmuc        ${F_\mu}$           (long_name='share of clean bank defaulters')
    Fmuf        ${F_\mu}$           (long_name='share of fossil bank defaulters')
    Fmun        ${F_\mu}$           (long_name='share of non-energy bank defaulters')
    Gc          ${G_c}$             (long_name='aggregate productivity of clean defaulters')
    Gf          ${G_f}$             (long_name='aggregate productivity of fossil defaulters')
    Gn          ${G_n}$             (long_name='aggregate productivity of non-energy defaulters')
    Gmuc        ${G_\mu}$           (long_name='clean bank conditional expected productivity')
    Gmuf        ${G_\mu}$           (long_name='fossil bank conditional expected productivity')
    Gmun        ${G_\mu}$           (long_name='non-energy bank conditional expected productivity')
    DFc         ${f_c}$             (long_name='clean revenue pdf')
    DFf         ${f_f}$             (long_name='fossil revenue pdf')
    DFn         ${f_n}$             (long_name='non-energy revenue pdf')

    %------------------------------- DEFINITIONS -------------------------
    levc        
    levf  
    levn      
    lev

    recovc
    recovf
    recovn
    recov

    yieldc
    yieldf
    yieldn
    yieldrf
    yielddep

    Fmu
    Fagg
    kagg
    lagg
    
    dshare
    energyshare
    fossilshare

    logc
    logd
    loge
    loginv
    logloan
    logy

    %------------------------------ EXOGENOUS VARS ------------------------
    A
    KAPPAC
    KAPPAF
    KAPPAN
;

% STOCHASTIC PROCESSES
varexo 
    eps_A
    eps_R
;

%------------------------------------------------------------------------
% Declare model parameters
%------------------------------------------------------------------------

parameters  BETA    ${\beta}$       (long_name='discount factor - household')
            GAMMA_C ${\gamma_C}$    (long_name='risk aversion - household')
            OMEGA_D ${\omega_D}$    (long_name='scaling parameter MIU')
            GAMMA_D ${\gamma_D}$    (long_name='MIU curvature')
            OMEGA_N ${\OMEGA_N}$    (long_name='scaling parameter labour disutility')
            GAMMA_N ${\GAMMA_N}$    (long_name='Frisch elasticity of labour supply')

            ALPHA   ${\theta}$      (long_name='Cobb-Douglas parameter - final good')
            DELTAE  ${\delta_E}$    (long_name='emission decay')
            DELTAK  ${\delta_K}$    (long_name='depreciation rate')
            PSID    ${\psi_D}$      (long_name='emission damage parameter')
            PSII    ${\psi_K}$      (long_name='inv adjustment parameter')
            PSIN    ${\PSIN}$      (long_name='sticky wage share')
            PSIP    ${\psi_P}$      (long_name='price adjustment parameter')
            PHI     ${\phi}$        (long_name='final good CES')
            PHITILDE${\tilde \phi}$ (long_name='labor CES')
            NUTILDE ${\tilde \nu}$  (long_name='Energy weight')
            EPSTILDE${\tilde \epsilon}$ (long_name='Non-energy-energy CES')
            NU      ${\nu}$         (long_name='Clean energy weight')
            EPS     ${\epsilon}$    (long_name='Fossil-clean energy CES')
            THETA1  ${\eta_0}$      (long_name='abatement cost slope')
            THETA2  ${\eta_1}$      (long_name='abatement cost curvature')

            BETAE   ${\beta_E}$     (long_name='discount factor - firm')
            VARPHI  ${\varphi}$     (long_name='default cost')
            SDEVM   ${\sigma_M}$    (long_name='stdev firm productivity')
            MEANM   ${\mu_M}$       (long_name='mean firm productivity')
            SDEVMU  ${\sigma_MU}$   (long_name='stdev bank productivity')
            MEANMU  ${\mu_MU}$      (long_name='mean bank productivity')
            CHI     ${\chi}$        (long_name='maturity parameter')
            ZETA    ${\zeta}$       (long_name='bailout cost')
            
            PHI_PI  ${\phi_\pi}$    (long_name='interest rate response to inflation')
            SIGMA_R ${\sigma_R}$    (long_name='std. deviation mp shock')    

            KAPPACss
            KAPPAFss
            KAPPANss
            TAXE

            RHO_A   ${\rho_A}$      (long_name='persistence tfp')
            SIGMA_A ${\sigma_A}$    (long_name='std. deviation tfp shock')
            ;

%------------------------------------------------------------------------
% Model equations
%------------------------------------------------------------------------

model;

%__________________________________________________________________________
%                       HOUSEHOLDS 

[name='Welfare']
V = c^(1-GAMMA_C)/(1-GAMMA_C) - OMEGA_N * ns^(1+GAMMA_N)/(1+GAMMA_N) + OMEGA_D*d^(1-GAMMA_D)/(1-GAMMA_D) + BETA*V(+1);

[name='Euler equation deposits']
1 = BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C) * (1+rdep) / pii(+1) + OMEGA_D * d^(-GAMMA_D) / c^(-GAMMA_C);

[name='Euler equation risk-free rate']
1 = BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C) * (1+rfree) / pii(+1);

[name='First auxiliary term']
X1 = w^PHITILDE * n * c^(-GAMMA_C) + BETA * PSIN * pii(+1)^(PHITILDE-1) * X1(+1);

[name='Second auxiliary term']
X2 = w^(PHITILDE*(1+GAMMA_N)) * OMEGA_N*n^(1+GAMMA_N) + BETA * PSIN * pii(+1)^(PHITILDE*(1+GAMMA_N)) * X2(+1);

[name='Optimal wage']
wstar^(1+PHITILDE*GAMMA_N) * X1 = X2;

[name='Law of motion aggregate wage']
w^(1-PHITILDE) = PSIN * (w(-1)/pii)^(1-PHITILDE) + (1-PSIN)*wstar^(1-PHITILDE);

[name='Labor supply']
ns = Delta*n;

[name='Law of motion wage dispersion']
Delta^(1+GAMMA_N) = (1-PSIN) * (wstar/w)^(-PHITILDE*(1+GAMMA_N)) + PSIN * (w*pii/w(-1))^(PHITILDE*(1+GAMMA_N)) * Delta(-1)^(1+GAMMA_N);

%__________________________________________________________________________ 
%                       FINAL PRODUCERS

[name='New Keynesian Phillips Curve']
pii * (pii-1) = BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C) * y(+1) / y * pii(+1) * (pii(+1)-1) + PHI/PSIP * (mc-(PHI-1)/PHI);

[name='Final production']
y = A * exp(-E*PSID) * ztilde^ALPHA * n^(1-ALPHA);

[name='Intermediate bundle']
ztilde = (NUTILDE * ze^((EPSTILDE-1)/EPSTILDE) + (1-NUTILDE) * zn^((EPSTILDE-1)/EPSTILDE))^(EPSTILDE/(EPSTILDE-1));

[name='Energy bundle']
ze = (NU * zc^((EPS-1)/EPS) + (1-NU) * zf^((EPS-1)/EPS))^(EPS/(EPS-1));

[name='Demand for clean energy']
ALPHA * mc * NUTILDE * NU * (y/ztilde) * (ztilde/ze)^(1/EPSTILDE) * (ze/zc)^(1/EPS) = pc;

[name='Demand for fossil energy']
ALPHA * mc * NUTILDE * (1-NU) * (y/ztilde) * (ztilde/ze)^(1/EPSTILDE) * (ze/zf)^(1/EPS) = pf;

[name='Demand for non-energy good']
ALPHA * mc * (1-NUTILDE) * (y/ztilde) * (ztilde/zn)^(1/EPSTILDE) = pn;

[name='Labor demand']
(1-ALPHA) * mc * y / n = w;

%__________________________________________________________________________ 
%                       NON-ENERGY FIRMS

[name='Non-energy default threshold']
mbarn = CHI*lnon(-1)/(pii*pn*kn(-1));

[name='Realized non-energy loan payoff']
Rn = CHI*(Gn/mbarn + (1-Fn) - Fn*VARPHI)/pii + (1-CHI)*qn;

[name='FOC for non-energy loans']
qn - lambdan*mbarn(+1)/lnon = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fn(+1))+(1-CHI)*qn(+1)) / pii(+1);                

[name='FOC for non-energy capital']
psin - lambdan*mbarn(+1)/kn = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * ( (1-DELTAK)*psin(+1) + pn(+1)*(1-Gn(+1)) );

[name='FOC for non-energy risk']
- lambdan - Dqn*(lnon-(1-CHI)*lnon(-1)/pii) = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (lnon(+1)-(1-CHI)*lnon/pii(+1))*Dqn(+1)*mm1n;

[name='Condition on non-energy policy function']
qn + mbarn(+1)*Dqn = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fn(+1)) + (1-CHI)*(qn(+1)+Dqn(+1)*mbarn(+1)*mm1n)) / pii(+1);

[name='Price of non-energy capital']
psin = 1 + 0.5*PSII*(iin/iin(-1)-1)^2 + PSII*(iin/iin(-1)-1)*( iin/iin(-1) ) - (BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C))*PSII*(iin(+1)/iin-1)*(iin(+1)/iin)^2;

[name='Non-energy production']
zn = kn(-1);

[name='Law of motion non-energy capital']
kn = (1-DELTAK)*kn(-1) + iin;

%__________________________________________________________________________
%                       CLEAN ENERGY FIRMS

[name='Clean default threshold']
mbarc = CHI*lc(-1)/(pii*pc*kc(-1));

[name='Realized clean loan payoff']
Rc = CHI*(Gc/mbarc + 1-Fc - Fc*VARPHI)/pii + (1-CHI)*qc;

[name='FOC for clean loans']
qc - lambdac*mbarc(+1)/lc = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fc(+1))+(1-CHI)*qc(+1)) / pii(+1);                

[name='FOC for clean capital']
psic - lambdac*mbarc(+1)/kc = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * ( (1-DELTAK)*psic(+1) + pc(+1)*(1-Gc(+1)) );

[name='FOC for clean risk']
- lambdac - Dqc*(lc-(1-CHI)*lc(-1)/pii) = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (lc(+1)-(1-CHI)*lc/pii(+1))*Dqc(+1)*mm1c;

[name='Condition on clean policy function']
qc + mbarc(+1)*Dqc = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fc(+1)) + (1-CHI)*(qc(+1)+Dqc(+1)*mbarc(+1)*mm1c)) / pii(+1);

[name='Price of clean capital']
psic = 1 + 0.5*PSII*(iic/iic(-1)-1)^2 + PSII*(iic/iic(-1)-1)*( iic/iic(-1) ) - ((BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C)))*PSII*(iic(+1)/iic-1)*(iic(+1)/iic)^2;

[name='Clean production']
zc = kc(-1);

[name='Law of motion clean capital']
kc = (1-DELTAK)*kc(-1) + iic;

%__________________________________________________________________________
%                       FOSSIL ENERGY FIRMS

[name='Fossil default threshold']
mbarf = CHI*lf(-1)/(pii*(pf-xi)*kf(-1));

[name='Realized fossil loan payoff']
Rf = CHI*(Gf/mbarf + 1-Ff - Ff*VARPHI)/pii + (1-CHI)*qf;

[name='FOC for fossil loans']
qf - lambdaf*mbarf(+1)/lf = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Ff(+1))+(1-CHI)*qf(+1)) / pii(+1);                

[name='FOC for fossil capital']
psif - lambdaf*mbarf(+1)/kf = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * ( (1-DELTAK)*psif(+1) + (pf(+1)-xi(+1))*(1-Gf(+1)) );

[name='FOC for fossil risk']
- lambdaf - Dqf*(lf-(1-CHI)*lf(-1)/pii) = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (lf(+1)-(1-CHI)*lf/pii(+1))*Dqf(+1)*mm1f;

[name='Condition on fossil policy function']
qf + mbarf(+1)*Dqf = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Ff(+1)) + (1-CHI)*(qf(+1)+Dqf(+1)*mbarf(+1)*mm1f)) / pii(+1);

[name='Price of fossil capital']
psif = 1 + 0.5*PSII*(iif/iif(-1)-1)^2 + PSII*(iif/iif(-1)-1)*( iif/iif(-1) ) - (BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C))*PSII*(iif(+1)/iif-1)*(iif(+1)/iif)^2;

[name='Fossil production']
zf = kf(-1);

[name='Abatement effort']
eta = (TAXE/THETA1)^(1/THETA2);

[name='Emissions']
e = (1-eta)*zf;

[name='Emission stock']
E = e + DELTAE*E(-1);

[name='Compliance cost per unit']
xi = TAXE*(1-eta) + THETA1/(1+THETA2)*eta^(1+THETA2);

[name='Law of motion fossil capital']
kf = (1-DELTAK)*kf(-1) + iif;

%__________________________________________________________________________
%                       BANKS 

[name='Break-even condition clean loans']
qc = ( (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Gmuc(+1)) + (1-KAPPAC)*Xic ) * Rc(+1);

[name='Derivative of clean loan price']
Dqc = ( BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*(1-Gmuc(+1)) + (1-KAPPAC)*Xic ) * ( -CHI*(Gc(+1)/mbarc(+1)^2 + VARPHI*DFc(+1))/pii(+1) + (1-CHI)*Dqc(+1)*mm1c);

[name='Break-even condition fossil loans']
qf = ( (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Gmuf(+1)) + (1-KAPPAF)*Xif ) * Rf(+1);

[name='Derivative of fossil loan price']
Dqf = ( BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*(1-Gmuf(+1)) + (1-KAPPAF)*Xif ) * ( -CHI*(Gf(+1)/mbarf(+1)^2 + VARPHI*DFf(+1))/pii(+1) + (1-CHI)*Dqf(+1)*mm1f);

[name='Break-even condition non-energy loans']
qn = ( (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Gmun(+1)) + (1-KAPPAN)*Xin ) * Rn(+1);

[name='Derivative of non-energy loan price']
Dqn = ( BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*(1-Gmun(+1)) + (1-KAPPAN)*Xin ) * ( -CHI*(Gn(+1)/mbarn(+1)^2 + VARPHI*DFn(+1))/pii + (1-CHI)*Dqn(+1)*mm1n);

[name='Clean bank equity constraint']
(1+rdep)*dc = (1-KAPPAC)*Rc(+1)*lc;

[name='Fossil bank equity constraint']
(1+rdep)*df = (1-KAPPAF)*Rf(+1)*lf;

[name='Non-energy bank equity constraint']
(1+rdep)*dn = (1-KAPPAN)*Rn(+1)*lnon;

[name='Clean deposit financing wedge']
Xic = pii(+1)/(1+rdep) - (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Fmuc(+1));

[name='Fossil deposit financing wedge']
Xif = pii(+1)/(1+rdep) - (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Fmuf(+1));

[name='Non-energy deposit financing wedge']
Xin = pii(+1)/(1+rdep) - (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Fmun(+1));

[name='Clean bank failure threshold']
mubarc = ((1+rdep(-1))*dc(-1))/(pii*Rc*lc(-1));

[name='Fossil bank failure threshold']
mubarf = ((1+rdep(-1))*df(-1))/(pii*Rf*lf(-1));

[name='Non-energy bank failure threshold']
mubarn = ((1+rdep(-1))*dn(-1))/(pii*Rn*lnon(-1));

%__________________________________________________________________________
%                        MONETARY POLICY

[name='Monetary Policy Rule']
rfree =  1/BETA-1 + PHI_PI*(pii-1) + SIGMA_R*eps_R;

%__________________________________________________________________________
%                       MARKET CLEARING 

[name='Goods market']
y = c + iic*(1+0.5*PSII*(iic/iic(-1)-1)^2) + iif*(1+0.5*PSII*(iif/iif(-1)-1)^2) + iin*(1+0.5*PSII*(iin/iin(-1)-1)^2) +
    THETA1/(1+THETA2)*eta^(1+THETA2)*zf + ZETA*(Fmuc*dc + Fmuf*df + Fmun*dn) + 0.5*PSIP*(pii-1)^2*y + CHI*VARPHI*(Fc*lc(-1)+Ff*lf(-1)+Fn*lnon(-1));

[name='Deposit market']
d = dc + df + dn;

%__________________________________________________________________________
%                       DEFAULT 

Fc  = normcdf((log(mbarc)-MEANM)/SDEVM);
Ff  = normcdf((log(mbarf)-MEANM)/SDEVM);
Fn  = normcdf((log(mbarn)-MEANM)/SDEVM);
Fmuc = normcdf((log(mubarc)-MEANMU)/SDEVMU);
Fmuf = normcdf((log(mubarf)-MEANMU)/SDEVMU);
Fmun = normcdf((log(mubarn)-MEANMU)/SDEVMU);
Gc  = normcdf((log(mbarc)-MEANM-SDEVM^2)/SDEVM);
Gf  = normcdf((log(mbarf)-MEANM-SDEVM^2)/SDEVM);
Gn  = normcdf((log(mbarn)-MEANM-SDEVM^2)/SDEVM);
Gmuc = normcdf((log(mubarc)-MEANMU-SDEVMU^2)/SDEVMU);
Gmuf = normcdf((log(mubarf)-MEANMU-SDEVMU^2)/SDEVMU);
Gmun = normcdf((log(mubarn)-MEANMU-SDEVMU^2)/SDEVMU);
DFc = (normpdf((log(mbarc)-MEANM)/SDEVM))/(SDEVM*mbarc);
DFf = (normpdf((log(mbarf)-MEANM)/SDEVM))/(SDEVM*mbarf);
DFn = (normpdf((log(mbarn)-MEANM)/SDEVM))/(SDEVM*mbarn);

%__________________________________________________________________________
%                       SHOCKS

[name='TFP']
log(A) = RHO_A*log(A(-1)) + SIGMA_A*eps_A ;

%__________________________________________________________________________
%                       POLICY

KAPPAC = KAPPACss;
KAPPAF = KAPPAFss;
KAPPAN = KAPPANss;

%__________________________________________________________________________
%                       DEFINITIONS

kagg = kc + kf + kn;
lagg = lc + lf + lnon;
Fagg = (lc(-1)*Fc + lf(-1)*Ff + lnon(-1)*Fn)/lagg(-1);
Fmu = (dc(-1)*Fmuc + df(-1)*Fmuf + dn(-1)*Fmun)/d(-1);

recovc = Gc/(Fc*mbarc)-VARPHI;
recovf = Gf/(Ff*mbarf)-VARPHI;
recovn = Gn/(Fn*mbarn)-VARPHI;
recov = (lc(-1)*recovc + lf(-1)*recovf + lnon(-1)*recovn)/lagg(-1);

levc = lc/kc;
levf = lf/kf;
levn = lnon/kn;
lev = (lc(-1)*levc + lf(-1)*levf + lnon(-1)*levn)/(lagg(-1));

yieldc      = 10000*(1+CHI/qc-CHI)-10000;
yieldf      = 10000*(1+CHI/qf-CHI)-10000;
yieldn      = 10000*(1+CHI/qn-CHI)-10000;
yieldrf     = 10000*(1+rfree)-10000;
yielddep    = 10000*(1+rdep)-10000;

dshare = 100*d/y;
energyshare = 100*(pc*zc + pf*zf)/(mc*y);
fossilshare = 100*(1-eta)*zf/(zf+zc);

logc = log(c);
logd = log(d);
loge = log(e);
loginv = log(iic + iif + iin);
logloan = log(lc + lf + lnon);
logy = log(y);

end;

steady;
%check;

%------------------------------------------------------------------------
% Declare shocks
%------------------------------------------------------------------------

shocks;
var eps_A; stderr 1;
var eps_R; stderr 1;
end;

%------------------------------------------------------------------------
% Simulation
%------------------------------------------------------------------------
stoch_simul(order=@{perorder},irf=@{nirf},periods=@{nperiods},nocorr,nograph,noprint);