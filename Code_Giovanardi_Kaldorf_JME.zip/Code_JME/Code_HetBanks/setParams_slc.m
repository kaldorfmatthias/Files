function par = setParams_slc()

par = setParams_structural();

% bank regulation
par.KAPPACss    = 0.08;    % clean
par.KAPPAFss    = 0.08;    % fossil reward
par.KAPPAFPEN   = 1;       % fossil penalty
par.KAPPANss    = 0.08;    % non-energy

% climate policy
par.TAXE        = 0.00;    % emission tax 
par.TAXK        = 0.0;    % fossil capital tax

end