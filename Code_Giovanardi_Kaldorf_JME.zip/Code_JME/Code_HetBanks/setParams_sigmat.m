function par = setParams_sigmat()

par = setParams_structural();

% policy
par.KAPPACss    = 0.08;
par.KAPPAFss    = 0.08;
par.KAPPANss    = 0.08;    
par.TAXEss      = 0.002;

par.RHO_T    	= 0.8;    % persistence tax
par.SIGMA_T  	= 0.002;   % standard deviation tax shock

end