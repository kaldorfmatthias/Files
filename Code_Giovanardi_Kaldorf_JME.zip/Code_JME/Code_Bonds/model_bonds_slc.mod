%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  Extension with bonds, sustainability linked capital requirements

%--------------------------------------------------------------------------
% Declare endogenous and exogenous variables
%--------------------------------------------------------------------------

var 
%---------------------------------- HOUSEHOLDS ----------------------------
    V           ${V}$               (long_name='welfare')   
    c           ${c}$               (long_name='consumption')   
    d           ${d}$               (long_name='deposits')
    n           ${n}$               (long_name='labor demand')
    ns          ${\mathcal{N}}$     (long_name='labor supply')
    X1          ${X_1}$             (long_name='first auxiliary term')
    X2          ${X_2}$             (long_name='second auxiliary term')

%---------------------------------- FIRMS ----------------------------
    zc          ${z_c}$             (long_name='clean energy')
    zf          ${z_f}$             (long_name='fossil energy')
    ze          ${z_e}$             (long_name='energy bundle')
    zn          ${z_n}$             (long_name='non-energy good')
    ztilde      ${\widetilde{Z}}$   (long_name='intermediate good bundle')
    kc          ${k_c}$             (long_name='clean capital')
    kf          ${k_f}$             (long_name='fossil capital')
    kn          ${k_n}$             (long_name='non-energy capital')
    iic         ${i_c}$             (long_name='clean investment')
    iif         ${i_f}$             (long_name='fossil investment')
    iin         ${i_n}$             (long_name='non-energy investment')
    lc          ${l_c}$             (long_name='clean loans')
    lf          ${l_f}$             (long_name='fossil loans')
    lnon        ${l_n}$             (long_name='non-energy loans')
    bf          ${b_f}$             (long_name='fossil bonds')
    e           ${e}$               (long_name='emissions')
    eta         ${\eta}$            (long_name='abatement effort')
    xi          ${\xi}$             (long_name='compliance cost per unit')
    y           ${y}$               (long_name='output') 

    %------------------------------ PRICES --------------------------------
    mc          ${mc}$              (long_name='marginal cost')
    pii         ${\pi}$             (long_name='gross inflation')
    w           ${w}$               (long_name='aggregate real wage')
    wstar       ${w^*}$             (long_name='optimal real wage')
    Delta       ${\Delta}$          (long_name='wage dispersion')
    psic        ${\psi_c}$          (long_name='clean capital price')
    psif        ${\psi_f}$          (long_name='fossil capital price')
    psin        ${\PSIN}$          (long_name='non-energy capital price')
    pc          ${p_c}$             (long_name='clean energy price')
    pf          ${p_g}$             (long_name='fossil energy price')
    pn          ${p_n}$             (long_name='non-energy price')
    rdep        ${r^D}$             (long_name='interest rate on deposits')
    rfree       ${r}$               (long_name='policy rate')

    %------------------------------ DEFAULT RISK -------------------------
    Xi          ${\Xi}$             (long_name='deposit financing wedge')
    Rbf         ${\mathcal{R}_f}$   (long_name='fossil bond payoff')
    Rlc         ${\mathcal{R}_c}$   (long_name='clean loan payoff')
    Rlf         ${\mathcal{R}_f}$   (long_name='fossil loan payoff')
    Rln         ${\mathcal{R}_n}$   (long_name='non-energy loan payoff')
    mbarc       ${\overline{m}_c}$  (long_name='clean default threshold')
    mm1c        ${m1_c}$            (long_name='clean policy function slope')
    lambdac     ${\lambda_c}$       (long_name='multiplier clean risk')
    mbarf       ${\overline{m}_f}$  (long_name='fossil default threshold')
    mm1f        ${m1_f}$            (long_name='fossil policy function slope')
    lambdaf     ${\lambda_f}$       (long_name='multiplier fossil risk')
    mbarn       ${\overline{m}_n}$  (long_name='non-energy default threshold')
    mm1n        ${m1_n}$            (long_name='non-energy policy function slope')
    lambdan     ${\lambda_n}$       (long_name='multiplier non-energy risk')
    mubar       ${\overline{\mu}}$  (long_name='bank failure threshold')

    qbf         ${q_f}$             (long_name='fossil bond price')
    qlc         ${q_c}$             (long_name='clean loan price')
    qlf         ${q_f}$             (long_name='fossil loan price')
    qln         ${q_n}$             (long_name='non-energy loan price')
    Dqbf        ${dq_f}$            (long_name='derivative of fossil bond price')
    Dqlc        ${dq_c}$            (long_name='derivative of clean loan price')
    Dqlf        ${dq_f}$            (long_name='derivative of fossil loan price')
    Dqln        ${dq_n}$            (long_name='derivative of non-energy loan price')

    Fc          ${F_c}$             (long_name='share of clean defaulters')
    Ff          ${F_f}$             (long_name='share of fossil defaulters')
    Fn          ${F_n}$             (long_name='share of non-energy defaulters')
    Fmu         ${F_\mu}$           (long_name='share of bank defaulters')
    Gc          ${G_c}$             (long_name='aggregate productivity of clean defaulters')
    Gf          ${G_f}$             (long_name='aggregate productivity of fossil defaulters')
    Gn          ${G_n}$             (long_name='aggregate productivity of non-energy defaulters')
    Gmu         ${G_\mu}$           (long_name='bank conditional expected productivity')
    DFc         ${f_c}$             (long_name='clean revenue pdf')
    DFf         ${f_f}$             (long_name='fossil revenue pdf')
    DFn         ${f_n}$             (long_name='non-energy revenue pdf')

    %------------------------------- DEFINITIONS -------------------------
    Fagg
    kagg
    lagg

    levc        
    levf  
    levn      
    lev

    recovc
    recovf
    recovn
    recov

    yieldc
    yieldf
    yieldn
    yieldrf
    yielddep

    bshare
    dshare
    energyshare
    fossilshare

    %------------------------------ EXOGENOUS VARS ------------------------
    A
    KAPPAC
    KAPPAF
    KAPPAFSTAR
    KAPPAN
;

% STOCHASTIC PROCESSES
varexo 
    eps_A
    eps_R
;

%------------------------------------------------------------------------
% Declare model parameters
%------------------------------------------------------------------------

parameters  BETA    ${\beta}$       (long_name='discount factor - household')
            GAMMA_C ${\gamma_C}$    (long_name='risk aversion - household')
            OMEGA_D ${\omega_D}$    (long_name='scaling parameter MIU')
            GAMMA_D ${\gamma_D}$    (long_name='MIU curvature')
            OMEGA_N ${\OMEGA_N}$    (long_name='scaling parameter labour disutility')
            GAMMA_N ${\GAMMA_N}$    (long_name='Frisch elasticity of labour supply')

            ALPHA   ${\theta}$      (long_name='Cobb-Douglas parameter - final good')
            DELTAK  ${\delta_K}$    (long_name='depreciation rate')
            PSIB    ${\psi_B}$      (long_name='adjustment cost bond share')
            PSID    ${\psi_D}$      (long_name='emission damage parameter')
            PSII    ${\psi_K}$      (long_name='inv adjustment parameter')
            PSIN    ${\PSIN}$      (long_name='sticky wage share')
            PSIP    ${\psi_P}$      (long_name='price adjustment parameter')
            PHI     ${\phi}$        (long_name='final good CES')
            PHITILDE${\tilde \phi}$ (long_name='labor CES')
            NUTILDE ${\tilde \nu}$  (long_name='Energy weight')
            EPSTILDE${\tilde \epsilon}$ (long_name='Non-energy-energy CES')
            NU      ${\nu}$         (long_name='Clean energy weight')
            EPS     ${\epsilon}$    (long_name='Fossil-clean energy CES')
            THETA1  ${\eta_0}$      (long_name='abatement cost slope')
            THETA2  ${\eta_1}$      (long_name='abatement cost curvature')

            BETAE   ${\beta_E}$     (long_name='discount factor - firm')
            BETAF   ${\beta_F}$     (long_name='discount factor - fossil firm')
            VARPHI  ${\varphi}$     (long_name='restructuring cost')
            VARPHITILDE ${\widetilde \varphi}$ (long_name='monitoring cost')
            SDEVF   ${\sigma_M}$    (long_name='stdev fossil firm productivity')
            MEANF   ${\sigma_M}$    (long_name='mean fossil firm productivity')
            SDEVM   ${\sigma_M}$    (long_name='stdev firm productivity')
            MEANM   ${\mu_M}$       (long_name='mean firm productivity')
            SDEVMU  ${\sigma_MU}$   (long_name='stdev bank productivity')
            MEANMU  ${\mu_MU}$      (long_name='mean bank productivity')
            CHI     ${\chi}$        (long_name='maturity parameter')
            ZETA    ${\zeta}$       (long_name='bailout cost')
            
            PHI_PI  ${\phi_\pi}$    (long_name='interest rate response to inflation')
            SIGMA_R ${\sigma_R}$    (long_name='std. deviation mp shock')    

            KAPPACss
            KAPPAFss
            KAPPAFPEN
            KAPPANss
            TAXE
            TAXK

            RHO_A   ${\rho_A}$      (long_name='persistence tfp')
            SIGMA_A ${\sigma_A}$    (long_name='std. deviation tfp shock')
            ;

%------------------------------------------------------------------------
% Model equations
%------------------------------------------------------------------------
model;

%__________________________________________________________________________
%                       HOUSEHOLDS 

[name='Welfare']
V = c^(1-GAMMA_C)/(1-GAMMA_C) - OMEGA_N * ns^(1+GAMMA_N)/(1+GAMMA_N) + OMEGA_D*d^(1-GAMMA_D)/(1-GAMMA_D) + BETA*V(+1);

[name='Euler equation deposits']
1 = BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C) * (1+rdep) / pii(+1) + OMEGA_D * d^(-GAMMA_D) / c^(-GAMMA_C);

[name='Euler equation risk-free rate']
1 = BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C) * (1+rfree) / pii(+1);

[name='First auxiliary term']
X1 = w^PHITILDE * n * c^(-GAMMA_C) + BETA * PSIN * pii(+1)^(PHITILDE-1) * X1(+1);

[name='Second auxiliary term']
X2 = w^(PHITILDE*(1+GAMMA_N)) * OMEGA_N*n^(1+GAMMA_N) + BETA * PSIN * pii(+1)^(PHITILDE*(1+GAMMA_N)) * X2(+1);

[name='Optimal wage']
wstar^(1+PHITILDE*GAMMA_N) * X1 = X2;

[name='Law of motion aggregate wage']
w^(1-PHITILDE) = PSIN * (w(-1)/pii)^(1-PHITILDE) + (1-PSIN)*wstar^(1-PHITILDE);

[name='Labor supply']
ns = Delta*n;

[name='Law of motion wage dispersion']
Delta^(1+GAMMA_N) = (1-PSIN) * (wstar/w)^(-PHITILDE*(1+GAMMA_N)) + PSIN * (w*pii/w(-1))^(PHITILDE*(1+GAMMA_N)) * Delta(-1)^(1+GAMMA_N);

%__________________________________________________________________________ 
%                       FINAL PRODUCERS

[name='New Keynesian Phillips Curve']
pii * (pii-1) = BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C) * y(+1) / y * pii(+1) * (pii(+1)-1) + PHI/PSIP * (mc-(PHI-1)/PHI);

[name='Final production']
y = A * exp(-PSID*e) * ztilde^ALPHA * n^(1-ALPHA);

[name='Intermediate bundle']
ztilde = (NUTILDE*ze^((EPSTILDE-1)/EPSTILDE) + (1-NUTILDE)*zn^((EPSTILDE-1)/EPSTILDE))^(EPSTILDE/(EPSTILDE-1));

[name='Energy bundle']
ze = (NU*zc^((EPS-1)/EPS) + (1-NU)*zf^((EPS-1)/EPS))^(EPS/(EPS-1));

[name='Demand for clean energy']
ALPHA * NUTILDE * NU * mc * (y/ztilde) * (ztilde/ze)^(1/EPSTILDE) * (ze/zc)^(1/EPS) = pc;

[name='Demand for fossil energy']
ALPHA * NUTILDE * (1-NU) * mc * (y/ztilde) * (ztilde/ze)^(1/EPSTILDE) * (ze/zf)^(1/EPS) = pf;

[name='Demand for non-energy good']
ALPHA * (1-NUTILDE) * mc * (y/ztilde) * (ztilde/zn)^(1/EPSTILDE) = pn;

[name='Labor demand']
(1-ALPHA) * mc * y / n = w;

%__________________________________________________________________________ 
%                       NON-ENERGY FIRMS

[name='Non-energy default threshold']
mbarn = CHI*lnon(-1)/(pii*pn*kn(-1));

[name='Realized non-energy loan payoff']
Rln = CHI*(Gn/mbarn + (1-Fn) - Fn*VARPHI)/pii + (1-CHI)*qln;

[name='FOC for non-energy loans']
qln - lambdan*mbarn(+1)/lnon = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fn(+1))+(1-CHI)*qln(+1)) / pii(+1);                

[name='FOC for non-energy capital']
psin - lambdan*mbarn(+1)/kn = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * ( (1-DELTAK)*psin(+1) + pn(+1)*(1-Gn(+1)) );

[name='FOC for non-energy risk']
- lambdan - Dqln*(lnon-(1-CHI)*lnon(-1)/pii) = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * mm1n*(lnon(+1)-(1-CHI)*lnon/pii(+1))*Dqln(+1);

[name='Condition on non-energy policy function']
qln + mbarn(+1)*Dqln = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fn(+1)) + (1-CHI)*(qln(+1)+Dqln(+1)*mbarn(+1)*mm1n)) / pii(+1);

[name='Price of non-energy capital']
psin = 1 + 0.5*PSII*(iin/iin(-1)-1)^2 + PSII*(iin/iin(-1)-1)*( iin/iin(-1) ) - (BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C))*PSII*(iin(+1)/iin-1)*(iin(+1)/iin)^2;

[name='Non-energy production']
zn = kn(-1);

[name='Law of motion non-energy capital']
kn = (1-DELTAK)*kn(-1) + iin;

%__________________________________________________________________________
%                       CLEAN ENERGY FIRMS

[name='Clean default threshold']
mbarc = CHI*lc(-1)/(pii*pc*kc(-1));

[name='Realized clean loan payoff']
Rlc = CHI*(Gc/mbarc + 1-Fc - Fc*VARPHI)/pii + (1-CHI)*qlc;

[name='FOC for clean loans']
qlc - lambdac*mbarc(+1)/lc = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fc(+1))+(1-CHI)*qlc(+1)) / pii(+1);                

[name='FOC for clean capital']
psic - lambdac*mbarc(+1)/kc = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * ( (1-DELTAK)*psic(+1) + pc(+1)*(1-Gc(+1)) );

[name='FOC for clean risk']
- lambdac - Dqlc*(lc-(1-CHI)*lc(-1)/pii) = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * mm1c*(lc(+1)-(1-CHI)*lc/pii(+1))*Dqlc(+1);

[name='Condition on clean policy function']
qlc + mbarc(+1)*Dqlc = BETAE*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Fc(+1)) + (1-CHI)*(qlc(+1)+Dqlc(+1)*mbarc(+1)*mm1c)) / pii(+1);

[name='Price of clean capital']
psic = 1 + 0.5*PSII*(iic/iic(-1)-1)^2 + PSII*(iic/iic(-1)-1)*(iic/iic(-1)) - BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*PSII*(iic(+1)/iic-1)*(iic(+1)/iic)^2;

[name='Clean production']
zc = kc(-1);

[name='Law of motion clean capital']
kc = (1-DELTAK)*kc(-1) + iic;

%__________________________________________________________________________
%                       FOSSIL ENERGY FIRMS

[name='Fossil default threshold']
mbarf = CHI*(bf(-1)+lf(-1))/(pii*(pf-xi)*kf(-1));

[name='Realized fossil bond payoff']
Rbf = CHI*(1-Ff)/pii + (1-CHI)*qbf;

[name='Realized fossil loan payoff']
Rlf = CHI*(Gf/mbarf + 1-Ff - Ff*VARPHI)/pii + (1-CHI)*qlf - VARPHITILDE;

[name='FOC for fossil bonds']
qbf - lambdaf*mbarf(+1)/(bf+lf) - PSIB*(bf-lf) = BETAF*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Ff(+1))+(1-CHI)*qbf(+1)) / pii(+1);                

[name='FOC for fossil loans']
qlf - lambdaf*mbarf(+1)/(bf+lf) + PSIB*(bf-lf) = BETAF*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Ff(+1))+(1-CHI)*qlf(+1)) / pii(+1);                

[name='FOC for fossil capital']
psif*(1+TAXK) - lambdaf*mbarf(+1)/kf = BETAF*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * ( (1-DELTAK)*psif(+1)*(1+TAXK) + (pf(+1)-xi(+1))*(1-Gf(+1)) );

[name='FOC for fossil risk']
- lambdaf - Dqbf*(bf-(1-CHI)*bf(-1)/pii) - Dqlf*(lf-(1-CHI)*lf(-1)/pii) = BETAF*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * mm1f*( (bf(+1)-(1-CHI)*bf/pii(+1))*Dqbf(+1) + (lf(+1)-(1-CHI)*lf/pii(+1))*Dqlf(+1) );

[name='Condition on fossil policy function']
qlf + mbarf(+1)*Dqlf = BETAF*c(+1)^(-GAMMA_C)/c^(-GAMMA_C) * (CHI*(1-Ff(+1)) + (1-CHI)*(qlf(+1)+Dqlf(+1)*mbarf(+1)*mm1f)) / pii(+1);

[name='Price of fossil capital']
psif = 1 + 0.5*PSII*(iif/iif(-1)-1)^2 + PSII*(iif/iif(-1)-1)*( iif/iif(-1) ) - (BETA * c(+1)^(-GAMMA_C) / c^(-GAMMA_C))*PSII*(iif(+1)/iif-1)*(iif(+1)/iif)^2;

[name='Fossil production']
zf = kf(-1);

[name='Abatement effort']
eta = (( TAXE + (KAPPAFPEN-KAPPAF)*Xi*Rlf(+1)*(lf-(1-CHI)*lf(-1)/pii)/zf ) / THETA1 )^(1/THETA2);

[name='Emissions']
e = (1-eta)*zf;

[name='Compliance cost per unit']
xi = TAXE*(1-eta) + THETA1/(1+THETA2)*eta^(1+THETA2);

[name='Law of motion fossil capital']
kf = (1-DELTAK)*kf(-1) + iif;

[name='Effective fossil cap requirement']
KAPPAFSTAR = (1-eta)*KAPPAFPEN + eta*KAPPAF;

%__________________________________________________________________________
%                       BANKS 

[name='Break-even condition clean loans']
qlc = ( (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Gmu(+1)) + (1-KAPPAC)*Xi ) * Rlc(+1);

[name='Derivative of clean loan price']
Dqlc = ( BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*(1-Gmu(+1)) + (1-KAPPAC)*Xi ) * ( -CHI*(Gc(+1)/mbarc(+1)^2 + VARPHI*DFc(+1))/pii(+1) + (1-CHI)*Dqlc(+1)*mm1c);

[name='Break-even condition fossil loans']
qlf = ( (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Gmu(+1)) + (1-KAPPAFSTAR)*Xi ) * Rlf(+1);

[name='Derivative of fossil loan price']
Dqlf = ( BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*(1-Gmu(+1)) + (1-KAPPAFSTAR)*Xi ) * ( -CHI*(Gf(+1)/mbarf(+1)^2 + VARPHI*DFf(+1))/pii(+1) + (1-CHI)*Dqlf(+1)*mm1f);

[name='Break-even condition non-energy loans']
qln = ( (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Gmu(+1)) + (1-KAPPAN)*Xi ) * Rln(+1);

[name='Derivative of non-energy loan price']
Dqln = ( BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*(1-Gmu(+1)) + (1-KAPPAN)*Xi ) * ( -CHI*(Gn(+1)/mbarn(+1)^2 + VARPHI*DFn(+1))/pii + (1-CHI)*Dqln(+1)*mm1n);

[name='Bank equity constraint']
(1+rdep)/pii(+1)*d = (1-KAPPAC)*Rlc(+1)*lc + (1-KAPPAFSTAR)*Rlf(+1)*lf + (1-KAPPAN)*Rln(+1)*lnon;

[name='Deposit financing wedge']
Xi = pii(+1)/(1+rdep) - (BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C))*(1-Fmu(+1));

[name='Bank failure threshold']
mubar = ((1+rdep(-1))*d(-1))/(pii*(Rc*lc(-1) + Rf*lf(-1) + Rn*lnon(-1)));

%__________________________________________________________________________
%                       BONDS 

[name='Break-even condition fossil bonds']
qbf = BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)*Rbf(+1);

[name='Derivative of clean bond price']
Dqbf = BETA*c(+1)^(-GAMMA_C)/c^(-GAMMA_C)* ( -CHI*DFf(+1)/pii(+1) + (1-CHI)*Dqbf(+1)*mm1f );

%__________________________________________________________________________
%                        MONETARY POLICY

[name='Monetary Policy Rule']
rfree =  1/BETA-1 + PHI_PI*(pii-1) + SIGMA_R*eps_R;

%__________________________________________________________________________
%                       MARKET CLEARING 

[name='Goods market']
y = c + iic*(1+0.5*PSII*(iic/iic(-1)-1)^2) + iif*(1+0.5*PSII*(iif/iif(-1)-1)^2) + iin*(1+0.5*PSII*(iin/iin(-1)-1)^2)
    + THETA1/(1+THETA2)*eta^(1+THETA2)*zf + ZETA*Fmu*d + 0.5*PSIP*(pii-1)^2*y + CHI*VARPHI*(Fc*lc(-1)+Ff*lf(-1)+Fn*lnon(-1))
    + VARPHITILDE*lf(-1) + 0.5*PSIB*(bf-lf)^2;

%__________________________________________________________________________
%                       DEFAULT 

Fc  = normcdf((log(mbarc)-MEANM)/SDEVM);
Ff  = normcdf((log(mbarf)-MEANF)/SDEVF);
Fn  = normcdf((log(mbarn)-MEANM)/SDEVM);
Fmu = normcdf((log(mubar)-MEANMU)/SDEVMU);
Gc  = normcdf((log(mbarc)-MEANM-SDEVM^2)/SDEVM);
Gf  = normcdf((log(mbarf)-MEANF-SDEVF^2)/SDEVF);
Gn  = normcdf((log(mbarn)-MEANM-SDEVM^2)/SDEVM);
Gmu = normcdf((log(mubar)-MEANMU-SDEVMU^2)/SDEVMU);
DFc = (normpdf((log(mbarc)-MEANM)/SDEVM))/(SDEVM*mbarc);
DFf = (normpdf((log(mbarf)-MEANF)/SDEVF))/(SDEVF*mbarf);
DFn = (normpdf((log(mbarn)-MEANM)/SDEVM))/(SDEVM*mbarn);

%__________________________________________________________________________
%                       SHOCKS

[name='TFP']
log(A) = RHO_A*log(A(-1)) + SIGMA_A*eps_A ;

%__________________________________________________________________________
%                       POLICY

[name='Clean Capital Requirement']
KAPPAC = KAPPACss;

[name='Fpssil Capital Requirement']
KAPPAF = KAPPAFss;

[name='Non-energy Capital Requirement']
KAPPAN = KAPPANss;

%__________________________________________________________________________
%                       DEFINITIONS

bshare = bf/(lf+bf);
kagg = kc + kf + kn;
lagg = lc + lf + lnon;
Fagg = (lc(-1)*Fc + lf(-1)*Ff + lnon(-1)*Fn)/lagg(-1);

recovc = Gc/(Fc*mbarc)-VARPHI;
recovf = Gf/(Ff*mbarf)-VARPHI;
recovn = Gn/(Fn*mbarn)-VARPHI;
recov = (lc(-1)*recovc + lf(-1)*recovf + lnon(-1)*recovn)/lagg(-1);

levc = lc/kc;
levf = lf/kf;
levn = lnon/kn;
lev = (lc(-1)*levc + lf(-1)*levf + lnon(-1)*levn)/lagg(-1);

yieldc      = 10000*(1+CHI/qlc-CHI)-10000;
yieldf      = 10000*(1+CHI/qlf-CHI)-10000;
yieldn      = 10000*(1+CHI/qln-CHI)-10000;
yieldrf     = 10000*(1+rfree)-10000;
yielddep    = 10000*(1+rdep)-10000;

dshare = 100*d/y;
fossilshare = 100*(1-eta)*zf/(zf+zc);
energyshare = 100*(pc*zc + pf*zf)/(mc*y);

end;

steady;
%check;

%------------------------------------------------------------------------
% Declare shocks
%------------------------------------------------------------------------

shocks;
var eps_A; stderr 1;
var eps_R; stderr 1;
end;

%------------------------------------------------------------------------
% Simulation
%------------------------------------------------------------------------
stoch_simul(order=@{perorder},irf=@{nirf},periods=@{nperiods},nocorr,nograph,noprint);