%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
% computes steady state for baseline with constant policy

function [out,par,check] = fcomputeSS_base(par)

% financial markets
out.KAPPAC          = par.KAPPACss;
out.KAPPAF          = par.KAPPAFss;
out.KAPPAN          = par.KAPPANss;

% real side
out.rfree           = 1/par.BETA-1;
out.TAXE            = par.TAXE;
out.A               = 1;
out.Delta           = 1;
out.eta             = (out.TAXE/par.THETA1)^(1/par.THETA2);
out.xi              = out.TAXE*(1-out.eta) + par.THETA1/(1+par.THETA2)*out.eta^(1+par.THETA2);

out.psic            = 1;
out.psif            = 1;
out.psin            = 1;

out.mc              = (par.PHI-1)/par.PHI;
out.pii             = 1;

% guess for mm1c, mm1f, mm1n, mbarc, mbarf, mbarn, mubar, rdep, lf
if out.KAPPAF > 0.5
finguess = [0.8,0.46,0.8,0.65,0.65,0.6,0.75,0,0.05];
else
finguess = [0.8,0.8,0.8,0.65,0.65,0.65,0.92,0,0.08];
end

options = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-16,'FunctionTolerance',1e-16);
finstar = fsolve(@(x) (fresidFIN(x,out,par)),finguess,options);

[valfun,out] = fresidFIN(finstar,out,par);

if abs(max(valfun)) > 1e-8
    error('No Fixed Point Found')
end

% Definitions
out.V           = (out.c^(1-par.GAMMA_C)/(1-par.GAMMA_C) - par.OMEGA_N * out.n^(1+par.GAMMA_N)/(1+par.GAMMA_N) + par.OMEGA_D*out.d^(1-par.GAMMA_D)/(1-par.GAMMA_D))/(1-par.BETA);

out.kagg        = out.kc + out.kf + out.kn;
out.lagg        = out.lc + out.lf + out.lnon;
out.Fagg        = (out.lc*out.Fc + out.lf*out.Ff + out.lnon*out.Fn)/out.lagg;

out.recovc      = out.Gc/(out.Fc*out.mbarc)-par.VARPHI;
out.recovf      = out.Gf/(out.Ff*out.mbarf)-par.VARPHI;
out.recovn      = out.Gn/(out.Fn*out.mbarn)-par.VARPHI;
out.recov       = (out.lc*out.recovc + out.lf*out.recovf + out.lnon*out.recovn)/out.lagg;

out.levc        = out.lc/out.kc;
out.levf        = (out.bf+out.lf)/out.kf;
out.levn        = out.lnon/out.kn;
out.lev         = (out.lc*out.levc + out.lf*out.levf + out.lnon*out.levn)/out.lagg;

out.bshare      = out.bf/(out.lf+out.bf);
out.dshare      = 100*out.d/out.y;
out.energyshare = 100*(out.pc*out.zc + out.pf*out.zf)/(out.mc*out.y);
out.fossilshare = 100*(1-out.eta)*out.zf/(out.zc+out.zf);
out.etacost     = par.THETA1/(1+par.THETA2)*out.eta^(1+par.THETA2)*out.zf;

out.yieldrf     = 10000*out.rfree;
out.yieldbf     = 10000*(1+par.CHI/out.qbf-par.CHI)-10000;
out.yieldlc     = 10000*(1+par.CHI/out.qlc-par.CHI)-10000;
out.yieldlf     = 10000*(1+par.CHI/out.qlf-par.CHI)-10000;
out.yieldln     = 10000*(1+par.CHI/out.qln-par.CHI)-10000;
out.yielddep    = 10000*out.rdep;
out.markdown    = (1+out.rdep)/(1+out.rfree);

out.logc          = log(out.c);
out.logd          = log(out.d);
out.loge          = log(out.e);
out.loginv        = log(out.iic + out.iif + out.iin);
out.logloan       = log(out.lc + out.lf + out.lnon);
out.logic         = log(out.iic);
out.logif         = log(out.iif);
out.logy          = log(out.y);

%% Flag if everything went through
check = 0;

end