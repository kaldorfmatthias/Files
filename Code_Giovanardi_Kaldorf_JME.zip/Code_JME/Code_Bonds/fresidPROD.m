%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  Residuals of goods market clearing condition, given financial markets
%  Extension with bonds

function [resid,out] = fresidPROD(prodguess,out,par)

out.kc      = prodguess(1);
out.kf      = prodguess(2);
out.kn      = prodguess(3);
out.c       = prodguess(4);
out.n       = prodguess(5);
out.bf      = prodguess(6);

% output and investment
out.zc      = prodguess(1);
out.zf      = prodguess(2);
out.zn      = prodguess(3);
out.iic     = par.DELTAK*out.kc;
out.iif     = par.DELTAK*out.kf;
out.iin     = par.DELTAK*out.kn;

% intermediate goods and environmental block
out.e       = (1-out.eta)*out.zf;
out.etacost = par.THETA1/(1+par.THETA2)*out.eta^(1+par.THETA2)*out.zf;
out.ze      = (par.NU * out.zc^((par.EPS-1)/par.EPS) + (1-par.NU) * out.zf^((par.EPS-1)/par.EPS))^(par.EPS/(par.EPS-1));
out.ztilde  = (par.NUTILDE * out.ze^((par.EPSTILDE-1)/par.EPSTILDE) + (1-par.NUTILDE) * out.zn^((par.EPSTILDE-1)/par.EPSTILDE))^(par.EPSTILDE/(par.EPSTILDE-1));

% Implied intermediate good prices from firm FOC for capital and risk
out.pc = (1-par.BETAE*(1-par.DELTAK)) / (par.BETAE*(1-out.Gc) - out.Dqlc*out.mbarc^2*(1+par.BETAE*out.mm1c));             
out.pf = (1 - par.BETAF*(1-par.DELTAK) + (1+par.BETAF*out.mm1f)*(out.Dqbf*out.bf+out.Dqlf*out.lf)*par.CHI*out.mbarf/out.kf) / (par.BETAF*(1-out.Gf)) + out.xi; 
out.pn = (1-par.BETAE*(1-par.DELTAK)) / (par.BETAE*(1-out.Gn) - out.Dqln*out.mbarn^2*(1+par.BETAE*out.mm1n));             

% loan demand from default threshold for clean and non-energy, fossil is a guess
out.lc      = out.mbarc*out.pc*out.kc/par.CHI;
out.lnon    = out.mbarn*out.pn*out.kn/par.CHI;

% bond demand from default thresholds
mbarf1      = par.CHI*(out.bf+out.lf)/((out.pf-out.xi)*out.kf);

% Lagrange multipliers from firm FOC for risk
out.lambdac = -(1+par.BETAE*out.mm1c)*par.CHI*out.lc*out.Dqlc;
out.lambdaf = -(1+par.BETAF*out.mm1f)*par.CHI*(out.bf*out.Dqbf+out.lf*out.Dqlf);
out.lambdan = -(1+par.BETAE*out.mm1n)*par.CHI*out.lnon*out.Dqln;

% Implied bond and loan prices from firm FOC for debt
out.qbf     = ( par.CHI*par.BETAF*(1-out.Ff) + out.lambdaf*out.mbarf/(out.bf+out.lf) + par.PSIB*(out.bf-out.lf) ) / (1-par.BETAF*(1-par.CHI));
out.qlc     = ( par.CHI*par.BETAE*(1-out.Fc) + out.lambdac*out.mbarc/out.lc ) / (1-par.BETAE*(1-par.CHI));
out.qlf     = ( par.CHI*par.BETAF*(1-out.Ff) + out.lambdaf*out.mbarf/(out.bf+out.lf) - par.PSIB*(out.bf-out.lf) ) / (1-par.BETAF*(1-par.CHI));
out.qln     = ( par.CHI*par.BETAE*(1-out.Fn) + out.lambdan*out.mbarn/out.lnon ) / (1-par.BETAE*(1-par.CHI));

% loan payoff
out.Rlc = par.CHI*(out.Gc/out.mbarc + 1-out.Fc - out.Fc*par.VARPHI) + (1-par.CHI)*out.qlc;
out.Rlf = par.CHI*(out.Gf/out.mbarf + 1-out.Ff - out.Ff*par.VARPHI) + (1-par.CHI)*out.qlf - par.VARPHITILDE;
out.Rln = par.CHI*(out.Gn/out.mbarn + 1-out.Fn - out.Fn*par.VARPHI) + (1-par.CHI)*out.qln;

% default cost
out.Fcost   = par.CHI*par.VARPHI*(out.Fc*out.lc+out.Ff*out.lf+out.Fn*out.lnon) + par.VARPHITILDE*out.lf;

% deposit demand
out.d       = (par.OMEGA_D*out.c^par.GAMMA_C/(1-par.BETA*(1+out.rdep)))^(1/par.GAMMA_D);

% bailout cost
out.FMUcost = par.ZETA*out.Fmu*out.d;

% resource constraint
out.y       = out.c + out.iic + out.iif + out.iin + out.Fcost + out.etacost + out.FMUcost + 0.5*par.PSIB*(out.bf-out.lf)^2;

% energy, non-energy and labor demand
zcd         = out.ze /( (out.pc/(out.mc*par.ALPHA*par.NU*par.NUTILDE) * (out.ztilde/out.y) * (out.ze/out.ztilde)^(1/par.EPSTILDE) )^par.EPS ); 
zfd         = out.ze /( (out.pf/(out.mc*par.ALPHA*(1-par.NU)*par.NUTILDE) * (out.ztilde/out.y) * (out.ze/out.ztilde)^(1/par.EPSTILDE) )^par.EPS ); 
znd         = out.ztilde /( (out.pn/(out.mc*par.ALPHA*(1-par.NUTILDE)) * (out.ztilde/out.y))^par.EPSTILDE );
out.w       = out.mc*(1-par.ALPHA)*out.y/out.n;
out.wstar   = out.w;

% supply of final good
ys          = out.A * exp(-par.PSID*out.e) * out.ztilde^par.ALPHA * out.n^(1-par.ALPHA);

% labor supply
out.ns      = out.n;
out.X1      = out.w^par.PHITILDE*out.n*out.c^(-par.GAMMA_C)/(1-par.BETA*par.PSIN);
out.X2      = out.w^(par.PHITILDE*(1+par.GAMMA_N))*par.OMEGA_N*out.n^(1+par.GAMMA_N)/(1-par.BETA*par.PSIN);

% Residuals
resid(1)    = out.zc - zcd;  % excess supply clean energy
resid(2)    = out.zf - zfd;  % excess supply fossil energy
resid(3)    = out.zn - znd;  % excess supply non-energy
resid(4)    = out.y - ys;    % excess demand final good
resid(5)    = out.X1 * out.w^(1+par.PHITILDE*par.GAMMA_N) - out.X2; % excess demand labor
resid(6)    = out.mbarf - mbarf1; % fossil default threshold

end
