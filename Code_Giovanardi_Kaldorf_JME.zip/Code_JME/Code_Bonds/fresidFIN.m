%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  Residuals of financial market clearing condition, given goods markets
%  Extension with bonds

function [resid,out] = fresidFIN(finguess,out,par)

out.mm1c    = finguess(1);
out.mm1f    = finguess(2);
out.mm1n    = finguess(3);
out.mbarc   = finguess(4);
out.mbarf   = finguess(5);
out.mbarn   = finguess(6);
out.mubar   = finguess(7);
out.rdep    = finguess(8);
out.lf      = finguess(9);

if ~isreal(out.mbarc) || ~isreal(out.mbarf) || ~isreal(out.mbarn)
    error('Calibration results in negative default probability, sigM too small')
end

if out.mbarc<0 || out.mbarf<0 || out.mbarn<0
    error('Calibration results in negative mbar')
end

% distribution
out.Fc      = normcdf((log(out.mbarc)-par.MEANM)/par.SDEVM);
out.Ff      = normcdf((log(out.mbarf)-par.MEANF)/par.SDEVF);
out.Fn      = normcdf((log(out.mbarn)-par.MEANM)/par.SDEVM);
out.Fmu     = normcdf((log(out.mubar)-par.MEANMU)/par.SDEVMU);
out.Gc      = normcdf((log(out.mbarc)-par.MEANM-par.SDEVM^2)/par.SDEVM);
out.Gf      = normcdf((log(out.mbarf)-par.MEANF-par.SDEVF^2)/par.SDEVF);
out.Gn      = normcdf((log(out.mbarn)-par.MEANM-par.SDEVM^2)/par.SDEVM);
out.Gmu     = normcdf((log(out.mubar)-par.MEANMU-par.SDEVMU^2)/par.SDEVMU);
out.DFc     = 1 / (out.mbarc * par.SDEVM * sqrt(2*pi)) * exp(-1 * (log(out.mbarc) - par.MEANM)^2 / (2 * par.SDEVM^2) );
out.DFf     = 1 / (out.mbarf * par.SDEVF * sqrt(2*pi)) * exp(-1 * (log(out.mbarf) - par.MEANF)^2 / (2 * par.SDEVF^2) ); 
out.DFn     = 1 / (out.mbarn * par.SDEVM * sqrt(2*pi)) * exp(-1 * (log(out.mbarn) - par.MEANM)^2 / (2 * par.SDEVM^2) ); 

% deposit financing wedge
out.Xi = (1/(1+out.rdep) - par.BETA*(1-out.Fmu));

% derivative of loan prices
out.Dqlc = - ((1-out.KAPPAC)*out.Xi + par.BETA*(1-out.Gmu)) * par.CHI * (out.Gc/out.mbarc^2 + par.VARPHI*out.DFc) / ( 1 - ((1-out.KAPPAC)*out.Xi + par.BETA*(1-out.Gmu))*(1-par.CHI)*out.mm1c );
out.Dqlf = - ((1-out.KAPPAF)*out.Xi + par.BETA*(1-out.Gmu)) * par.CHI * (out.Gf/out.mbarf^2 + par.VARPHI*out.DFf) / ( 1 - ((1-out.KAPPAF)*out.Xi + par.BETA*(1-out.Gmu))*(1-par.CHI)*out.mm1f );
out.Dqln = - ((1-out.KAPPAN)*out.Xi + par.BETA*(1-out.Gmu)) * par.CHI * (out.Gn/out.mbarn^2 + par.VARPHI*out.DFn) / ( 1 - ((1-out.KAPPAN)*out.Xi + par.BETA*(1-out.Gmu))*(1-par.CHI)*out.mm1n );

% derivative of bond prices
out.Dqbf = - par.CHI*out.DFf / ((1+out.rfree) - (1-par.CHI)*out.mm1f);

% initial guesses kc, kf, kn, c, n, bf
if par.TAXE > 0.049
prodguess = [0.16,0.38,1.24,0.45,0.45,0.04];
else
prodguess = [0.11,0.44,1.25,0.45,0.45,0.04];
end

% solve
options     = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-16,'FunctionTolerance',1e-16);
prodstar    = fsolve(@(x) (fresidPROD(x,out,par)),prodguess,options);

[valfun,out] = fresidPROD(prodstar,out,par);

if max(abs(valfun)) > 1e-8
    error('Excess demand on some market not zero')
end

% deposits from HH foc 
d1          = ((1-out.KAPPAC)*out.Rlc*out.lc + (1-out.KAPPAF)*out.Rlf*out.lf + (1-out.KAPPAN)*out.Rln*out.lnon)/(1+out.rdep);

% bank failure threshold
mubar1      = (1+out.rdep)*out.d/(out.Rlc*out.lc + out.Rlf*out.lf + out.Rln*out.lnon);

% loan and bond payoffs
out.Rlc = par.CHI*(out.Gc/out.mbarc + 1-out.Fc - out.Fc*par.VARPHI) + (1-par.CHI)*out.qlc;
out.Rlf = par.CHI*(out.Gf/out.mbarf + 1-out.Ff - out.Ff*par.VARPHI) + (1-par.CHI)*out.qlf - par.VARPHITILDE;
out.Rln = par.CHI*(out.Gn/out.mbarn + 1-out.Fn - out.Fn*par.VARPHI) + (1-par.CHI)*out.qln;
out.Rbf = par.CHI*(1-out.Ff) + (1-par.CHI)*out.qbf;

% loan and bond price consistent with bank FOC
qlc1 = out.Rlc * ( (1-out.KAPPAC)*out.Xi + par.BETA*(1-out.Gmu) );
qlf1 = out.Rlf * ( (1-out.KAPPAF)*out.Xi + par.BETA*(1-out.Gmu) );
qln1 = out.Rln * ( (1-out.KAPPAN)*out.Xi + par.BETA*(1-out.Gmu) );
qbf1 = out.Rbf / (1+out.rfree);

% slope of policy function
mm11c = ( (out.qlc+out.mbarc*out.Dqlc)/par.BETAE - par.CHI*(1-out.Fc)-(1-par.CHI)*out.qlc ) / ((1-par.CHI)*out.Dqlc*out.mbarc);
mm11f = ( (out.qlf+out.mbarf*out.Dqlf)/par.BETAF - par.CHI*(1-out.Ff)-(1-par.CHI)*out.qlf ) / ((1-par.CHI)*out.Dqlf*out.mbarf);
mm11n = ( (out.qln+out.mbarn*out.Dqln)/par.BETAE - par.CHI*(1-out.Fn)-(1-par.CHI)*out.qln ) / ((1-par.CHI)*out.Dqln*out.mbarn);

% Residuals
resid(1)    = qlc1 - out.qlc;
resid(2)    = qlf1 - out.qlf;
resid(3)    = qln1 - out.qln;
resid(4)    = d1 - out.d;
resid(5)    = mubar1 - out.mubar;
resid(6)    = mm11c - out.mm1c;
resid(7)    = mm11f - out.mm1f;
resid(8)    = mm11n - out.mm1n;
resid(9)    = qbf1 - out.qbf;

end
