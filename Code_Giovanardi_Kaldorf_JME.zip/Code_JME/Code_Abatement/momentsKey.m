function out = momentsKey(results,results_base)

M_  = results.M_;
means = results.mean;

% delta emissions
vecMoments(1,1) = 100 * means(ismember(M_.endo_names,'e')) / results_base.mean(ismember(results_base.M_.endo_names,'e'))-100;
% bank default
vecMoments(2,1) = 100*means(ismember(M_.endo_names,'Fmu')); 
% liquidity premium
vecMoments(3,1) = means(ismember(M_.endo_names,'yielddep')) - means(ismember(M_.endo_names,'yieldrf'));
% welfare gain
vecMoments(4,1) = 100*exp(0.01*( means(ismember(M_.endo_names,'V')) -  results_base.mean(ismember(M_.endo_names,'V')) ))-100;

vecMoments = round(vecMoments,2);

varNAMES  = ["Model"];
rowNAMES  = ["Delta Emissions","Bank Failure","Mean Dep Spread","Welfare Gain"];
out = table(vecMoments,'VariableNames',varNAMES,'RowNames',rowNAMES);  

end