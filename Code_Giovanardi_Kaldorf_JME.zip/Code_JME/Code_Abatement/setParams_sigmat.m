function par = setParams_sigmat()

par = setParams_structural();

% bank regulation
par.KAPPACss    = 0.08;    % clean
par.KAPPAFss    = 0.08;    % fossil
par.KAPPANss    = 0.08;    % non-energy

% climate policy
par.TAXEss      = 0.002;    % emission tax 
par.TAXK        = 0.0;    % fossil capital tax
par.RHO_T    	= 0.8;    % persistence tax
par.SIGMA_T  	= 0.00;   % standard deviation tax shock

end