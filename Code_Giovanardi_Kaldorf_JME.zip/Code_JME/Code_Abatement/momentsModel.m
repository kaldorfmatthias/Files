function out = momentsModel(results)

M_  = results.M_;
means = results.mean;

% energy share
vecMoments(1,1) = means(ismember(M_.endo_names,'energyshare'));
% fossil energy share
vecMoments(2,1) = means(ismember(M_.endo_names,'fossilshare'));
% liquidity premium
vecMoments(3,1) = means(ismember(M_.endo_names,'yielddep')) - means(ismember(M_.endo_names,'yieldrf'));
% clean leverage
vecMoments(4,1) = 100*means(ismember(M_.endo_names,'levc'));
% fossil leverage
vecMoments(5,1) = 100*means(ismember(M_.endo_names,'levf'));
% clean default
vecMoments(6,1) = 100*means(ismember(M_.endo_names,'Fc'));
% fossil default
vecMoments(7,1) = 100*means(ismember(M_.endo_names,'Ff'));
% bank default
vecMoments(8,1) = 100*means(ismember(M_.endo_names,'Fmu'));
% recovery rate
vecMoments(9,1) = 100*means(ismember(M_.endo_names,'recov'));
% abatement share
vecMoments(10,1) = 100*means(ismember(M_.endo_names,'eta'));

vecMoments = round(vecMoments,2);

% DATA
vecMomentsData = [10; 80; -40; 26; 26; 1.7; 1.7; 0.6; 82; 0];

varNAMES  = ["Model","Data"];
rowNAMES  = ["Energy Share","Fossil Share","Mean Dep Spread","Clean Leverage","Fossil Leverage",...
            "Clean Default","Fossil Default","Bank Failure","Recovery","Abatement Share"];
out = table(vecMoments,vecMomentsData,'VariableNames',varNAMES,'RowNames',rowNAMES);  

end