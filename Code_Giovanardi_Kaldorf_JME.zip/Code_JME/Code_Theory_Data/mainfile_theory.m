%% Figure 3: xi and wedge for fossil cap requirement
par = setParams_structural();

% endogenous variables in steady state without policy intervention
Xi = 0.00815;
DFf = 0.327;
mbarf = 0.64;
levf = 0.29;
pf = 0.0906;
Rf = 0.972576;

vecKAPPAF = linspace(0.08,1,93);
vecKAPPAPEN = linspace(0.08,1,93);
vecTax = linspace(0.00,0.05,51);

vecA = (vecTax./par.THETA1).^(1/par.THETA2);
vecA_SLC = ((vecKAPPAPEN-0.08)*Xi*Rf*par.CHI*levf/par.THETA1).^(1/par.THETA2);

vecWedge = (((1-0.08)*Xi+par.BETA)*DFf*mbarf^2 + 1) * (pf - vecTax.*(1-vecA) - par.THETA1/(1+par.THETA2)*vecA.^(1+par.THETA2)) ;
vecWedgef = (((1-vecKAPPAF)*Xi+par.BETA)*DFf*mbarf^2 + 1) * pf;

% plot options
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 12;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 9;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultLineMarkerSize',8) 

fig = figure;
subplot(2,2,1)
hold on; box on; grid on; grid minor
plot(100*vecKAPPAF,100*vecWedgef/vecWedgef(1)-100,'LineWidth',2,'color','red','LineStyle','--');
xlim([8 100])
title('Wedge in Fossil Inv. Payoff')
ylabel('%')
xlabel('Fossil Capital Requirement (%)')

subplot(2,2,2)
hold on; box on; grid on; grid minor
plot(par.s1/par.s2*vecTax,100*vecWedge/vecWedge(1)-100,'LineWidth',2,'color','blue');
title('Wedge in Fossil Inv. Payoff')
ylabel('%')
xlabel('Emission Tax ($/tCO2)')
xlim([0 100])

subplot(2,2,3)
hold on; box on; grid on; grid minor
plot(100*vecKAPPAF,100*vecA_SLC,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
xlim([8 100])
title('Abatement Share')
ylabel('%')
xlabel('Penalty Capital Requirement (%)')

subplot(2,2,4)
hold on; box on; grid on; grid minor
plot(par.s1/par.s2*vecTax,100*vecA,'LineWidth',2,'color','blue');
title('Abatement Share')
ylabel('%')
xlabel('Emission Tax ($/tCO2)')
xlim([0 100])

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','simple_model');
