%% prepare macro data
data_macro = xlsread('Data_Giovanardi_Kaldorf.xlsx','Macro');

year_y = data_macro(:,1);
d = data_macro(:,3);
y = data_macro(:,5);
infl = data_macro(:,7);
c = data_macro(:,8);
inv = data_macro(:,10);
ffr = data_macro(:,11);
dy = d./y;
dc = d./c;

[~,infl_cycle] = one_sided_hp_filter(infl,6.25);
[~,dc_cycle] = one_sided_hp_filter(dc,6.25);
[~,dy_cycle] = one_sided_hp_filter(dy,6.25);
[~,d_cycle] = one_sided_hp_filter(log(d),6.25);
[~,y_cycle] = one_sided_hp_filter(log(y),6.25);
[~,i_cycle] = one_sided_hp_filter(log(y-c),6.25);
[~,c_cycle] = one_sided_hp_filter(log(c),6.25);
[~,ffr_cycle] = one_sided_hp_filter(ffr,6.25);

%% prepare leverage data
data_leverage = xlsread('Data_Giovanardi_Kaldorf.xlsx','Leverage');
year_leverage = data_leverage(:,1);
leverage = data_leverage(:,2);
debt = data_leverage(:,5);
[~,l_cycle] = one_sided_hp_filter(log(debt),6.25);
[~,lev_cycle] = one_sided_hp_filter(leverage,6.25);

%% data corporate default
data_default = xlsread('Data_Giovanardi_Kaldorf.xlsx','Default');
year_default = data_default(65:end,1);
corp_default = data_default(65:end,11);
[~,default_cycle] = one_sided_hp_filter(corp_default,6.25);

%% data bank failure
data_bank = xlsread('Data_Giovanardi_Kaldorf.xlsx','FDIC');
year_failure = data_bank(1:30,1);
bank_failure = data_bank(1:30,5);
[~,failure_cycle] = one_sided_hp_filter(bank_failure,6.25);

%% plot
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 12;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 9;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',0.5)
set(0,'DefaultLineMarkerSize',12) 

fig = figure;
hold on; grid on; grid minor;
plot(year_y,100*y_cycle,Color='black',LineWidth=2)
plot(year_failure,100*failure_cycle,LineWidth=2,Color="blue")
plot(year_leverage,100*lev_cycle,LineStyle=':',LineWidth=2)
plot(year_default,default_cycle,LineStyle='--',LineWidth=2)
yline(0)
ylabel('Percent')
xlim([1983 2013])
box;
lgd = legend('GDP','Bank Failure','Leverage','Corp Default','Orientation','horizontal');
lgd.Position(2) = 0.0125;
lgd.Position(1) = 0.15;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;
fig.PaperSize(1)        = opts.width;
fig.PaperSize(2)        = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','data');

%% compute macro moments
clc
% excess vols
display(['Excess vol investment: ' num2str(std(i_cycle)/std(y_cycle))]);
display(['Excess vol deposits: ' num2str(std(dy_cycle)/std(y_cycle))]);
display(['Excess vol interest rate: ' num2str(0.01*std(ffr_cycle)/std(y_cycle))]);
display(['Excess vol inflation: ' num2str(std(0.01*infl_cycle)/std(y_cycle))]);
display(['Excess vol consumption: ' num2str(std(c_cycle)/std(y_cycle))]);
display(['Excess vol leverage: ' num2str(std(lev_cycle)/std(y_cycle))]);
display(['Excess vol corp default: ' num2str(std(0.01*default_cycle)/std(y_cycle))]);
display(['Excess vol bank failure: ' num2str(std(failure_cycle)/std(y_cycle))]);

% correlations with gdp
display(['corr(y,d/y): ' num2str(corr(dy_cycle,y_cycle))]);
display(['corr(y,lev): ' num2str(corr(y_cycle(1:end-1),lev_cycle))]);
display(['corr(y,Fm): ' num2str(corr(y_cycle,default_cycle))]);
display(['corr(y,Fmu): ' num2str(corr(y_cycle,failure_cycle))]);
display(['corr(Fm,Fmu): ' num2str(corr(failure_cycle,default_cycle))]);

% correlations with inflation
display(['corr(r,pi): ' num2str(corr(infl_cycle,ffr_cycle))]);
display(['corr(lev,pi): ' num2str(corr(lev_cycle,infl_cycle(1:end-1)))]);
display(['corr(log(l),pi): ' num2str(corr(l_cycle,infl_cycle(1:end-1)))]);
display(['corr(Fm,pi): ' num2str(corr(default_cycle,infl_cycle))]);
display(['corr(Fmu,pi): ' num2str(corr(failure_cycle,infl_cycle))]);

%% read central bank speeches
%opts = detectImportOptions("Data_Giovanardi_Kaldorf.xlsx",Sheet="Speeches")
data_speeches = readtable("Data_Giovanardi_Kaldorf.xlsx",Sheet='Speeches');
vec_years = year(data_speeches.Date);

%% plot
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 12;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 9;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',0.5)
set(0,'DefaultLineMarkerSize',12) 

fig = figure;
hist = histogram(vec_years);
ylabel('Number of Speeches')

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;
fig.PaperSize(1)        = opts.width;
fig.PaperSize(2)        = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','data_speeches');