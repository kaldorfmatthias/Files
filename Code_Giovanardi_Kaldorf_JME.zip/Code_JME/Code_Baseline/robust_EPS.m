%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  robustness with lower clean-fossil EOS
%  this script generates Table D.2, Panel E

clear all; clc; close all;

eval(['dynare model_base.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])

set_param_value('EPS',5)
set_param_value('NU',0.435) % ensure that fossil share is still 80%
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_); 
results_base.mean = oo_.mean;
results_base.var = oo_.var;
results_base.M_ = M_;

% kappaf = 1
set_param_value('TAXE',0.0)
set_param_value('KAPPAFss',1)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_kappaf1.mean = oo_.mean;
results_kappaf1.M_ = M_;

% 10 USD tax
set_param_value('KAPPAFss',0.08)
set_param_value('TAXE',0.0025)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_low.mean = oo_.mean;
results_low.M_ = M_;

% net zero tax
set_param_value('TAXE',0.0499)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_paris.mean = oo_.mean;
results_paris.M_ = M_;

% slc
eval(['dynare model_slc.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
set_param_value('EPS',5)
set_param_value('NU',0.435) % ensure that fossil share is still 80%
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_slc.mean = oo_.mean;
results_slc.M_ = M_;
momentsModel(results_slc)

% tax shocks
eval(['dynare model_sigmat.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
set_param_value('EPS',5)
set_param_value('NU',0.435) % ensure that fossil share is still 80%
set_param_value('TAXEss',0.0025)
set_param_value('SIGMA_T',0.0025)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_shocks.mean = oo_.mean;
results_shocks.M_ = M_;

%% Table D.2, Panel D
momentsModel(results_base)

momentsKey(results_kappaf1,results_base)
momentsKey(results_slc,results_base)
momentsKey(results_paris,results_base)
momentsKey(results_low,results_base)
momentsKey(results_shocks,results_base)

%% optimal capital requirements for different tax levels
eval(['dynare model_base.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
set_param_value('EPS',5)
set_param_value('NU',0.435) % ensure that fossil share is still 80%

nkappa          = 41;
polMat.KAPPA    = linspace(0.06,0.1,nkappa);
V_pos    = strmatch('V',M_.endo_names,'exact');

vecWelfare_notax    = nan(nkappa,1);
vecWelfare_tax      = nan(nkappa,1);

for ikappa = 1:nkappa
           
        set_param_value('KAPPACss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPAFss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPANss',polMat.KAPPA(1,ikappa));
        set_param_value('TAXE',0);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.means        = oo_.mean;
        vecWelfare_notax(ikappa,1)          = results.means(V_pos);

        set_param_value('TAXE',0.0499);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.means        = oo_.mean;
        vecWelfare_tax(ikappa,1)          = results.means(V_pos);

        clc
        fprintf('capital requirement : %1.0f \n',ikappa);
        
end

ind_max_notax = find(vecWelfare_notax == max(vecWelfare_notax));
ind_max_tax = find(vecWelfare_tax == max(vecWelfare_tax));
display(['Optimal KAPPA without tax = ' num2str(polMat.KAPPA(ind_max_notax))])
display(['Optimal KAPPA under full abatement = ' num2str(polMat.KAPPA(ind_max_tax))])

%% optimal symmetric capital requirements with policy uncertainty
eval(['dynare model_sigmat.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
set_param_value('EPS',5)
set_param_value('NU',0.435) % ensure that fossil share is still 80%

nkappa          = 41;
polMat.KAPPA    = linspace(0.07,0.09,nkappa);
V_pos    = strmatch('V',M_.endo_names,'exact');

vecWelfare_lowtax      = nan(nkappa,1);
vecWelfare_taxshock      = nan(nkappa,1);

for ikappa = 1:nkappa
           
        set_param_value('KAPPACss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPAFss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPANss',polMat.KAPPA(1,ikappa));
        set_param_value('TAXEss',0.005);
        set_param_value('SIGMA_T',0);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.means        = oo_.mean;
        vecWelfare_lowtax(ikappa,1)          = results.means(V_pos);

        set_param_value('TAXEss',0.0025);
        set_param_value('SIGMA_T', 0.0025);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.means        = oo_.mean;
        vecWelfare_taxshock(ikappa,1)          = results.means(V_pos);

        clc
        fprintf('capital requirement : %1.0f \n',ikappa);
        
end

ind_max_low = find(vecWelfare_lowtax == max(vecWelfare_lowtax));
ind_max_shock = find(vecWelfare_taxshock == max(vecWelfare_taxshock));
display(['Optimal KAPPA without policy uncertainty = ' num2str(polMat.KAPPA(ind_max_low))])
display(['Optimal KAPPA with policy uncertainty = ' num2str(polMat.KAPPA(ind_max_shock))])
