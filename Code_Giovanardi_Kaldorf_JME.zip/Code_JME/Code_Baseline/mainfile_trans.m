%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  This script generates Figure 4 and Figure C.5

clear all; close all; clc

% transition with constant policy
eval('dynare model_trans_real.mod')
vecY_real = y;
display(['Welfare gain (CE,%) ' num2str(100*(-0.01*V(2))^-1/(-0.01*V(1))^-1-100)]); %2.6491

% add nominal rigidities
eval('dynare model_trans.mod')
veca_base = eta;
vecD_base = d;
vece_base = e;
vece_base(27:end) = 0;
vece_base = 37.5*vece_base/vece_base(1);
vecE_base = cumsum(vece_base);
vecFMu_base = Fmu;
vecFC_base = Fc;
vecFF_base = Ff;
vecFN_base = Fn;
vecKC_base = kc;
vecKF_base = kf;
vecKN_base = kn;
vecLC_base = lc;
vecLF_base = lf;
vecLN_base = lnon;
vecY_base = y;
vecYGAP_base = vecY_base - vecY_real;
vecPii_base = pii;
display(['Welfare gain (CE,%) ' num2str(100*(-0.01*V(2))^-1/(-0.01*V(1))^-1-100)]); %1.325
display(['Temperature increase ' num2str(0.58*(2400+vecE_base(25))/1000)]); %1.634 celsius

% transition with SLC
eval('dynare model_trans_slc_real.mod')
vecY_slc_real = y;
display(['Welfare gain (CE,%) ' num2str(100*(-0.01*V(2))^-1/(-0.01*V(1))^-1-100)]); %2.6516

% add nominal rigidities
eval('dynare model_trans_slc.mod')
veca_slc = eta;
vecD_slc = d;
vece_slc = e;
vece_slc(27:end) = 0;
vece_slc = 37.5*vece_slc/vece_slc(1);
vecE_slc = cumsum(vece_slc);
vecFMu_slc = Fmu;
vecFC_slc = Fc;
vecFF_slc = Ff;
vecFN_slc = Fn;
vecKC_slc = kc;
vecKF_slc = kf;
vecKN_slc = kn;
vecLC_slc = lc;
vecLF_slc = lf;
vecLN_slc = lnon;
vecY_slc = y;
vecYGAP_slc = vecY_slc - vecY_slc_real;
vecPii_slc = pii;
display(['Welfare gain (CE,%) ' num2str(100*(-0.01*V(2))^-1/(-0.01*V(1))^-1-100)]); %1.327
display(['Temperature increase ' num2str(0.58*(2400+vecE_slc(25))/1000)]); %1.636 celsius

save('workspace_transition.mat')

%% plot figure 4 (emissions, deposits, inflation, output gap over model emissions)
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 12;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 7;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultLineMarkerSize',8) 

% GDP 105 trillion in 2022
s1 = 105*1E9/0.590541; 
% emissions 37.5 GtCO2 in 2022
s2 = 37.5*1E6/0.447941;

fig = figure;
subplot(2,3,1)
hold on; box on; grid on;
plot((2025:2226),[TAXstart;TAXpath(1:201)]*s1/s2,'LineWidth',2,'color','blue')
xlim([2025 2035])
title('Emission Tax ($/tCO2)')

subplot(2,3,2)
hold on; box on; grid on;
plot((2025:2226),100*vecYGAP_base(1:202),'LineWidth',2,'color','blue')
plot((2025:2226),100*vecYGAP_slc(1:202),'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Output Gap (%)')

subplot(2,3,3)
hold on; box on; grid on;
plot((2025:2226),100*vecPii_base(1:202)-100,'LineWidth',2,'color','blue')
plot((2025:2226),100*vecPii_slc(1:202)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Inflation (%)')

subplot(2,3,4)
hold on; box on; grid on;
plot((2025:2226),2400+vecE_base(1:202),'LineWidth',2,'color','blue')
plot((2025:2226),2400+vecE_slc(1:202),'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Atmospheric GtCO2')

subplot(2,3,5)
hold on; box on; grid on;
plot((2025:3026),100*vecFMu_base,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecFMu_slc,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Bank Failure Rate (%)')

subplot(2,3,6)
hold on; box on; grid on;
plot((2025:2226),100*vecD_base(1:202)/vecD_base(1)-100,'LineWidth',2,'color','blue')
plot((2025:2226),100*vecD_slc(1:202)./vecD_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('\Delta Deposits (%)')
lgd = legend('Emission Tax Only','Emission Tax and SLC','Orientation','Horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.25;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','transition');

%display(['Additional Emission Reduction in 2050, KAPPAF=100: ' num2str(vece_kappa(25)*E_US/E_model-vece_base(25)*E_US/E_model)]);
%display(['Additional Emission Reduction in 2050, SLC: ' num2str(vece_slc(25)*E_US/E_model-vece_base(25)*E_US/E_model)]);

%% plot Figure C.5
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 14;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 7;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',2)
set(0,'DefaultLineMarkerSize',8) 

fig=figure;
subplot(4,3,1)
hold on; box on; grid on;
plot((2025:2226),[TAXstart;TAXpath(1:201)]*s1/s2,'LineWidth',2,'color','blue')
xlim([2025 2035])
title('Emission Tax ($/tCO2)')

subplot(4,3,2)
hold on; box on; grid on;
plot((2025:3026),100*veca_base,'LineWidth',2,'color','blue')
plot((2025:3026),100*veca_slc,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Abatement Share (%)')

subplot(4,3,3)
hold on; box on; grid on;
plot((2025:2226),vecY_base(1:202)/vecY_base(1),'LineWidth',2,'color','blue')
plot((2025:2226),vecY_slc(1:202)/vecY_slc(1),'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('GDP (%)')

subplot(4,3,4)
hold on; box on; grid on;
plot((2025:3026),100*vecKF_base/vecKF_base(1)-100,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecKF_slc/vecKF_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
yline(0)
xlim([2025 2035])
title('\Delta Fossil Capital (%)')

subplot(4,3,5)
hold on; box on; grid on;
plot((2025:3026),100*vecKC_base/vecKC_base(1)-100,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecKC_slc/vecKC_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
yline(0)
xlim([2025 2035])
title('\Delta Clean Capital (%)')

subplot(4,3,6)
hold on; box on; grid on;
plot((2025:3026),100*vecKN_base/vecKN_base(1)-100,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecKN_slc/vecKN_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
yline(0)
xlim([2025 2035])
title('\Delta Non-Energy Capital (%)')

subplot(4,3,7)
hold on; box on; grid on;
plot((2025:3026),100*vecLF_base/vecLF_base(1)-100,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecLF_slc/vecLF_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
yline(0)
xlim([2025 2035])
title('\Delta Fossil Loans (%)')

subplot(4,3,8)
hold on; box on; grid on;
plot((2025:3026),100*vecLC_base/vecLC_base(1)-100,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecLC_slc/vecLC_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
yline(0)
xlim([2025 2035])
title('\Delta Clean Loans (%)')

subplot(4,3,9)
hold on; box on; grid on;
plot((2025:3026),100*vecLN_base/vecLN_base(1)-100,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecLN_slc/vecLN_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
yline(0)
xlim([2025 2035])
title('\Delta Non-Energy Loans (%)')

subplot(4,3,10)
hold on; box on; grid on;
plot((2025:3026),100*vecFF_base,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecFF_slc,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Fossil Default (p.p.)')

subplot(4,3,11)
hold on; box on; grid on;
plot((2025:3026),100*vecFC_base,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecFC_slc,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Clean Default (p.p.)')

subplot(4,3,12)
hold on; box on; grid on;
plot((2025:3026),100*vecFN_base,'LineWidth',2,'color','blue')
plot((2025:3026),100*vecFN_slc,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':')
xlim([2025 2035])
title('Non-Energy Default (p.p.)')
lgd = legend('Emission Tax Only','Emission Tax and SLC','Orientation','Horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.25;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 7);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','transition_app');
