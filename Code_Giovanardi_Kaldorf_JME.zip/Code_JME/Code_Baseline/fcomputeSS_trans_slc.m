%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2024)
%**************************************************************************
%  solves steady state equations for a given emission tax
%  sustainability linked capital requirement

function [c,y,n,ns,X1,X2,zc,zf,ze,zn,ztilde,kc,kf,kn,iic,iif,iin,...
    lc,lf,lnon,d,e,E,eta,xi,mc,pii,w,psic,psif,psin,pc,pf,pn,rdep,rfree,...
    lambdac,lambdaf,lambdan,mm1c,mm1f,mm1n,mbarc,mbarf,mbarn,mubar,Xi,Rc,Rf,Rn,qc,qf,qn,...
    Dqc,Dqf,Dqn,Fc,Ff,Fn,Fmu,Gc,Gf,Gn,Gmu,DFc,DFf,DFn] = fcomputeSS_trans_slc(TAXE,KAPPAFPEN)

par = setParams_structural();

% policy
par.TAXK    = 0;
par.TAXE    = TAXE;
out.KAPPAFPEN = KAPPAFPEN;

out.KAPPAC  = 0.08;
out.KAPPAF  = 0.08;
out.KAPPAN  = 0.08;

out.A       = 1;    
out.eta     = (par.TAXE/par.THETA1)^(1/par.THETA2);
out.rfree   = 1/par.BETA-1;

out.mc      = (par.PHI-1)/par.PHI;
out.psic    = 1;
out.psif    = 1;
out.psin    = 1;
out.pii     = 1;

% guess for mm1c, mm1f, mm1n, mbarc, mbarf, mbarn, mubar, rdep
if par.TAXE > 0.049
    finguess = [0.8,0.8,0.8,0.65,0.65,0.65,0.92,0];
else
    finguess = [0.8,0.8,0.8,0.65,0.6,0.65,0.72,0];
end

options = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-16,'FunctionTolerance',1e-16);
finstar = fsolve(@(x) (fresidFIN_slc(x,out,par)),finguess,options);

[valfun,out] = fresidFIN_slc(finstar,out,par);

if abs(max(valfun)) > 1e-12
    error('No Fixed Point Found')
end

%% write output
c	    =   out.c	;
y	    =	out.y	;
n	    =	out.n	;
ns	    =	out.ns	;
X1	    =	out.X1	;
X2	    =	out.X2	;
zc	    =	out.zc	;
zf	    =	out.zf	;
ze	    =	out.ze	;
zn	    =	out.zn	;
ztilde	=	out.ztilde	;
kc	    =	out.kc	;
kf	    =	out.kf	;
kn	    =	out.kn	;
iic	    =	out.iic	;
iif	    =	out.iif	;
iin	    =	out.iin	;
lc	    =	out.lc	;
lf	    =	out.lf	;
lnon	=	out.lnon	;
d	    =	out.d	;
e	    =	out.e	;
E       =   out.E   ;
eta	    =	out.eta	;
xi	    =	out.xi	;
mc      =   out.mc  ;
pii     =   out.pii ;
w	    =	out.w	;
psic	=	out.psic	;
psif	=	out.psif	;
psin	=	out.psin	;
pc	    =	out.pc	;
pf	    =	out.pf	;
pn  	=	out.pn	;
rdep	=	out.rdep	;
rfree   =   out.rfree   ;
lambdac =   out.lambdac ;
lambdaf =   out.lambdaf ;
lambdan =   out.lambdan ;
mm1c    =   out.mm1c    ;
mm1f    =   out.mm1f    ;
mm1n    =   out.mm1n    ;
mbarc	=	out.mbarc	;
mbarf	=	out.mbarf	;
mbarn	=	out.mbarn	;
mubar	=	out.mubar	;
Xi      =   out.Xi  ;
Rc	    =	out.Rc	;
Rf	    =	out.Rf	;
Rn	    =	out.Rn	;
qc	    =	out.qc	;
qf	    =	out.qf	;
qn	    =	out.qn	;
Dqc 	=	out.Dqc	;
Dqf	    =	out.Dqf	;
Dqn	    =	out.Dqn	;
Fc	    =	out.Fc	;
Ff	    =	out.Ff	;
Fn	    =	out.Fn	;
Fmu	    =	out.Fmu	;
Gc	    =	out.Gc	;
Gf	    =	out.Gf	;
Gn	    =	out.Gn	;
Gmu	    =	out.Gmu	;
DFc	    =	out.DFc	;
DFf	    =	out.DFf	;
DFn	    =	out.DFn	;

end