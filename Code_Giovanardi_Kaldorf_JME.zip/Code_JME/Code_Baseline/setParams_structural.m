function par = setParams_structural()

% preferences
par.BETA        = 0.99;    % discount factor (household)
par.GAMMA_C     = 2;        % consumption crra
par.OMEGA_D     = 0.0074;    % weight on miu 
par.GAMMA_D     = 1.5;      % miu curvature 
par.OMEGA_N     = 20;        % weight on labour disutility
par.GAMMA_N     = 1;        % Frisch elasticity of labour supply

% technology
par.ALPHA       = 1/3;      % Cobb-Douglas parameter labor/intermediate goods
par.DELTAE      = 0.0;        % emission persistence
par.DELTAK      = 0.08;     % depreciation rate
par.PSID        = 0.1;    % damage parameter
par.PSII        = 2;        % investment adjustment cost
par.PSIN        = 0.63;      % share of sticky wage households
par.PSIP        = 4.5;      % Rotemberg parameter
par.PHI         = 6;        % goods demand elasticity
par.PHITILDE    = 3;        % labor demand elasticity
par.NUTILDE     = 0.0015;   % energy weight 
par.EPSTILDE    = 0.2;      % elasticity of substitution (energy-non-energy) 
par.NU          = 0.3865;   % clean energy weight
par.EPS         = 3;        % elasticity of substitution (clean fossil)
par.THETA1      = 0.05;     % abatement cost slope 
par.THETA2      = 1.6;      % abatement cost curvature 

% financial block
par.BETAE       = 0.988;    % discount factor (entrepreneur) 0.988
par.CHI         = 0.2;     % maturity parameter
par.VARPHI      = 0.12;      % restructuring cost
par.SDEVM       = 0.2;     % std. deviation of idiosyncratic prod
par.MEANM       = -0.5*par.SDEVM^2;
par.SDEVMU      = 0.0315;    % std. deviation of bank return
par.MEANMU      = -0.5*par.SDEVMU^2;
par.ZETA        = 0.0115;   % bailout cost

% monetary policy
par.PHI_PI      = 2;
par.RHO_R       = 0;
par.SIGMA_R     = 0.015;

% fiscal policy
par.TAXK        = 0;
par.TAXE        = 0;

% shocks
par.RHO_A    	= 0.8;    % persistence TFP
par.SIGMA_A  	= 0.004;   % standard deviation TFP shock

% auxiliary constants
par.s1 = 105*1E9/0.441032; 
par.s2 = 37.5*1E6/0.318386;

end