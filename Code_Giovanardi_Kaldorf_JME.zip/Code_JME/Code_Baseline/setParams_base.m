function par = setParams_base()

par = setParams_structural();

% bank regulation
par.KAPPACss    = 0.08;    % clean
par.KAPPAFss    = 0.08;    % fossil
par.KAPPANss    = 0.08;    % non-energy

% climate policy
par.TAXE        = 0.0;    % emission tax 
par.TAXK        = 0.0;    % fossil capital tax

end