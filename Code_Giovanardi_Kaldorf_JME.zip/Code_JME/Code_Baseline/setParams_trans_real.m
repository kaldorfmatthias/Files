function par = setParams_trans_real()

par = setParams_structural();

% bank regulation
par.KAPPACss    = 0.08;    % clean
par.KAPPAFss    = 0.08;    % fossil
par.KAPPANss    = 0.08;    % non-energy

% climate policy
par.TAXE        = 0.0;    % emission tax 
par.TAXK        = 0.0;    % fossil capital tax

% nominal rigidities
par.PSIN        = 0.01;      % share of sticky wage households
par.PSIP        = 0.01;      % Rotemberg parameter

end