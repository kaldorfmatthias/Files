%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  optimal symmetric bank capital requirements
%  this script generates Figure C.3 and Figure C.4

clear all; clc; close all;

%% long-run effects of symmetric capital requirements for different tax levels
eval(['dynare model_base.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
nkappa          = 61;
polMat.KAPPA    = linspace(0.04,0.1,nkappa);

C_pos    = strmatch('c',M_.endo_names,'exact');
E_pos    = strmatch('E',M_.endo_names,'exact');
F_pos    = strmatch('Fagg',M_.endo_names,'exact');
FMU_pos  = strmatch('Fmu',M_.endo_names,'exact');
K_pos    = strmatch('kagg',M_.endo_names,'exact');
L_pos    = strmatch('lagg',M_.endo_names,'exact');
RD_pos   = strmatch('yielddep',M_.endo_names,'exact');
RF_pos   = strmatch('yieldrf',M_.endo_names,'exact');
V_pos    = strmatch('V',M_.endo_names,'exact');
Y_pos    = strmatch('y',M_.endo_names,'exact');
YF_pos   = strmatch('yieldf',M_.endo_names,'exact');

vecBankfailure_notax  = nan(nkappa,1);
vecCapital_notax      = nan(nkappa,1);
vecConsumption_notax  = nan(nkappa,1);
vecDepspread_notax    = nan(nkappa,1);
vecDefaultrate_notax  = nan(nkappa,1);
vecEmissions_notax    = nan(nkappa,1);
vecLoan_notax         = nan(nkappa,1);
vecOutput_notax       = nan(nkappa,1);
vecWelfare_notax      = nan(nkappa,1);
vecYield_notax        = nan(nkappa,1);

vecBankfailure_tax  = nan(nkappa,1);
vecDepspread_tax    = nan(nkappa,1);
vecDefaultrate_tax  = nan(nkappa,1);
vecCapital_tax      = nan(nkappa,1);
vecConsumption_tax  = nan(nkappa,1);
vecEmissions_tax    = nan(nkappa,1);
vecLoan_tax         = nan(nkappa,1);
vecOutput_tax       = nan(nkappa,1);
vecWelfare_tax      = nan(nkappa,1);
vecYield_tax        = nan(nkappa,1);

for ikappa = 1:nkappa
           
        set_param_value('KAPPACss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPAFss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPANss',polMat.KAPPA(1,ikappa));
        set_param_value('TAXE',0);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.mean        = oo_.mean;

        vecBankfailure_notax(ikappa,1)      = results.mean(FMU_pos);
        vecCapital_notax(ikappa,1)          = results.mean(K_pos);
        vecConsumption_notax(ikappa,1)      = results.mean(C_pos);
        vecDepspread_notax(ikappa,1)        = results.mean(RD_pos)-results.mean(RF_pos);
        vecDefaultrate_notax(ikappa,1)      = results.mean(F_pos);
        vecEmissions_notax(ikappa,1)        = results.mean(E_pos);
        vecLoan_notax(ikappa,1)             = results.mean(L_pos);
        vecOutput_notax(ikappa,1)           = results.mean(Y_pos);
        vecWelfare_notax(ikappa,1)          = results.mean(V_pos);
        vecYield_notax(ikappa,1)            = results.mean(YF_pos);

        set_param_value('TAXE',0.0499);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.mean        = oo_.mean;
        
        vecBankfailure_tax(ikappa,1)      = results.mean(FMU_pos);
        vecCapital_tax(ikappa,1)          = results.mean(K_pos);
        vecConsumption_tax(ikappa,1)      = results.mean(C_pos);
        vecDepspread_tax(ikappa,1)        = results.mean(RD_pos)-results.mean(RF_pos);
        vecDefaultrate_tax(ikappa,1)      = results.mean(F_pos);
        vecEmissions_tax(ikappa,1)        = 0;
        vecLoan_tax(ikappa,1)             = results.mean(L_pos);
        vecOutput_tax(ikappa,1)           = results.mean(Y_pos);
        vecWelfare_tax(ikappa,1)          = results.mean(V_pos);
        vecYield_tax(ikappa,1)            = results.mean(YF_pos);

        clc
        fprintf('capital requirement : %1.0f \n',ikappa);
        
end

ind_max_notax = find(vecWelfare_notax == max(vecWelfare_notax));
ind_max_tax = find(vecWelfare_tax == max(vecWelfare_tax));
display(['Optimal KAPPA without tax = ' num2str(polMat.KAPPA(ind_max_notax))])
display(['Optimal KAPPA under full abatement = ' num2str(polMat.KAPPA(ind_max_tax))])

%% long-run effects of symmetric capital requirements with policy uncertainty
eval(['dynare model_sigmat.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])

nkappa          = 61;
polMat.KAPPA    = linspace(0.04,0.1,nkappa);

C_pos    = strmatch('c',M_.endo_names,'exact');
E_pos    = strmatch('E',M_.endo_names,'exact');
F_pos    = strmatch('Fagg',M_.endo_names,'exact');
FMU_pos  = strmatch('Fmu',M_.endo_names,'exact');
K_pos    = strmatch('kagg',M_.endo_names,'exact');
L_pos    = strmatch('lagg',M_.endo_names,'exact');
RD_pos   = strmatch('yielddep',M_.endo_names,'exact');
RF_pos   = strmatch('yieldrf',M_.endo_names,'exact');
V_pos    = strmatch('V',M_.endo_names,'exact');
Y_pos    = strmatch('y',M_.endo_names,'exact');
YF_pos   = strmatch('yieldf',M_.endo_names,'exact');

vecBankfailure_lowtax  = nan(nkappa,1);
vecCapital_lowtax      = nan(nkappa,1);
vecConsumption_lowtax  = nan(nkappa,1);
vecDepspread_lowtax    = nan(nkappa,1);
vecDefaultrate_lowtax  = nan(nkappa,1);
vecEmissions_lowtax    = nan(nkappa,1);
vecLoan_lowtax         = nan(nkappa,1);
vecOutput_lowtax       = nan(nkappa,1);
vecWelfare_lowtax      = nan(nkappa,1);
vecYield_lowtax        = nan(nkappa,1);

vecBankfailure_taxshock  = nan(nkappa,1);
vecDepspread_taxshock    = nan(nkappa,1);
vecDefaultrate_taxshock  = nan(nkappa,1);
vecCapital_taxshock      = nan(nkappa,1);
vecConsumption_taxshock  = nan(nkappa,1);
vecEmissions_taxshock    = nan(nkappa,1);
vecLoan_taxshock         = nan(nkappa,1);
vecOutput_taxshock       = nan(nkappa,1);
vecWelfare_taxshock      = nan(nkappa,1);
vecYield_taxshock        = nan(nkappa,1);

for ikappa = 1:nkappa
           
        set_param_value('KAPPACss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPAFss',polMat.KAPPA(1,ikappa));
        set_param_value('KAPPANss',polMat.KAPPA(1,ikappa));
        set_param_value('TAXEss',0.005);
        set_param_value('SIGMA_T',0);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.mean         = oo_.mean;

        vecBankfailure_lowtax(ikappa,1)      = results.mean(FMU_pos);
        vecCapital_lowtax(ikappa,1)          = results.mean(K_pos);
        vecConsumption_lowtax(ikappa,1)      = results.mean(C_pos);
        vecDepspread_lowtax(ikappa,1)        = results.mean(RD_pos)-results.mean(RF_pos);
        vecDefaultrate_lowtax(ikappa,1)      = results.mean(F_pos);
        vecEmissions_lowtax(ikappa,1)        = results.mean(E_pos);
        vecLoan_lowtax(ikappa,1)             = results.mean(L_pos);
        vecOutput_lowtax(ikappa,1)           = results.mean(Y_pos);
        vecWelfare_lowtax(ikappa,1)          = results.mean(V_pos);
        vecYield_lowtax(ikappa,1)            = results.mean(YF_pos);

        set_param_value('TAXEss',0.0025);
        set_param_value('SIGMA_T', 0.0015);
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.mean        = oo_.mean;

        vecBankfailure_taxshock(ikappa,1)      = results.mean(FMU_pos);
        vecCapital_taxshock(ikappa,1)          = results.mean(K_pos);
        vecConsumption_taxshock(ikappa,1)      = results.mean(C_pos);
        vecDepspread_taxshock(ikappa,1)        = results.mean(RD_pos)-results.mean(RF_pos);
        vecDefaultrate_taxshock(ikappa,1)      = results.mean(F_pos);
        vecEmissions_taxshock(ikappa,1)        = results.mean(E_pos);
        vecLoan_taxshock(ikappa,1)             = results.mean(L_pos);
        vecOutput_taxshock(ikappa,1)           = results.mean(Y_pos);
        vecWelfare_taxshock(ikappa,1)          = results.mean(V_pos);
        vecYield_taxshock(ikappa,1)            = results.mean(YF_pos);

        clc
        fprintf('capital requirement : %1.0f \n',ikappa);
        
end

ind_max_low = find(vecWelfare_lowtax == max(vecWelfare_lowtax));
ind_max_shock = find(vecWelfare_taxshock == max(vecWelfare_taxshock));
display(['Optimal KAPPA without policy uncertainty = ' num2str(polMat.KAPPA(ind_max_low))])
display(['Optimal KAPPA with policy uncertainty = ' num2str(polMat.KAPPA(ind_max_shock))])

%% Figure 4: macro effects of symm capital requirements 
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 12;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 7;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultLineMarkerSize',8) 

fig = figure;
subplot(2,2,1)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,vecDepspread_notax,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,vecDepspread_tax,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('Liquidity Premium (bps)')
xlabel('Capital Requirement (%)')
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)

subplot(2,2,2)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecBankfailure_notax,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,100*vecBankfailure_tax,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('Bank Failure Rate (%)')
xlabel('Capital Requirement (%)')
ylim([0 5])
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)
%lgd = legend('No Tax','Net Zero Tax','Location','southoutside');

subplot(2,2,3)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,vecDepspread_lowtax,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,vecDepspread_taxshock,'LineWidth',2,'color','m','LineStyle',':');
title('Liquidity Premium (bps)')
xlabel('Capital Requirement (%)')
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)

subplot(2,2,4)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100+100*vecBankfailure_notax,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,100+100*vecBankfailure_tax,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
plot(100*polMat.KAPPA,100*vecBankfailure_lowtax,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,100*vecBankfailure_taxshock,'LineWidth',2,'color','m','LineStyle',':');
title('Bank Failure Rate (%)')
xlabel('Capital Requirement (%)')
ylim([0 5])
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)
lgd = legend('No Tax','Net Zero Tax','Current Tax','Policy Uncertainty','Orientation','horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.125;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
%fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','longrun_kappa');

%% Figure C.3: macro effects of symm capital requirements for different tax levels
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 10;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 7;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',2)
set(0,'DefaultLineMarkerSize',8) 

fig = figure;
subplot(2,3,1)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecDefaultrate_notax,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,100*vecDefaultrate_tax,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)
ylim([1.6 2.3])
title('Corporate Default Rate (p.p.)')

subplot(2,3,2)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecLoan_notax/vecLoan_notax(ind_max_notax)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,100*vecLoan_tax/vecLoan_tax(ind_max_notax)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)
yline(0)
title('\Delta Loans (%)')

subplot(2,3,3)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecCapital_notax/vecCapital_notax(ind_max_notax)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,100*vecCapital_tax/vecCapital_tax(ind_max_notax)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)
yline(0)
title('\Delta Capital (%)')

subplot(2,3,4)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecOutput_notax/vecOutput_notax(ind_max_notax)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,100*vecOutput_tax/vecOutput_tax(ind_max_notax)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)
yline(0)
xlabel('Capital Requirement (%)')
title('\Delta GDP (%)')

subplot(2,3,5)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,vecYield_notax,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,vecYield_tax,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
ylim([50 70])
title('Loan Rate (bps)')
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)
yline(0)
xlabel('Capital Requirement (%)')

subplot(2,3,6)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*exp(0.01*(vecWelfare_notax-vecWelfare_notax(ind_max_notax)))-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPA,100*exp(0.01*(vecWelfare_tax-vecWelfare_tax(ind_max_notax)))-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
xline(100*polMat.KAPPA(ind_max_notax),'color','red','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_tax),'color',[0.4,0.8,0],'LineWidth',1)
title('\Delta Welfare (%)')

yline(0)
xlabel('Capital Requirement (%)')
lgd = legend('No Tax','Net Zero Tax','Orientation','horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.35;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 7);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','longrun_kappa_level');

%% Figure C.4: macro effects of symm capital requirements with policy uncertainty
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 10;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 7;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',2)
set(0,'DefaultLineMarkerSize',8) 

fig = figure;
subplot(2,3,1)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecDefaultrate_lowtax,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,100*vecDefaultrate_taxshock,'LineWidth',2,'color','m','LineStyle',':');
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)
ylim([1.7 2.3])
title('Corporate Default Rate (p.p.)')

subplot(2,3,2)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecLoan_lowtax/vecLoan_lowtax(ind_max_notax)-100,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,100*vecLoan_taxshock/vecLoan_taxshock(ind_max_notax)-100,'LineWidth',2,'color','m','LineStyle',':');
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)
yline(0)
title('\Delta Loans (%)')

subplot(2,3,3)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecCapital_lowtax/vecCapital_lowtax(ind_max_notax)-100,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,100*vecCapital_taxshock/vecCapital_taxshock(ind_max_notax)-100,'LineWidth',2,'color','m','LineStyle',':');
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)
yline(0)
title('\Delta Capital (%)')

subplot(2,3,4)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*vecOutput_lowtax/vecOutput_lowtax(ind_max_notax)-100,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,100*vecOutput_taxshock/vecOutput_taxshock(ind_max_notax)-100,'LineWidth',2,'color','m','LineStyle',':');
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)
yline(0)
xlabel('Capital Requirement (%)')
title('\Delta GDP (%)')

subplot(2,3,5)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,vecYield_lowtax,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,vecYield_taxshock,'LineWidth',2,'color','m','LineStyle',':');
ylim([50 70])
title('Loan Rate (bps)')
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)
yline(0)
xlabel('Capital Requirement (%)')

subplot(2,3,6)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPA,100*exp(0.01*(vecWelfare_lowtax-vecWelfare_lowtax(ind_max_notax)))-100,'LineWidth',2,'color','blue');
plot(100*polMat.KAPPA,100*exp(0.01*(vecWelfare_taxshock-vecWelfare_taxshock(ind_max_notax)))-100,'LineWidth',2,'color','m','LineStyle',':');
title('\Delta Welfare (%)')
xline(100*polMat.KAPPA(ind_max_low),'color','blue','LineWidth',1)
xline(100*polMat.KAPPA(ind_max_shock),'color','m','LineWidth',1)
yline(0)
xlabel('Capital Requirement (%)')
lgd = legend('Constant Tax','Policy Uncertainty','Orientation','horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.3;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 7);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','longrun_kappa_shock');

%% loop over macro effects of carbon taxes
eval(['dynare model_sigmat.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])

ntax            = 50;
polMat.TAX      = linspace(0.002,0.0498,ntax);

ETA_pos         = strmatch('eta',M_.endo_names,'exact');
FMU_pos         = strmatch('Fmu',M_.endo_names,'exact');
C_pos           = strmatch('c',M_.endo_names,'exact');
RD_pos          = strmatch('yielddep',M_.endo_names,'exact');
RF_pos          = strmatch('yieldrf',M_.endo_names,'exact');
E_pos           = strmatch('e',M_.endo_names,'exact');
FN_pos          = strmatch('Fn',M_.endo_names,'exact');
FC_pos          = strmatch('Fc',M_.endo_names,'exact');
FF_pos          = strmatch('Ff',M_.endo_names,'exact');
KN_pos          = strmatch('kn',M_.endo_names,'exact');
KC_pos          = strmatch('kc',M_.endo_names,'exact');
KF_pos          = strmatch('kf',M_.endo_names,'exact');
LN_pos          = strmatch('lnon',M_.endo_names,'exact');
LC_pos          = strmatch('lc',M_.endo_names,'exact');
LF_pos          = strmatch('lf',M_.endo_names,'exact');
XI_pos          = strmatch('xi',M_.endo_names,'exact');
Y_pos           = strmatch('y',M_.endo_names,'exact');
V_pos           = strmatch('V',M_.endo_names,'exact');

vecBankfailure  = nan(ntax,1);
vecConsumption  = nan(ntax,1);
vecDepspread    = nan(ntax,1);
vecEmissions    = nan(ntax,1);
vecFC           = nan(ntax,1);
vecFF           = nan(ntax,1);
vecFN           = nan(ntax,1);
vecKC           = nan(ntax,1);
vecKF           = nan(ntax,1);
vecKN           = nan(ntax,1);
vecLN           = nan(ntax,1);
vecLC           = nan(ntax,1);
vecLF           = nan(ntax,1);
vecOutput       = nan(ntax,1);
vecWelfare      = nan(ntax,1);

vecBankfailure_sigmat  = nan(ntax,1);
vecConsumption_sigmat  = nan(ntax,1);
vecDepspread_sigmat    = nan(ntax,1);
vecEmissions_sigmat    = nan(ntax,1);
vecFC_sigmat           = nan(ntax,1);
vecFF_sigmat           = nan(ntax,1);
vecFN_sigmat           = nan(ntax,1);
vecKC_sigmat           = nan(ntax,1);
vecKF_sigmat           = nan(ntax,1);
vecKN_sigmat           = nan(ntax,1);
vecLN_sigmat           = nan(ntax,1);
vecLC_sigmat           = nan(ntax,1);
vecLF_sigmat           = nan(ntax,1);
vecOutput_sigmat       = nan(ntax,1);
vecWelfare_sigmat      = nan(ntax,1);

% loop over tax parameters
for itax = 1:ntax
    
    set_param_value('SIGMA_T', 0.000);
    set_param_value('TAXEss', polMat.TAX(1,itax));
    oo_.steady_state     = steady_(M_,options_,oo_);
    [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
    results.mean        = oo_.mean;

    vecBankfailure(itax,1)  = results.mean(FMU_pos);
    vecConsumption(itax,1)  = results.mean(C_pos);
    vecDepspread(itax,1)    = results.mean(RD_pos)-results.mean(RF_pos);
    vecEmissions(itax,1)    = results.mean(E_pos);
    vecFN(itax,1)           = results.mean(FN_pos);
    vecFC(itax,1)           = results.mean(FC_pos);
    vecFF(itax,1)           = results.mean(FF_pos);
    vecKN(itax,1)           = results.mean(KN_pos);
    vecKC(itax,1)           = results.mean(KC_pos);
    vecKF(itax,1)           = results.mean(KF_pos);
    vecLN(itax,1)           = results.mean(LN_pos);
    vecLC(itax,1)           = results.mean(LC_pos);
    vecLF(itax,1)           = results.mean(LF_pos);
    vecWelfare(itax,1)      = results.mean(V_pos);
    vecOutput(itax,1)       = results.mean(Y_pos);
    
    set_param_value('SIGMA_T', 0.0024);
    oo_.steady_state     = steady_(M_,options_,oo_);
    [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
    results.mean        = oo_.mean;

    vecBankfailure_sigmat(itax,1)  = results.mean(FMU_pos);
    vecConsumption_sigmat(itax,1)  = results.mean(C_pos);
    vecDepspread_sigmat(itax,1)    = results.mean(RD_pos)-results.mean(RF_pos);
    vecEmissions_sigmat(itax,1)    = results.mean(E_pos);
    vecFN_sigmat(itax,1)            = results.mean(F_pos);
    vecFC_sigmat(itax,1)           = results.mean(FC_pos);
    vecFF_sigmat(itax,1)           = results.mean(FF_pos);
    vecKN_sigmat(itax,1)            = results.mean(K_pos);
    vecKC_sigmat(itax,1)           = results.mean(KC_pos);
    vecKF_sigmat(itax,1)           = results.mean(KF_pos);
    vecLN_sigmat(itax,1)            = results.mean(L_pos);
    vecLC_sigmat(itax,1)           = results.mean(LC_pos);
    vecLF_sigmat(itax,1)           = results.mean(LF_pos);
    vecWelfare_sigmat(itax,1)      = results.mean(V_pos);
    vecOutput_sigmat(itax,1)       = results.mean(Y_pos);

    clc
    fprintf('tax parameter  : %1.0f \n',itax);

end

%% Figure C.2: plot macro effects of carbon taxes

% GDP 105 trillion in 2022
s1 = 105*1E9/0.590541; 
% emissions 37.5 GtCO2 in 2022
s2 = 37.5*1E6/0.447941;
% full abatement carbon price in USD/tCO2
s1/s2*0.05;
s1/s2*0.0024

opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 18;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 9;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultLineMarkerSize',8) 

fig = figure;
subplot(5,3,1)
hold on; box on; grid on; grid minor; 
plot(s1/s2*polMat.TAX,100*vecEmissions/vecEmissions(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecEmissions_sigmat/vecEmissions_sigmat(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('Emission Reduction (%)')
xlim([0,105])

subplot(5,3,2)
hold on; box on; grid on; grid minor; 
plot(s1/s2*polMat.TAX,100*vecBankfailure,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecBankfailure_sigmat,'LineWidth',1.5,'color','m','LineStyle','--');
title('Bank Failure (%)')
ylim([0.5 0.7])
xlim([0,105])

subplot(5,3,3)
hold on; box on; grid on; grid minor; 
plot(s1/s2*polMat.TAX,vecDepspread,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,vecDepspread_sigmat,'LineWidth',1.5,'color','m','LineStyle','--');
title('Liquidity Premium (bps)')
xlim([0,105])

subplot(5,3,4)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecConsumption/vecConsumption(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecConsumption_sigmat/vecConsumption(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Consumption (%)')
xlim([0,105])

subplot(5,3,5)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecOutput/vecOutput(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecOutput_sigmat/vecOutput(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta GDP (%)')
xlim([0,105])

subplot(5,3,6)
hold on; box on; grid on; grid minor; 
plot(s1/s2*polMat.TAX,100*exp(0.01*(vecWelfare-vecWelfare(1)))-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*exp(0.01*(vecWelfare_sigmat-vecWelfare(1)))-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Welfare, CE (%)')
xlim([0,105])

subplot(5,3,7)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecKF/vecKF(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecKF_sigmat/vecKF(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Fossil Capital (%)')
xlim([0,105])

subplot(5,3,8)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecKC/vecKC(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecKC_sigmat/vecKC(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Clean Capital (%)')
xlim([0,105])

subplot(5,3,9)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecKN/vecKN(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecKN_sigmat/vecKN(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Non-Energy Capital (%)')
xlim([0,105])

subplot(5,3,10)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecLF/vecLF(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecLF_sigmat/vecLF(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Fossil Loans (%)')
xlim([0,105])

subplot(5,3,11)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecLC/vecLC(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecLC_sigmat/vecLC(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Clean Loans (%)')
xlim([0,105])

subplot(5,3,12)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecLN/vecLN(1)-100,'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecLN_sigmat/vecLN(1)-100,'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Non-Energy Loans (%)')
xlim([0,105])

subplot(5,3,13)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecFF-100*vecFF(1),'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecFF_sigmat-100*vecFF(1),'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Fossil Default (p.p.)')
xlabel('Emission Tax ($/tCO2)')
xlim([0,105])

subplot(5,3,14)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecFC-100*vecFC(1),'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecFC_sigmat-100*vecFC(1),'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Clean Default (p.p.)')
xlabel('Emission Tax ($/tCO2)')
xlim([0,105])

subplot(5,3,15)
hold on; box on; grid on; grid minor;
plot(s1/s2*polMat.TAX,100*vecFN-100*vecFN(1),'LineWidth',1.5,'color','blue');
plot(s1/s2*polMat.TAX,100*vecFN_sigmat-100*vecFN(1),'LineWidth',1.5,'color','m','LineStyle','--');
title('\Delta Non-Energy Default (p.p.)')
xlabel('Emission Tax ($/tCO2)')
xlim([0,105])
lgd = legend('Baseline','Policy Uncertainty','Orientation','Horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.3;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','longrun_carbontax_app');