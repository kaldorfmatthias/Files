%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  Residuals of financial market clearing condition, given goods markets
%  Baseline model

function [resid,out] = fresidFIN(finguess,out,par)

out.mm1c    = finguess(1);
out.mm1f    = finguess(2);
out.mm1n    = finguess(3);
out.mbarc   = finguess(4);
out.mbarf   = finguess(5);
out.mbarn   = finguess(6);
out.mubar   = finguess(7);
out.rdep    = finguess(8);

if ~isreal(out.mbarc) || ~isreal(out.mbarf) || ~isreal(out.mbarn)
    error('Calibration results in negative default probability, sigM too small')
end

if out.mbarc<0 || out.mbarf<0 || out.mbarn<0
    error('Calibration results in negative mbar')
end

% distribution
out.Fc      = normcdf((log(out.mbarc)-par.MEANM)/par.SDEVM);
out.Ff      = normcdf((log(out.mbarf)-par.MEANM)/par.SDEVM);
out.Fn      = normcdf((log(out.mbarn)-par.MEANM)/par.SDEVM);
out.Fmu     = normcdf((log(out.mubar)-par.MEANMU)/par.SDEVMU);
out.Gc      = normcdf((log(out.mbarc)-par.MEANM-par.SDEVM^2)/par.SDEVM);
out.Gf      = normcdf((log(out.mbarf)-par.MEANM-par.SDEVM^2)/par.SDEVM);
out.Gn      = normcdf((log(out.mbarn)-par.MEANM-par.SDEVM^2)/par.SDEVM);
out.Gmu     = normcdf((log(out.mubar)-par.MEANMU-par.SDEVMU^2)/par.SDEVMU);
out.DFc     = 1 / (out.mbarc * par.SDEVM * sqrt(2*pi)) * exp(-1 * (log(out.mbarc) - par.MEANM)^2 / (2 * par.SDEVM^2) );
out.DFf     = 1 / (out.mbarf * par.SDEVM * sqrt(2*pi)) * exp(-1 * (log(out.mbarf) - par.MEANM)^2 / (2 * par.SDEVM^2) ); 
out.DFn     = 1 / (out.mbarn * par.SDEVM * sqrt(2*pi)) * exp(-1 * (log(out.mbarn) - par.MEANM)^2 / (2 * par.SDEVM^2) ); 

% deposit financing wedge
out.Xi = (1/(1+out.rdep) - par.BETA*(1-out.Fmu));

% derivative of bond prices
out.Dqc = - ((1-out.KAPPAC)*out.Xi + par.BETA*(1-out.Gmu)) * par.CHI * (out.Gc/out.mbarc^2 + par.VARPHI*out.DFc) / ( 1 - ((1-out.KAPPAC)*out.Xi + par.BETA*(1-out.Gmu))*(1-par.CHI)*out.mm1c );
out.Dqf = - ((1-out.KAPPAF)*out.Xi + par.BETA*(1-out.Gmu)) * par.CHI * (out.Gf/out.mbarf^2 + par.VARPHI*out.DFf) / ( 1 - ((1-out.KAPPAF)*out.Xi + par.BETA*(1-out.Gmu))*(1-par.CHI)*out.mm1f );
out.Dqn = - ((1-out.KAPPAN)*out.Xi + par.BETA*(1-out.Gmu)) * par.CHI * (out.Gn/out.mbarn^2 + par.VARPHI*out.DFn) / ( 1 - ((1-out.KAPPAN)*out.Xi + par.BETA*(1-out.Gmu))*(1-par.CHI)*out.mm1n );

% Implied bond prices from entrepreneur FOC for loans
out.qc = ( -par.CHI*( -par.BETAE*(1-out.Fc) + out.Dqc*out.mbarc*(1+par.BETAE*out.mm1c) ) ) / (1-par.BETAE*(1-par.CHI));
out.qf = ( -par.CHI*( -par.BETAE*(1-out.Ff) + out.Dqf*out.mbarf*(1+par.BETAE*out.mm1f) ) ) / (1-par.BETAE*(1-par.CHI));
out.qn = ( -par.CHI*( -par.BETAE*(1-out.Fn) + out.Dqn*out.mbarn*(1+par.BETAE*out.mm1n) ) ) / (1-par.BETAE*(1-par.CHI));

% loan payoff
out.Rc      = par.CHI*(out.Gc/out.mbarc + 1-out.Fc - out.Fc*par.VARPHI) + (1-par.CHI)*out.qc;
out.Rf      = par.CHI*(out.Gf/out.mbarf + 1-out.Ff - out.Ff*par.VARPHI) + (1-par.CHI)*out.qf;
out.Rn      = par.CHI*(out.Gn/out.mbarn + 1-out.Fn - out.Fn*par.VARPHI) + (1-par.CHI)*out.qn;

% initial guesses kc, kf, kn, c, n
if par.TAXE > 0.049
prodguess = [0.16,0.38,1.24,0.45,0.45];
else
prodguess = [0.11,0.44,1.25,0.45,0.45];
end

% solve
options     = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-16,'FunctionTolerance',1e-16);
prodstar    = fsolve(@(x) (fresidPROD(x,out,par)),prodguess,options);

[valfun,out] = fresidPROD(prodstar,out,par);

if max(abs(valfun)) > 1e-12
    error('Excess demand on some market not zero, investors too imaptient')
end

% deposits from HH foc and from bank capital constraint
d1          = ((1-out.KAPPAC)*out.Rc*out.lc + (1-out.KAPPAF)*out.Rf*out.lf + (1-out.KAPPAN)*out.Rn*out.lnon)/(1+out.rdep);
mubar1      = (1+out.rdep)*out.d/(out.Rc*out.lc + out.Rf*out.lf + out.Rn*out.lnon);

% loan price consistent with bank FOC
qc1 = out.Rc * ( (1-out.KAPPAC)*out.Xi + par.BETA*(1-out.Gmu) );
qf1 = out.Rf * ( (1-out.KAPPAF)*out.Xi + par.BETA*(1-out.Gmu) );
qn1 = out.Rn * ( (1-out.KAPPAN)*out.Xi + par.BETA*(1-out.Gmu) );

% slope of policy function
mm11c = ( (out.qc+out.mbarc*out.Dqc)/par.BETAE - par.CHI*(1-out.Fc)-(1-par.CHI)*out.qc ) / ((1-par.CHI)*out.Dqc*out.mbarc);
mm11f = ( (out.qf+out.mbarf*out.Dqf)/par.BETAE - par.CHI*(1-out.Ff)-(1-par.CHI)*out.qf ) / ((1-par.CHI)*out.Dqf*out.mbarf);
mm11n = ( (out.qn+out.mbarn*out.Dqn)/par.BETAE - par.CHI*(1-out.Fn)-(1-par.CHI)*out.qn ) / ((1-par.CHI)*out.Dqn*out.mbarn);

% Residuals
resid(1)    = qc1 - out.qc;
resid(2)    = qf1 - out.qf;
resid(3)    = qn1 - out.qn;
resid(4)    = d1 - out.d;
resid(5)    = mubar1 - out.mubar;
resid(6)    = mm11c - out.mm1c;
resid(7)    = mm11f - out.mm1f;
resid(8)    = mm11n - out.mm1n;

end
