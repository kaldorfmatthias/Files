%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  tilted bank capital requirements
%  this script generates Table 3, Figure 1

clear all; clc; close all;

%% baseline: no policy
par = setParams_structural();
eval(['dynare model_base.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])

V_pos    = strmatch('V',M_.endo_names,'exact');
results_base.welfare = oo_.mean(V_pos);
results_base.mean = oo_.mean;
results_base.var = oo_.var;
results_base.M_ = M_;
momentsModel(results_base)
momentsModel2nd(results_base)

% Table 3
% full abatement tax
set_param_value('TAXE',0.049)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_paris.mean = oo_.mean;
results_paris.M_ = M_;

% KAPPAF = 1
set_param_value('TAXE',0.0)
set_param_value('KAPPAFss',1)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_kappaf1.mean = oo_.mean;
results_kappaf1.M_ = M_;

% low emission tax 0.0025*par.s1/par.s2 = 5 USD/tCO2
set_param_value('KAPPAFss',0.08)
set_param_value('TAXE',0.0025)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_taue.mean = oo_.mean;
results_taue.M_ = M_;

% fossil capital tax 1%
set_param_value('TAXE',0.00)
set_param_value('TAXK',0.01)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_tauk.mean = oo_.mean;
results_tauk.M_ = M_;

% low emission tax 0.005
set_param_value('KAPPAFss',0.08)
set_param_value('TAXE',0.0025)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_low.mean = oo_.mean;
results_low.M_ = M_;

% tax shocks
eval(['dynare model_sigmat.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
set_param_value('TAXEss',0.0025)
set_param_value('SIGMA_T',0.0025)
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_shocks.mean = oo_.mean;
results_shocks.M_ = M_;

% slc
eval(['dynare model_slc.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
oo_.steady_state = steady_(M_,options_,oo_);
[info,oo_,~,M_]  = stoch_simul(M_, options_, oo_, var_list_);   
results_slc.mean = oo_.mean;
results_slc.M_ = M_;
%momentsModel(results_slc)

%% Table 3
momentsKey(results_kappaf1,results_base)
momentsKey(results_slc,results_base)
momentsKey(results_taue,results_base)
momentsKey(results_paris,results_base)
momentsKey(results_tauk,results_base)

% Table D.1-D.3
momentsKey(results_low,results_base)
momentsKey(results_shocks,results_base)

%% long-run effects of fossil capital requirements
eval(['dynare model_base.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])

V_pos    = strmatch('V',M_.endo_names,'exact');
results_base.welfare = oo_.mean(V_pos);

nkappaf         = 93;
polMat.KAPPAF   = linspace(0.08,1,nkappaf);

ETA_pos         = strmatch('eta',M_.endo_names,'exact');
FMU_pos         = strmatch('Fmu',M_.endo_names,'exact');
C_pos           = strmatch('c',M_.endo_names,'exact');
RD_pos          = strmatch('yielddep',M_.endo_names,'exact');
RF_pos          = strmatch('yieldrf',M_.endo_names,'exact');
E_pos           = strmatch('e',M_.endo_names,'exact');
FN_pos          = strmatch('Fn',M_.endo_names,'exact');
FC_pos          = strmatch('Fc',M_.endo_names,'exact');
FF_pos          = strmatch('Ff',M_.endo_names,'exact');
KN_pos          = strmatch('kn',M_.endo_names,'exact');
KC_pos          = strmatch('kc',M_.endo_names,'exact');
KF_pos          = strmatch('kf',M_.endo_names,'exact');
LN_pos          = strmatch('lnon',M_.endo_names,'exact');
LC_pos          = strmatch('lc',M_.endo_names,'exact');
LF_pos          = strmatch('lf',M_.endo_names,'exact');
Y_pos           = strmatch('y',M_.endo_names,'exact');
V_pos           = strmatch('V',M_.endo_names,'exact');

vecBankfailure  = nan(nkappaf,1);
vecConsumption  = nan(nkappaf,1);
vecDepspread    = nan(nkappaf,1);
vecEmissions    = nan(nkappaf,1);
vecETA          = nan(nkappaf,1);
vecFC           = nan(nkappaf,1);
vecFF           = nan(nkappaf,1);
vecFN           = nan(nkappaf,1);
vecKC           = nan(nkappaf,1);
vecKF           = nan(nkappaf,1);
vecKN           = nan(nkappaf,1);
vecLN           = nan(nkappaf,1);
vecLC           = nan(nkappaf,1);
vecLF           = nan(nkappaf,1);
vecOutput       = nan(nkappaf,1);
vecWelfare      = nan(nkappaf,1);

for ikappaf = 1:nkappaf
           
        set_param_value('KAPPAFss',polMat.KAPPAF(1,ikappaf));
        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.means        = oo_.mean;
        
        vecBankfailure(ikappaf,1)  = results.means(FMU_pos);
        vecConsumption(ikappaf,1)  = results.means(C_pos);
        vecDepspread(ikappaf,1)    = results.means(RD_pos)-results.means(RF_pos);
        vecEmissions(ikappaf,1)    = results.means(E_pos);
        vecETA(ikappaf,1)          = results.means(ETA_pos);
        vecFN(ikappaf,1)           = results.means(FN_pos);
        vecFC(ikappaf,1)           = results.means(FC_pos);
        vecFF(ikappaf,1)           = results.means(FF_pos);
        vecKN(ikappaf,1)           = results.means(KN_pos);
        vecKC(ikappaf,1)           = results.means(KC_pos);
        vecKF(ikappaf,1)           = results.means(KF_pos);
        vecLN(ikappaf,1)           = results.means(LN_pos);
        vecLC(ikappaf,1)           = results.means(LC_pos);
        vecLF(ikappaf,1)           = results.means(LF_pos);
        vecOutput(ikappaf,1)       = results.means(Y_pos);
        vecWelfare(ikappaf,1)      = results.means(V_pos);


        clc
        fprintf('fossil capital requirement : %1.0f \n',ikappaf);
        
end

%% long-run effects of sustainability linked capital requirements
eval(['dynare model_slc.mod noclearall -Dperorder=2 -Dnirf=0 -Dnperiods=0'])
nkappaf          = 93;
polMat.KAPPAFPEN = linspace(0.08,1,nkappaf);
polMat.KAPPAFPEN(4) = 0.111;

ETA_pos         = strmatch('eta',M_.endo_names,'exact');
FMU_pos         = strmatch('Fmu',M_.endo_names,'exact');
C_pos           = strmatch('c',M_.endo_names,'exact');
RD_pos          = strmatch('yielddep',M_.endo_names,'exact');
RF_pos          = strmatch('yieldrf',M_.endo_names,'exact');
E_pos           = strmatch('e',M_.endo_names,'exact');
FN_pos          = strmatch('Fn',M_.endo_names,'exact');
FC_pos          = strmatch('Fc',M_.endo_names,'exact');
FF_pos          = strmatch('Ff',M_.endo_names,'exact');
KN_pos          = strmatch('kn',M_.endo_names,'exact');
KC_pos          = strmatch('kc',M_.endo_names,'exact');
KF_pos          = strmatch('kf',M_.endo_names,'exact');
LN_pos          = strmatch('lnon',M_.endo_names,'exact');
LC_pos          = strmatch('lc',M_.endo_names,'exact');
LF_pos          = strmatch('lf',M_.endo_names,'exact');
Y_pos           = strmatch('y',M_.endo_names,'exact');
V_pos           = strmatch('V',M_.endo_names,'exact');

vecBankfailure_slc  = vecBankfailure;
vecConsumption_slc  = vecConsumption;
vecDepspread_slc    = vecDepspread;
vecEmissions_slc    = vecEmissions;
vecETA_slc          = vecETA;
vecFC_slc           = vecFC;
vecFF_slc           = vecFF;
vecFN_slc           = vecFN;
vecKC_slc           = vecKC;
vecKF_slc           = vecKF;
vecKN_slc           = vecKN;
vecLN_slc           = vecLN;
vecLC_slc           = vecLC;
vecLF_slc           = vecLF;
vecOutput_slc       = vecOutput;
vecWelfare_slc      = vecWelfare;

for ikappaf = 2:nkappaf
           
        set_param_value('KAPPAFPEN',polMat.KAPPAFPEN(1,ikappaf));

        oo_.steady_state     = steady_(M_,options_,oo_);
        [info,oo_,~,M_]      = stoch_simul(M_, options_, oo_, var_list_);     
        results.M_           = M_;
        results.means        = oo_.mean;

        vecBankfailure_slc(ikappaf,1)  = results.means(FMU_pos);
        vecConsumption_slc(ikappaf,1)  = results.means(C_pos);
        vecDepspread_slc(ikappaf,1)    = results.means(RD_pos)-results.means(RF_pos);
        vecEmissions_slc(ikappaf,1)    = results.means(E_pos);
        vecETA_slc(ikappaf,1)          = results.means(ETA_pos);
        vecFN_slc(ikappaf,1)           = results.means(FN_pos);
        vecFC_slc(ikappaf,1)           = results.means(FC_pos);
        vecFF_slc(ikappaf,1)           = results.means(FF_pos);
        vecKN_slc(ikappaf,1)           = results.means(KN_pos);
        vecKC_slc(ikappaf,1)           = results.means(KC_pos);
        vecKF_slc(ikappaf,1)           = results.means(KF_pos);
        vecLN_slc(ikappaf,1)           = results.means(LN_pos);
        vecLC_slc(ikappaf,1)           = results.means(LC_pos);
        vecLF_slc(ikappaf,1)           = results.means(LF_pos);
        vecOutput_slc(ikappaf,1)       = results.means(Y_pos);
        vecWelfare_slc(ikappaf,1)      = results.means(V_pos);

        clc
        fprintf('slc requirement : %1.0f \n',ikappaf);
        
end

%% Figure 2: fossil capital and SLC requirements for main text
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 12;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 7;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultLineMarkerSize',8) 

fig = figure;
subplot(2,2,2)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecBankfailure,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAFPEN,100*vecBankfailure_slc,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('Bank Failure Rate (%)')
xlabel('Fossil Capital Requirement (%)')
xlim([8 100])

subplot(2,2,1)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecEmissions/vecEmissions(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAFPEN,100*vecEmissions_slc/vecEmissions(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('Emission Reduction (%)')
xlabel('Fossil Capital Requirement (%)')
xlim([8 100])

subplot(2,2,3)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,vecDepspread,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAFPEN,vecDepspread_slc,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('Liquidity Premium (bps)')
xlabel('Fossil Capital Requirement (%)')
xlim([8 100])

subplot(2,2,4)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*exp(0.01*(vecWelfare-results_base.welfare))-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAFPEN,100*exp(0.01*(vecWelfare_slc-results_base.welfare))-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Welfare (%)')
xlabel('Fossil Capital Requirement (%)')
yline(0)
xlim([8 100])
lgd = legend('Simple Fossil $\kappa^f$=100\%','Sustainability Linked $\kappa^{pen}$=100\%','Interpreter','Latex','Orientation','Horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.175;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','longrun_kappaf');

%% Figure C.1: plot macro effects of tilted cap requirement for appendix
opts.Colors     = get(groot,'defaultAxesColorOrder');
opts.width      = 16;
opts.height     = 14;
opts.fontType   = 'Times New Roman';
opts.fontSize   = 7;
set(0,'DefaultFigureRenderer','painters')
set(0,'DefaultLineLineWidth',1.5)
set(0,'DefaultLineMarkerSize',8) 

fig = figure;
subplot(4,3,1)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecConsumption/vecConsumption(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecConsumption_slc/vecConsumption_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Consumption (%)')
xlim([9 100])

subplot(4,3,2)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecOutput/vecOutput(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecOutput_slc/vecOutput_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta GDP (%)')
xlim([9 100])

subplot(4,3,3)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*exp(0.01*(vecWelfare-results_base.welfare))-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAFPEN,100*exp(0.01*(vecWelfare_slc-results_base.welfare))-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Welfare (%)')
xlim([9 100])

subplot(4,3,4)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecKF/vecKF(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecKF_slc/vecKF_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Fossil Capital (%)')
xlim([9 100])

subplot(4,3,5)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecKC/vecKC(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecKC_slc/vecKC_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Clean Capital (%)')
xlim([9 100])

subplot(4,3,6)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecKN/vecKN(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecKN_slc/vecKN_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Non-Energy Capital (%)')
xlim([9 100])

subplot(4,3,7)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecLF/vecLF(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecLF_slc/vecLF_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Fossil Loans (%)')
xlim([9 100])

subplot(4,3,8)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecLC/vecLC(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecLC_slc/vecLC_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Clean Loans (%)')
xlim([9 100])

subplot(4,3,9)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecLN/vecLN(1)-100,'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecLN_slc/vecLN_slc(1)-100,'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Non-Energy Loans (%)')
xlim([9 100])

subplot(4,3,10)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecFF-100*vecFF(1),'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecFF_slc-100*vecFF_slc(1),'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Fossil Default (p.p.)')
xlabel('Capital Requirement (%)')
xlim([9 100])

subplot(4,3,11)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecFC-100*vecFC(1),'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecFC_slc-100*vecFC_slc(1),'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Clean Default (p.p.)')
xlabel('Capital Requirement (%)')
xlim([9 100])

subplot(4,3,12)
hold on; box on; grid on; grid minor;
plot(100*polMat.KAPPAF,100*vecFN-100*vecFN(1),'LineWidth',2,'color','red','LineStyle','--');
plot(100*polMat.KAPPAF,100*vecFN_slc-100*vecFN_slc(1),'LineWidth',2,'color',[0.4,0.8,0],'LineStyle',':');
title('\Delta Non-Energy Default (p.p.)')
xlabel('Capital Requirement (%)')
xlim([9 100])
lgd = legend('Simple Fossil $\kappa^f$=100\%','Sustainability Linked $\kappa^{pen}$=100\%','Interpreter','Latex','Orientation','Horizontal');
lgd.Position(2) = 0.0025;
lgd.Position(1) = 0.225;

% scaling
fig.Units               = 'centimeters';
fig.Position(3)         = opts.width;
fig.Position(4)         = opts.height;

% set text properties
set(fig.Children, 'FontName','Times', 'FontSize', 8);
fig.PaperPositionMode   = 'auto';

print('-r800','-depsc','longrun_kappaf_app');
