%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
%  residuals of goods market clearing condition, given financial markets

function [resid,out] = fresidPROD(prodguess,out,par)

out.kc      = prodguess(1);
out.kf      = prodguess(2);
out.kn      = prodguess(3);
out.c       = prodguess(4);
out.n       = prodguess(5);

% energy supply and environmental block
out.zc      = prodguess(1);
out.zf      = prodguess(2);
out.zn      = prodguess(3);
out.e       = (1-out.eta)*out.zf;
out.E       = out.e/(1-par.DELTAE);
out.etacost = par.THETA1/(1+par.THETA2)*out.eta^(1+par.THETA2)*out.zf;
out.ze      = (par.NU * out.zc^((par.EPS-1)/par.EPS) + (1-par.NU) * out.zf^((par.EPS-1)/par.EPS))^(par.EPS/(par.EPS-1));
out.ztilde  = (par.NUTILDE * out.ze^((par.EPSTILDE-1)/par.EPSTILDE) + (1-par.NUTILDE) * out.zn^((par.EPSTILDE-1)/par.EPSTILDE))^(par.EPSTILDE/(par.EPSTILDE-1));

% Implied energy prices from firm FOC
out.pc = (1-par.BETAE*(1-par.DELTAK)) / (par.BETAE*(1-out.Gc) - out.Dqc*out.mbarc^2*(1+par.BETAE*out.mm1c));             
out.pf = (1-par.BETAE*(1-par.DELTAK)) / (par.BETAE*(1-out.Gf) - out.Dqf*out.mbarf^2*(1+par.BETAE*out.mm1f)) + out.xi; 
out.pn = (1-par.BETAE*(1-par.DELTAK)) / (par.BETAE*(1-out.Gn) - out.Dqn*out.mbarn^2*(1+par.BETAE*out.mm1n));             

% loan demand and Lagrangian from default threshold
out.lc      = out.mbarc*out.pc*out.kc/par.CHI;
out.lf      = out.mbarf*(out.pf-out.xi)*out.kf/par.CHI;
out.lnon    = out.mbarn*out.pn*out.kn/par.CHI;

out.lambdac = -par.CHI*out.lc*out.Dqc*(1+par.BETAE*out.mm1c);
out.lambdaf = -par.CHI*out.lf*out.Dqf*(1+par.BETAE*out.mm1f);
out.lambdan = -par.CHI*out.lnon*out.Dqn*(1+par.BETAE*out.mm1n);

% investment and dividends
out.iic = par.DELTAK*out.kc;
out.iif = par.DELTAK*out.kf;
out.iin = par.DELTAK*out.kn;

% default cost
out.Fcost   = par.CHI*par.VARPHI*(out.Fc*out.lc+out.Ff*out.lf+out.Fn*out.lnon);

% deposit demand
out.d       = (par.OMEGA_D*out.c^par.GAMMA_C/(1-par.BETA*(1+out.rdep)))^(1/par.GAMMA_D);
out.DIAcost = par.ZETA*out.Fmu*out.d;

% resource constraint
out.y       = out.c + out.iic + out.iif + out.iin + out.Fcost + out.etacost + out.DIAcost;

% energy, non-energy and labor demand
zcd         = out.ze /( (out.pc/(out.mc*par.ALPHA*par.NU*par.NUTILDE) * (out.ztilde/out.y) * (out.ze/out.ztilde)^(1/par.EPSTILDE) )^par.EPS ); 
zfd         = out.ze /( (out.pf/(out.mc*par.ALPHA*(1-par.NU)*par.NUTILDE) * (out.ztilde/out.y) * (out.ze/out.ztilde)^(1/par.EPSTILDE) )^par.EPS ); 
znd         = out.ztilde /( (out.pn/(out.mc*par.ALPHA*(1-par.NUTILDE)) * (out.ztilde/out.y))^par.EPSTILDE );
out.w       = out.mc*(1-par.ALPHA)*out.y/out.n;
out.wstar   = out.w;

% supply of final good
ys          = out.A * exp(-par.PSID*out.E) * out.ztilde^par.ALPHA * out.n^(1-par.ALPHA);

% labor supply
out.ns      = out.n;
out.X1      = out.w^par.PHITILDE*out.n*out.c^(-par.GAMMA_C)/(1-par.BETA*par.PSIN);
out.X2      = out.w^(par.PHITILDE*(1+par.GAMMA_N))*par.OMEGA_N*out.n^(1+par.GAMMA_N)/(1-par.BETA*par.PSIN);

% Residuals
resid(1)    = out.zc - zcd;  % excess supply clean energy
resid(2)    = out.zf - zfd;  % excess supply fossil energy
resid(3)    = out.zn - znd;  % excess supply non-energy
resid(4)    = out.y - ys;    % excess demand final good
resid(5)    = out.X1 * out.w^(1+par.PHITILDE*par.GAMMA_N) - out.X2;

end
