function par = setParams_slc()

par = setParams_structural();

% bank regulation
par.KAPPACss    = 0.08;    % clean
par.KAPPAFss    = 0.08;    % fossil reward
par.KAPPAFPEN   = 1;       % fossil penalty
par.KAPPANss    = 0.08;    % non-energy
par.KAPPAGss    = 0.08;    % gvt

% government bond supply
par.LG          = 0.6;

% climate policy
par.TAXE        = 0.0;    % emission tax 

end