%**************************************************************************
%  Climate Change and the Macroeconomics of Bank Capital Regulation
%  (C) Giovanardi and Kaldorf (2025)
%**************************************************************************
% computes steady state for extension with risk-free asset, constant policy

function [out,par,check] = fcomputeSS_rf(par)

% financial markets
out.KAPPAC          = par.KAPPACss;
out.KAPPAF          = par.KAPPAFss;
out.KAPPAN          = par.KAPPANss;
out.KAPPAG          = par.KAPPAGss;
out.lg              = par.LG;

% real side
out.TAXE            = par.TAXE;
out.A               = 1;
out.Delta           = 1;
out.eta             = (out.TAXE/par.THETA1)^(1/par.THETA2);
out.xi              = out.TAXE*(1-out.eta) + par.THETA1/(1+par.THETA2)*out.eta^(1+par.THETA2);

out.psic            = 1;
out.psif            = 1;
out.psin            = 1;

out.mc              = (par.PHI-1)/par.PHI;
out.pii             = 1;

% guess for mm1c, mm1f, mm1n, mbarc, mbarf, mbarn, mubar, rdep
if out.KAPPAF > 0.5
finguess = [0.8,0.8,0.8,0.65,0.65,0.65,0.85,0];
else
finguess = [0.8,0.8,0.8,0.65,0.65,0.65,0.92,0];
end

options = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-16,'FunctionTolerance',1e-16);
finstar = fsolve(@(x) (fresidFIN(x,out,par)),finguess,options);

[valfun,out] = fresidFIN(finstar,out,par);

if abs(max(valfun)) > 1e-12
    error('No Fixed Point Found')
end

% Definitions
out.V           = (out.c^(1-par.GAMMA_C)/(1-par.GAMMA_C) - par.OMEGA_N * out.n^(1+par.GAMMA_N)/(1+par.GAMMA_N) + par.OMEGA_D*out.d^(1-par.GAMMA_D)/(1-par.GAMMA_D))/(1-par.BETA);

out.kagg        = out.kc + out.kf + out.kn;
out.lagg        = out.lc + out.lf + out.lnon;
out.fossilshare = 100*(1-out.eta)*out.zf/(out.zc+out.zf);

out.recovc      = out.Gc/(out.Fc*out.mbarc)-par.VARPHI;
out.recovf      = out.Gf/(out.Ff*out.mbarf)-par.VARPHI;
out.recovn      = out.Gn/(out.Fn*out.mbarn)-par.VARPHI;
out.recov       = (out.lc*out.recovc + out.lf*out.recovf + out.lnon*out.recovn)/out.lagg;

out.levc        = out.lc/out.kc;
out.levf        = out.lf/out.kf;
out.levn        = out.lnon/out.kn;
out.lev         = (out.lc*out.levc + out.lf*out.levf + out.lnon*out.levn)/out.lagg;

out.dshare      = 100*out.d/out.y;
out.Fagg        = (out.lc*out.Fc + out.lf*out.Ff + out.lnon*out.Fn)/out.lagg;
out.etacost     = par.THETA1/(1+par.THETA2)*out.eta^(1+par.THETA2)*out.zf;
out.energyshare = 100*(out.pc*out.zc + out.pf*out.zf)/(out.mc*out.y);

out.rfree       = 1/par.BETA-1;
out.yieldrf     = 10000*out.rfree;
out.yieldc      = 10000*(1+par.CHI/out.qc-par.CHI)-10000;
out.yieldf      = 10000*(1+par.CHI/out.qf-par.CHI)-10000;
out.yieldn      = 10000*(1+par.CHI/out.qn-par.CHI)-10000;
out.yieldg      = 10000*(1+par.CHI/out.qg-par.CHI)-10000;
out.yielddep    = 10000*out.rdep;
out.markdown    = (1+out.rdep)/(1+out.rfree);

out.logc          = log(out.c);
out.logd          = log(out.d);
out.loge          = log(out.e);
out.loginv        = log(out.iic + out.iif + out.iin);
out.logloan       = log(out.lc + out.lf + out.lnon);
out.logy          = log(out.y);

%% Flag if everything went through
check = 0;

end