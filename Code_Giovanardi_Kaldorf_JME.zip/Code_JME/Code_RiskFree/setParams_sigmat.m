function par = setParams_sigmat()

par = setParams_structural();

% bank regulation
par.KAPPACss    = 0.08;    % clean
par.KAPPAFss    = 0.08;    % fossil
par.KAPPANss    = 0.08;    % non-energy
par.KAPPAGss    = 0.08;    % gvt

% government bond supply
par.LG          = 0.6;

% climate policy
par.TAXEss      = 0.002;    % emission tax 
par.RHO_T    	= 0.8;    % persistence tax
par.SIGMA_T  	= 0.00;   % standard deviation tax shock

end